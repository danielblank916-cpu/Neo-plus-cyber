# NEO CYBER project status — 2.0.0 source release candidate

## Confirmed product requirements
- Android only; standalone phone operation.
- No root required for supported features.
- No laptop, Kali installation, or remote computer required at runtime.
- Local-first operation for supported security assessments.
- No demo screens, sample capture files, mock findings, fake scan output, or non-functional placeholder tools.

## Implemented in source
- [x] Flutter dark mobile dashboard and navigation.
- [x] Bounded TCP connect scanner (up to 128 ports per run), explicit authorization acknowledgement, and stop control.
- [x] Common TCP service-name hints and best-effort service banner identification.
- [x] Passive HTTP(S) security-header checker.
- [x] New passive web vulnerability/configuration assessment: HTTP transport, HSTS, CSP, anti-framing policy, MIME sniffing, referrer and permissions headers, cookie attributes, and technology-banner disclosure.
- [x] Evidence and remediation guidance displayed for each observed condition.
- [x] Copyable plain-text assessment report.
- [x] Manual HTTP request/response workbench (GET, HEAD, OPTIONS, POST) with normal TLS validation and bounded response display.
- [x] Offline Ethernet PCAP and PCAPNG metadata reader.
- [x] IPv4 and IPv6 endpoint decoding; TCP/UDP port and ICMP/ICMPv6/ARP identification.
- [x] Local assessment history for scanner and web-header checks.
- [x] Loopback-only explicit HTTP forward proxy on 127.0.0.1:8888; HTTPS CONNECT remains encrypted.
- [x] Original uploaded Python project retained under `legacy_engine/`.
- [x] No bundled sample captures, fake findings, demo screens, or placeholder tool modules.

## Vulnerability assessment scope and limitations
- This module performs one ordinary GET request and evaluates observable response headers and Set-Cookie attributes. It does not crawl the site or test application inputs.
- Missing headers/attributes are configuration observations, not proof of an exploitable vulnerability. Severity labels are triage guidance and need manual validation.
- It does not test SQL injection, XSS, CSRF exploitability, authentication, authorization/access control, business logic, dependencies, source code, server-side vulnerabilities, or authenticated areas.
- It does not bypass TLS validation, submit exploit payloads, brute-force credentials, or attempt exploitation.
- The copyable report is plain text. PDF export is not implemented in this version.

## Other explicit limitations
- Port scanner is a conservative sequential TCP connect scanner, not the full Nmap engine. It does not perform SYN/UDP scans, OS detection, NSE scripts, or exploit checks.
- HTTP Inspector is a manual request workbench, not a transparent Burp-style interception proxy.
- Local proxy does not decrypt TLS, install a CA certificate, or inspect encrypted requests/responses. It listens on loopback only.
- Packet analyzer imports capture files; it does not perform live traffic capture, decrypt HTTPS, or inspect application payloads. PCAPNG interface timestamp-resolution (decimal and binary) and timestamp-offset options are interpreted; classic PCAP microsecond and nanosecond timestamps are normalized to UTC microseconds. Simple Packet Blocks, which do not carry timestamps, are marked as timestamp unavailable.
- Wi-Fi monitor mode, packet injection, and unrestricted low-level capture are unavailable on ordinary non-rooted Android devices.
- Full Metasploit Framework, full OWASP ZAP, full Burp Suite, live VPN packet capture, automated exploit testing, PDF reports, and NEO AI are not part of this build.

## Build verification
Flutter and the Android SDK are not available in the current build environment. Source has not been compiled into an APK or device-tested here. ZIP integrity can be checked, but that is not a substitute for a Flutter build. Build using `flutter pub get` and `flutter build apk --release` in a configured Flutter/Android environment.

## Safety
Use only on systems you own or have explicit permission to assess. The in-app authorization acknowledgement is a reminder, not proof of permission.


## v0.9 update
- Added formatted PDF export for completed passive web assessments using the Android share/print sheet.
- Added automatic local history entry with target, HTTP status, observation count, and severity totals.
- PDF includes evidence, remediation guidance, timestamp, and explicit scope limitations.
- Build/device testing still required; Flutter/Android SDK are not present in the authoring environment.

## v1.0 update
- Added detailed local history records for completed passive web vulnerability assessments, including each finding's level, title, evidence, and recommendation.
- History entries can be opened to inspect stored details, deleted individually, or cleared after a confirmation prompt.
- Older history records remain readable; records created by other tools continue to show their summary where detailed evidence was not stored.
- Existing PDF export remains available from the live assessment result screen; historical PDF re-export is not implemented.
- No APK compilation or Android device test has been performed in this environment.


## v1.1 update
- Added PDF re-export for saved web vulnerability assessment records from the History list and record details dialog.
- Historical PDF reproduces only stored data and clearly states that it does not re-run or independently validate the original assessment.
- Legacy summary-only records remain supported; the detailed export action is shown only for saved web assessment records containing detailed observations.
- Updated app version to 1.1.0+11.
- Source-level checks and ZIP integrity check performed. Flutter compilation and physical-device testing remain outstanding because Flutter and Android SDK are unavailable in this environment.


## v1.2 update
- Added passive Content-Security-Policy quality observations for `unsafe-inline`, `unsafe-eval`, and wildcard `default-src` patterns.
- Added an HSTS max-age observation when the HTTPS response omits max-age or uses a value shorter than 180 days.
- Added a SameSite=None-without-Secure cookie observation.
- These checks inspect the single response already fetched by the existing assessment; they do not send exploit payloads or make a vulnerability claim beyond the observed configuration.
- Updated app version to 1.2.0+12. Source compilation and device testing remain outstanding.


## v1.3 update
Added local history search, Web/Network/Other category filtering, and newest/oldest ordering. This is a UI-level view over existing records; no scan behavior or stored record format changed. Compilation/device testing remains outstanding until a Flutter/Android SDK environment is available.


## v1.4 update
- TCP scan history now stores the actual service-identification observations returned by that scan, rather than only a summary string.
- Added CSV copying for current service-identification results, with quoted/escaped fields for safe spreadsheet import.
- CSV columns include target, port, protocol, common-port service hint, and the observed banner/result text.
- CSV export is only available when real service-identification results exist; no sample rows or fabricated results are generated.
- Updated app version to 1.4.0+14. Source-level inspection and ZIP integrity checks performed; Flutter compilation and Android device testing remain outstanding.


## v1.5 update
- Added four selectable per-port TCP connection timeout values: 400, 800, 1,500, and 2,500 ms.
- The same selected timeout is used during the TCP connect scan and the subsequent best-effort service identification connection/read wait.
- The chosen timeout is saved in the scan history summary for context when reviewing results later.
- This is a tuning control for differing network latency; it does not guarantee a service banner or provide full Nmap fingerprinting.
- Updated app version to 1.5.0+15. Flutter compilation and physical-device testing remain outstanding because Flutter and Android SDK are unavailable in the authoring environment.


## v1.6 update
- Classic PCAP packet timestamps now honor both microsecond and nanosecond file formats and validate the timestamp fraction range.
- PCAPNG Interface Description Blocks now parse the `if_tsresol` option (decimal and binary resolutions) and `if_tsoffset`; packet timestamps are converted to UTC microseconds per interface.
- Packet rows display the decoded UTC timestamp. PCAPNG Simple Packet Blocks are correctly marked as having no timestamp instead of displaying a fabricated zero time.
- Unsupported/unrepresentable PCAPNG timestamp resolutions are rejected with a clear format error.
- Updated app version to 1.6.0+16. Source inspection and ZIP integrity checks are performed; Flutter compilation and physical-device testing remain outstanding because Flutter and Android SDK are unavailable in the authoring environment.


## v1.7 update
- Hardened the loopback HTTP proxy with a maximum of 12 simultaneous client connections; excess clients receive an HTTP 503 response and a real rejection event is recorded.
- Added a 64 KiB request-header size ceiling and a 15-second header-read timeout to reduce resource exhaustion from stalled or oversized local clients.
- The proxy remains bound only to 127.0.0.1; HTTPS CONNECT remains an opaque encrypted tunnel.
- Updated app version to 1.7.0+17. Source inspection and ZIP integrity checks performed; Flutter compilation and physical Android testing remain outstanding.


## v1.8 update
- Replaced substring-based cookie attribute detection with exact Set-Cookie attribute parsing to reduce false positives.
- Added passive recognition of unrecognized SameSite values.
- Added checks for `__Secure-` and `__Host-` cookie prefix requirements (Secure; and for `__Host-`, Path=/ with no Domain).
- Checks inspect only Set-Cookie headers from the same ordinary HTTP(S) response; no authentication, exploit payloads, or active testing were added.
- Updated app version to 1.8.0+18. Source inspection and ZIP integrity checks performed; Flutter compilation and physical Android testing remain outstanding.


## v1.9 update
- Added an app integration check screen under About. It performs actual local checks for Android runtime, readability of the saved assessment history, and ability to bind a temporary loopback TCP socket.
- The loopback probe binds only to 127.0.0.1 on an operating-system-assigned ephemeral port and closes immediately; it does not scan external hosts or leave a listener running.
- Results include pass/fail details and the number of saved history records. The screen explicitly explains that these checks are not full application certification.
- Updated app version to 1.9.0+19. Source inspection and ZIP integrity checks performed. Flutter compilation and physical Android testing remain outstanding because Flutter and Android SDK are unavailable in the authoring environment.


## v2.0.0 source release candidate
- Consolidated the current tool set and updated the package version to 2.0.0+20.
- Added a release-gate checklist covering static analysis, Flutter tests, Android manifest/SDK verification, release APK build, physical-device testing, lifecycle/error handling, and artifact checksum recording.
- Re-stated the non-rooted Android scope and excluded desktop-equivalent/live-capture/TLS-interception claims.
- **Not certified as a final installable release:** Flutter and Android SDK are unavailable in this authoring environment; no APK was built, no Flutter analyzer/test suite was run, and no physical Android device was tested. The Android platform/Gradle project is not included in this source archive and must be generated/verified in the configured build environment.
- ZIP integrity and source-level consistency checks are the only completed release checks in this environment.


## v2.1 — NEO DEVICE CONTROL foundation
- Added a Devices navigation destination and a dedicated NEO DEVICE CONTROL page.
- Added real manual inventory enrollment for Android, computer, router, camera, IoT and Bluetooth categories.
- Inventory persists locally using SharedPreferences; users can remove entries after confirmation.
- Added bounded TCP reachability checks (one configured host/port, 3-second timeout, socket closed after attempt).
- Status is explicitly unknown until checked. Results are labelled as TCP reachability, not device management access.
- No demo entries, automatic network discovery, credentials, remote commands, or fake control buttons.
- Bluetooth pairing, companion apps, computer agent, router APIs and camera/IoT controls remain future milestones.
- Build status: source-only update. Flutter/Dart toolchain availability and Android device validation must be checked in a configured build environment; do not treat this ZIP as a tested APK.


## v2.2 milestone — Bluetooth / BLE foundation

Implemented in source: foreground BLE scan, Android 12+ scan/connect runtime permission requests, scan-result display (advertised name, identifier, RSSI), user-initiated connection, GATT service discovery, read-only characteristic reads, disconnect, and error/status messaging. Characteristic writes, background scanning, classic Bluetooth control, and vendor-specific commands are not implemented. Android manifest requirements and compatibility notes are documented in `docs/ANDROID_BLE_SETUP_v2.2.md`.

Validation status: source files and archive integrity can be checked here, but Flutter/Dart compilation and physical Bluetooth testing require the Flutter toolchain and an Android phone; neither is claimed as completed by this release.


## v2.3 — ONVIF and IoT discovery foundation
- Added foreground ONVIF WS-Discovery using a standard UDP multicast probe to 239.255.255.250:3702.
- Parses returned XAddrs, source IP, scopes, and type metadata; endpoint URLs can be copied.
- Read-only discovery only: no camera authentication, video, PTZ, settings changes, or generic IoT commands.
- Documented Android/network multicast limitations, including networks that filter multicast and absence of a native Wi-Fi multicast-lock implementation.
- Updated package version to 2.3.0+23. Source archive validation is not a substitute for Flutter compilation or testing with a physical ONVIF camera.


## v2.4 — Android companion application foundation
- Added a separate `neo_android_companion/` Flutter project for installation on a second Android phone.
- Reads real Android device metadata locally (manufacturer, model, Android release, SDK and security patch).
- Displays the metadata and shares a report only after an explicit user tap using the Android share sheet.
- No automatic transmission, background listener, remote command execution, or access to private device content.
- This is not yet paired with the main NEO CYBER controller. Secure enrollment and authenticated communications are future work.
- Build instructions are in `neo_android_companion/README.md`.


## v2.5 — Computer agent foundation
Added an optional Python 3.10+ Windows/Linux foreground agent with authenticated, read-only inventory and allowlisted diagnostics. LAN access requires HTTPS configuration; loopback is the default. It is not yet paired with the Android app. See `computer_agent/README.md`.


## v2.5 — Optional Windows/Linux computer agent
- Added `computer_agent/`, a Python 3.10+ foreground agent.
- Authenticated read-only inventory and three allowlisted diagnostics: system, storage, and network identity.
- No arbitrary shell execution, file access, process/service control, persistence, or stealth.
- Loopback HTTP is the default; LAN binding requires TLS certificate/key. Restrict LAN access with a host firewall and a long random bearer token.
- Not yet paired with the Android app. Secure enrollment, certificate validation and controller UI are future work.
- See `computer_agent/README.md`.
