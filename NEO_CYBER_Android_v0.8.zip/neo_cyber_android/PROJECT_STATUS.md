# NEO CYBER project status — 0.8.0

## Confirmed product requirements
- Android only; standalone phone operation.
- No root required for supported features.
- No laptop, Kali installation, or remote computer required at runtime.
- Local-first operation for supported security assessments.
- No demo screens, sample capture files, mock findings, fake scan output, or non-functional placeholder tools.

## Implemented in source
- [x] Flutter dark mobile dashboard and navigation.
- [x] Bounded TCP connect scanner (up to 128 ports per run), explicit authorization acknowledgement, and stop control.
- [x] Common TCP service-name hints and best-effort service banner identification.
- [x] Passive HTTP(S) security-header checker.
- [x] New passive web vulnerability/configuration assessment: HTTP transport, HSTS, CSP, anti-framing policy, MIME sniffing, referrer and permissions headers, cookie attributes, and technology-banner disclosure.
- [x] Evidence and remediation guidance displayed for each observed condition.
- [x] Copyable plain-text assessment report.
- [x] Manual HTTP request/response workbench (GET, HEAD, OPTIONS, POST) with normal TLS validation and bounded response display.
- [x] Offline Ethernet PCAP and PCAPNG metadata reader.
- [x] IPv4 and IPv6 endpoint decoding; TCP/UDP port and ICMP/ICMPv6/ARP identification.
- [x] Local assessment history for scanner and web-header checks.
- [x] Loopback-only explicit HTTP forward proxy on 127.0.0.1:8888; HTTPS CONNECT remains encrypted.
- [x] Original uploaded Python project retained under `legacy_engine/`.
- [x] No bundled sample captures, fake findings, demo screens, or placeholder tool modules.

## Vulnerability assessment scope and limitations
- This module performs one ordinary GET request and evaluates observable response headers and Set-Cookie attributes. It does not crawl the site or test application inputs.
- Missing headers/attributes are configuration observations, not proof of an exploitable vulnerability. Severity labels are triage guidance and need manual validation.
- It does not test SQL injection, XSS, CSRF exploitability, authentication, authorization/access control, business logic, dependencies, source code, server-side vulnerabilities, or authenticated areas.
- It does not bypass TLS validation, submit exploit payloads, brute-force credentials, or attempt exploitation.
- The copyable report is plain text. PDF export is not implemented in this version.

## Other explicit limitations
- Port scanner is a conservative sequential TCP connect scanner, not the full Nmap engine. It does not perform SYN/UDP scans, OS detection, NSE scripts, or exploit checks.
- HTTP Inspector is a manual request workbench, not a transparent Burp-style interception proxy.
- Local proxy does not decrypt TLS, install a CA certificate, or inspect encrypted requests/responses. It listens on loopback only.
- Packet analyzer imports capture files; it does not perform live traffic capture, decrypt HTTPS, or inspect application payloads. PCAPNG timestamp-resolution options are not yet interpreted.
- Wi-Fi monitor mode, packet injection, and unrestricted low-level capture are unavailable on ordinary non-rooted Android devices.
- Full Metasploit Framework, full OWASP ZAP, full Burp Suite, live VPN packet capture, automated exploit testing, PDF reports, and NEO AI are not part of this build.

## Build verification
Flutter and the Android SDK are not available in the current build environment. Source has not been compiled into an APK or device-tested here. ZIP integrity can be checked, but that is not a substitute for a Flutter build. Build using `flutter pub get` and `flutter build apk --release` in a configured Flutter/Android environment.

## Safety
Use only on systems you own or have explicit permission to assess. The in-app authorization acknowledgement is a reminder, not proof of permission.
