# NEO CYBER — Android standalone application (0.8.0)

NEO CYBER is designed to run directly on a non-rooted Android phone. It does not require a laptop, Kali installation, or remote computer at runtime. The app contains mobile-compatible assessment functions; it does not claim to bundle full desktop versions of Nmap, Wireshark, Burp Suite, OWASP ZAP, or Metasploit.

## Functions in this source build
- Dark Flutter mobile dashboard and navigation.
- Bounded TCP connect scanner (up to 128 ports per run), common-port service hints, and best-effort banner checks.
- Passive HTTP(S) security-header checker.
- **Web vulnerability/configuration assessment:** one-request inspection of transport security, HSTS, CSP, anti-framing headers, MIME-sniffing protection, referrer/permissions policies, cookie attributes, and technology-banner disclosure. Displays evidence and remediation guidance; supports copying a plain-text report.
- Manual HTTP request/response workbench for GET, HEAD, OPTIONS and POST; HTTPS uses normal platform certificate validation.
- Offline Ethernet PCAP and PCAPNG metadata analyzer; no live packet capture or payload decryption.
- Local assessment history.
- Explicit loopback HTTP forward proxy at `127.0.0.1:8888`; HTTPS CONNECT is an opaque tunnel and remains encrypted.
- Original uploaded Python modules retained under `legacy_engine/`.

## Vulnerability assessment limitations
The new assessment makes one ordinary GET request and checks observable response headers and cookies. It does not crawl, fuzz, authenticate, exploit, or test application input handling. Missing headers are not proof of exploitability. It does not test SQL injection, XSS, access control, authentication, business logic, dependencies, or server-side code. The report is plain text; PDF export is not included yet.

## Other limitations
The scanner is not the Nmap engine and does not perform SYN/UDP scans, OS detection, NSE scripts, or exploit checks. The HTTP workbench is not a transparent Burp proxy. The local proxy does not decrypt TLS. The packet analyzer imports PCAP files and does not capture live traffic. Rootless Android restricts monitor mode, packet injection, and low-level capture.

## Android build
Install Flutter and Android Studio with the Android SDK. From this directory run:

```bash
flutter pub get
flutter create --platforms=android --org com.neocyber .
flutter run
```

If the Android platform folder already exists, skip `flutter create`. Add `INTERNET` and `ACCESS_NETWORK_STATE` permissions under the `<manifest>` element in `android/app/src/main/AndroidManifest.xml`.

Build a release APK with:

```bash
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Safety
Only assess systems you own or have explicit permission to test. The authorization checkbox is a reminder, not proof of permission.
