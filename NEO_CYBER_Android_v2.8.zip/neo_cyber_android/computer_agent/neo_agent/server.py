#!/usr/bin/env python3
"""NEO CYBER authenticated, read-only computer companion agent."""
import argparse, json, os, platform, secrets, shutil, socket, ssl, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

STARTED = time.monotonic()
ALLOWED = {"system", "storage", "network_identity"}

def inventory():
    d = shutil.disk_usage(os.path.abspath(os.sep))
    return {"hostname": socket.gethostname(), "platform": platform.system(),
            "platform_release": platform.release(), "architecture": platform.machine(),
            "python": platform.python_version(),
            "root_storage": {"total_bytes": d.total, "free_bytes": d.free},
            "agent_uptime_seconds": int(time.monotonic()-STARTED)}

def diagnostic(name):
    if name == "system":
        return {"platform": platform.platform(), "architecture": platform.machine(),
                "python": platform.python_version(), "processor": platform.processor()}
    if name == "storage":
        d = shutil.disk_usage(os.path.abspath(os.sep))
        return {"total_bytes": d.total, "used_bytes": d.used, "free_bytes": d.free}
    if name == "network_identity":
        return {"hostname": socket.gethostname(), "fqdn": socket.getfqdn()}
    raise KeyError(name)

class Handler(BaseHTTPRequestHandler):
    server_version = "NEO-Computer-Agent/2.5"
    def log_message(self, fmt, *args):
        print(json.dumps({"event":"access","client":self.client_address[0],
                          "message":fmt % args}), flush=True)
    def send_json(self, code, data):
        body=json.dumps(data,separators=(",",":")).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(body)))
        self.send_header("Cache-Control","no-store")
        self.end_headers()
        self.wfile.write(body)
    def authorized(self):
        return secrets.compare_digest(self.headers.get("Authorization",""),
                                       "Bearer "+self.server.token)
    def do_GET(self):
        if not self.authorized():
            self.send_json(401,{"error":"unauthorized"}); return
        path=urlparse(self.path).path
        if path=="/health":
            self.send_json(200,{"status":"ok","version":"2.5","read_only":True}); return
        if path=="/v1/inventory":
            self.send_json(200,inventory()); return
        prefix="/v1/diagnostics/"
        if path.startswith(prefix):
            name=path[len(prefix):]
            if name not in ALLOWED:
                self.send_json(404,{"error":"diagnostic_not_allowed"}); return
            self.send_json(200,{"name":name,"result":diagnostic(name)}); return
        self.send_json(404,{"error":"not_found"})
    def do_POST(self): self.send_json(405,{"error":"read_only_agent"})
    do_PUT=do_POST
    do_DELETE=do_POST

def main():
    p=argparse.ArgumentParser(description="NEO authenticated read-only computer agent")
    p.add_argument("--host",default="127.0.0.1")
    p.add_argument("--port",type=int,default=8765)
    p.add_argument("--token",default=os.environ.get("NEO_AGENT_TOKEN"))
    p.add_argument("--tls-cert"); p.add_argument("--tls-key")
    a=p.parse_args()
    loopback=a.host in ("127.0.0.1","::1","localhost")
    if not loopback and not (a.tls_cert and a.tls_key):
        p.error("Non-loopback binding requires --tls-cert and --tls-key (HTTPS).")
    token=a.token or secrets.token_urlsafe(32)
    if len(token)<24: p.error("Token must contain at least 24 characters.")
    server=ThreadingHTTPServer((a.host,a.port),Handler)
    server.token=token
    if not loopback:
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version=ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(a.tls_cert,a.tls_key)
        server.socket=ctx.wrap_socket(server.socket,server_side=True)
    print(json.dumps({"event":"started","host":a.host,"port":a.port,
                      "transport":"loopback-http" if loopback else "https",
                      "bearer_token":token if not a.token else "provided",
                      "read_only":True}),flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__=="__main__": main()
