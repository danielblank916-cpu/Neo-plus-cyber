# NEO Computer Agent v2.5

Optional foreground agent for a Windows or Linux computer you own or are authorized to administer. Requires Python 3.10+; standard library only.

## Features
- Bearer-token authenticated health endpoint and device inventory.
- Three read-only allowlisted diagnostics: system, storage, network identity.
- Access logging without logging bearer tokens.
- No arbitrary shell execution, file browsing or transfer, process/service control, persistence, stealth, or remote power controls.
- Loopback HTTP by default. Any non-loopback bind requires TLS certificate and key.

## Start locally
`python -m neo_agent.server`
The generated one-time token is printed on startup. Keep it private.
`curl -H "Authorization: Bearer YOUR_TOKEN" http://127.0.0.1:8765/v1/inventory`

## LAN use
Only on a trusted LAN, with a trusted TLS certificate and host firewall restricted to the controller:
`NEO_AGENT_TOKEN='long-random-secret-at-least-24-chars' python -m neo_agent.server --host 0.0.0.0 --port 8765 --tls-cert cert.pem --tls-key key.pem`

This is a foreground process. Stop it with Ctrl+C. The Android NEO CYBER app is not yet paired to this agent; secure enrollment, certificate validation and integration remain future work.
