# NEO CYBER v2.8 — Secure computer-agent pairing

## What this milestone does

The Android Device Control area includes a user-initiated pairing panel for the
optional NEO Windows/Linux agent. It sends authenticated GET requests to:

- `GET /health`
- `GET /v1/inventory`

Both requests use `Authorization: Bearer <token>`. A successful response from
both endpoints is required before the UI reports an authenticated connection.
The token is not written to preferences or a local file by this panel.

## Transport requirements

The Android client accepts HTTPS only and uses the platform's normal TLS
certificate validation. It does not disable certificate validation or accept
arbitrary certificates. For a private LAN deployment, use a certificate whose
identity and trust chain are valid on the Android phone, or deploy a properly
trusted certificate. A self-signed/untrusted certificate will fail by design.

Do not expose the agent to the public internet. Prefer a trusted private LAN or
a secure VPN. The agent's non-loopback bind mode must use its TLS certificate
and private key as documented in the agent README. Protect the bearer token
and rotate it if it is disclosed.

## Pairing steps

1. Start the agent on the computer using its documented secure TLS mode.
2. Ensure the phone can reach the computer on the private network/VPN.
3. Enter the agent's HTTPS address and port in NEO CYBER.
4. Enter the bearer token configured for that agent.
5. Confirm that you administer the computer or have explicit permission.
6. Tap **Authenticate & pair**. The app checks `/health` and `/v1/inventory`.
7. Tap **Disconnect** to clear the screen's token and connection state.

## Current limitations

- No permanent device enrollment or token storage.
- No QR-code provisioning or one-time pairing code.
- No certificate pinning or managed CA import UI.
- No remote command execution, process control, file access or service control.
- The UI confirms authenticated read-only endpoint access only.
- The pairing panel does not yet integrate Android companion enrollment.
- The agent's own bind address, firewall and TLS configuration must be set up
  by the computer administrator.

## Validation

The source archive is checked for ZIP integrity and expected source markers.
Flutter build, HTTPS handshake testing on Android, and live agent pairing
remain outstanding. No installable APK is claimed.
