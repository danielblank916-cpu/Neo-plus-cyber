# NEO CYBER v2.7 — Unified Device Control Centre

## Overview

The Device Control area now includes a unified capability overview and a
session-only activity log. The overview distinguishes implemented local tools
from components that are not yet paired or integrated.

## Capability status

- Android companion: separate Flutter project; local device information and
  user-initiated report sharing. It is not remotely paired to the main app.
- Windows/Linux computer agent: optional agent source is included, but
  Android-to-agent enrollment, secure pairing and command routing are not
  integrated in this release.
- Router diagnostics: one manually entered authorized host; TCP reachability
  checks on ports 80, 443, 8080 and 8443 only.
- Bluetooth/BLE: foreground discovery and supported read-only GATT inspection,
  subject to hardware and Android permissions.
- ONVIF/IoT: user-triggered WS-Discovery for compatible ONVIF devices.

## Activity log

The activity log records router port-check outcomes in memory during the
current app session, with a maximum of 100 entries. The user can clear it.
Entries are not persisted after process termination. Persistent encrypted
storage, log export, and full event coverage for BLE/ONVIF/companion/agent
actions are not implemented in this milestone.

## Authorization and limitations

Use only devices you own or are explicitly authorized to assess. This release
does not add stealth access, lock bypass, password guessing, arbitrary shell
execution, or universal device control. Device capabilities remain protocol-
and vendor-dependent.

## Validation

The source archive is checked for ZIP integrity and expected source markers.
Flutter compilation, Android permission-flow testing, BLE hardware testing,
ONVIF network testing and physical device testing remain outstanding.
