# NEO CYBER v2.6 — Router diagnostics

## Scope

The Router Diagnostics panel is an Android-side, user-triggered, read-only TCP
reachability check for one router IP address or hostname entered by the user.
The user must confirm that they own the router or have permission to assess it.

The check attempts only TCP ports 80, 443, 8080 and 8443, sequentially, with a
two-second timeout per port. Each socket is closed immediately after the
connection attempt. No subnet sweep or automatic router discovery is performed.

## Interpreting results

A successful TCP connection means only that a TCP endpoint accepted a
connection at that host and port at the time of the check. It does not establish
that the endpoint is a router administration interface, identify the router,
confirm a login page, or reveal firmware, WAN/LAN configuration, connected
clients, or security posture. A failed connection may reflect filtering,
network isolation, a different management port, or an offline host.

## Safety and compatibility

- No credentials are requested or stored.
- No login attempts, password guessing, configuration changes, or commands.
- No router reset, reboot, firmware update, or connected-device enumeration.
- Use only on equipment you own or are explicitly authorized to assess.
- Android Wi-Fi client isolation, VPNs, firewalls, routing, and OS/network
  restrictions may affect reachability.
- Router administration remains vendor-specific. Authenticated management,
  SNMPv3, UPnP device-description parsing, and vendor APIs are not implemented
  by this milestone.

This is a source milestone, not a certified APK. Flutter compilation and
physical-router testing must be completed in a configured Android build
environment.
