import 'dart:math';
import 'dart:convert';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const NeoCompanionApp());

class NeoCompanionApp extends StatelessWidget {
  const NeoCompanionApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'NEO Companion', debugShowCheckedModeBanner: false,
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: const Color(0xFF080D18),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF168BFF), brightness: Brightness.dark)),
    home: const CompanionHome());
}

class CompanionHome extends StatefulWidget {
  const CompanionHome({super.key});
  @override
  State<CompanionHome> createState() => _CompanionHomeState();
}

class _CompanionHomeState extends State<CompanionHome> {
  AndroidDeviceInfo? info;
  String? error;
  bool loading = true;
  @override
  void initState() { super.initState(); loadInfo(); }
  Future<void> loadInfo() async {
    try {
      final value = await DeviceInfoPlugin().androidInfo;
      if (!mounted) return;
      setState(() { info = value; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = 'Device information unavailable: $e'; loading = false; });
    }
  }
  String get report {
    final i = info;
    if (i == null) return 'NEO Companion device report unavailable.';
    return [
      'NEO CYBER COMPANION — DEVICE REPORT',
      'Manufacturer: ${i.manufacturer}', 'Model: ${i.model}', 'Device: ${i.device}',
      'Android release: ${i.version.release}', 'SDK level: ${i.version.sdkInt}',
      'Security patch: ${i.version.securityPatch}', 'Physical device: ${i.isPhysicalDevice}',
      'Generated locally following a user action.'
    ].join('\\n');
  }

  String _secureToken(int bytes) {
    final random = Random.secure();
    final values = List<int>.generate(bytes, (_) => random.nextInt(256));
    return base64UrlEncode(values).replaceAll('=', '');
  }

  String get enrollmentBundle {
    final i = info;
    if (i == null) return '';
    final payload = <String, dynamic>{
      'format': 'neo-companion-enrollment-v1',
      'device_type': 'android',
      'device_id': _secureToken(18),
      'enrollment_secret': _secureToken(32),
      'manufacturer': i.manufacturer,
      'model': i.model,
      'device': i.device,
      'android_release': i.version.release,
      'sdk_level': i.version.sdkInt,
      'security_patch': i.version.securityPatch,
      'physical_device': i.isPhysicalDevice,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'transfer_note': 'User-mediated offline enrollment. Not a live connection proof.'
    };
    return const JsonEncoder.withIndent('  ').convert(payload);
  }

  Widget row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 9),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 132, child: Text(label, style: const TextStyle(color: Colors.white60))),
      Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600))) ]));
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('NEO COMPANION'), centerTitle: true),
    body: SafeArea(child: loading ? const Center(child: CircularProgressIndicator()) :
      error != null ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!))) :
      ListView(padding: const EdgeInsets.all(20), children: [
        const Icon(Icons.phonelink_setup, size: 54, color: Color(0xFF168BFF)),
        const SizedBox(height: 12),
        const Text('THIS ANDROID DEVICE', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Device details are read locally. Nothing is transmitted automatically.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 24),
        Card(color: const Color(0xFF111B2D), child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
          row('Manufacturer', info!.manufacturer), row('Model', info!.model), row('Device code', info!.device),
          row('Android', info!.version.release), row('SDK level', '${info!.version.sdkInt}'),
          row('Security patch', info!.version.securityPatch), row('Physical device', info!.isPhysicalDevice ? 'Yes' : 'No')]))),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: () => Share.share(report, subject: 'NEO Companion device report'), icon: const Icon(Icons.share), label: const Text('Share device report')),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: () => Share.share(enrollmentBundle,
              subject: 'NEO CYBER companion enrollment bundle'),
          icon: const Icon(Icons.add_link),
          label: const Text('Create & share enrollment bundle'),
        ),
        const SizedBox(height: 12),
        const Text('This bundle is a user-mediated offline enrollment record. It does not establish a live connection, authenticate the device over a network, or enable remote commands. No background listener, camera, microphone, or private-file access is exposed.', style: TextStyle(color: Colors.orangeAccent, height: 1.4))
      ]))));
}
