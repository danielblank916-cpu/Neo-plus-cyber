# NEO CYBER v2.9 — Android companion enrollment

## Workflow

1. Build and install the separate `neo_android_companion` Flutter project on
   the Android device that you own or administer.
2. Open NEO Companion and tap **Create & share enrollment bundle**.
3. Share the JSON bundle to the phone running the main NEO CYBER app.
4. Copy the JSON text and paste it into **Android Companion Enrollment**.
5. Confirm authorization and tap **Enroll companion**.
6. The main app saves a local enrollment record. Use the revoke icon to remove
   that record and its secret from this app.

## Bundle contents

The companion creates a random device identifier and 256-bit random enrollment
secret using the platform cryptographic random generator, plus locally
available Android device details. Bundle generation and sharing happen only
after the user taps the share action.

## Important security boundary

This is an offline, user-mediated enrollment record. It is not a live pairing
handshake and does not prove that the imported metadata came from a genuine
companion app. Anyone who can edit the JSON can alter its descriptive fields.
Treat the bundle as sensitive because it contains an enrollment secret.

The main app currently stores the secret in ordinary SharedPreferences, which
is not encrypted by this milestone. Do not reuse the secret as a password or
share it publicly. Local revocation removes the record from this app only; it
does not remotely invalidate a secret or erase the companion device.

## Not included

- Live network pairing or mutual authentication.
- Encrypted-at-rest secret storage or hardware-backed key protection.
- Remote revocation, device commands, background listeners, or remote wipe.
- QR-code scanning or one-time challenge-response.
- Synchronization between companion and main app.

## Validation

The archive is checked for ZIP integrity and source markers. Flutter compilation
and physical two-phone workflow testing remain outstanding. No APK is claimed.
