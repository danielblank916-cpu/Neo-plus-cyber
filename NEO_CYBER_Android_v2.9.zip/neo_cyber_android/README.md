# NEO CYBER — Android standalone application (2.3.0 source release candidate)

NEO CYBER is designed to run directly on a non-rooted Android phone. It does not require a laptop, Kali installation, or remote computer at runtime. The app contains mobile-compatible assessment functions; it does not claim to bundle full desktop versions of Nmap, Wireshark, Burp Suite, OWASP ZAP, or Metasploit.

## Functions in this source build
- Dark Flutter mobile dashboard and navigation.
- Bounded TCP connect scanner (up to 128 ports per run), common-port service hints, and best-effort banner checks.
- Passive HTTP(S) security-header checker.
- **Web vulnerability/configuration assessment:** one-request inspection of transport security, HSTS, CSP, anti-framing headers, MIME-sniffing protection, referrer/permissions policies, cookie attributes, and technology-banner disclosure. Displays evidence and remediation guidance; supports copying a plain-text report.
- Manual HTTP request/response workbench for GET, HEAD, OPTIONS and POST; HTTPS uses normal platform certificate validation.
- Offline Ethernet PCAP and PCAPNG metadata analyzer with microsecond/nanosecond and per-interface PCAPNG timestamp resolution support; no live packet capture or payload decryption.
- Local assessment history.
- **NEO DEVICE CONTROL:** locally persisted manual inventory for Android phones, computers, routers, cameras, IoT and Bluetooth; bounded TCP reachability checks; real foreground BLE discovery and read-only GATT inspection; user-initiated ONVIF WS-Discovery on the local network with endpoint display/copy. ONVIF discovery is read-only and does not log in or control cameras. No sample devices or fake controls.
- Explicit loopback HTTP forward proxy at `127.0.0.1:8888`; HTTPS CONNECT is an opaque tunnel and remains encrypted.
- Original uploaded Python modules retained under `legacy_engine/`.

- **PDF report export:** creates a formatted PDF with target, timestamp, HTTP status, severity counts, evidence, recommendations, and scope limitations; invokes Android share/print sheet. Completed web assessments are also recorded in local assessment history.

## Vulnerability assessment limitations
The new assessment makes one ordinary GET request and checks observable response headers and cookies. It does not crawl, fuzz, authenticate, exploit, or test application input handling. Missing headers are not proof of exploitability. It does not test SQL injection, XSS, access control, authentication, business logic, dependencies, or server-side code. The PDF is a summary of the same passive observations; it does not add deeper testing or establish exploitability.

## Other limitations
The scanner is not the Nmap engine and does not perform SYN/UDP scans, OS detection, NSE scripts, or exploit checks. The HTTP workbench is not a transparent Burp proxy. The local proxy does not decrypt TLS. The packet analyzer imports Ethernet PCAP/PCAPNG files and displays packet metadata/timestamps; it does not capture live traffic, decrypt HTTPS, or inspect application payloads. Rootless Android restricts monitor mode, packet injection, and low-level capture.

## Android build
Install Flutter and Android Studio with the Android SDK. From this directory run:

```bash
flutter pub get
flutter create --platforms=android --org com.neocyber .
flutter run
```

If the Android platform folder already exists, skip `flutter create`. Add `INTERNET` and `ACCESS_NETWORK_STATE` permissions under the `<manifest>` element in `android/app/src/main/AndroidManifest.xml`.

Build a release APK with:

```bash
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Safety
Only assess systems you own or have explicit permission to test. The authorization checkbox is a reminder, not proof of permission.


## v1.0 history improvements
Completed passive web assessments now save their individual observations, evidence, and recommendations in local history. Open a history item to review it, delete one item, or clear all history after confirmation. Older records remain compatible. PDF export is available from the current assessment result; re-exporting PDFs from history is not included.


## v1.1 history PDF export
Saved web vulnerability assessments with detailed observations can now be exported again from the History screen using the PDF icon or the record details dialog. The report reproduces the stored target, timestamp, summary, observations, evidence, and recommendations; it does not run a new scan or validate old observations. Older summary-only records remain viewable but are not offered the detailed PDF action.


### v1.2 passive web policy checks
The web assessment now flags selected CSP policy weaknesses (`unsafe-inline`, `unsafe-eval`, wildcard `default-src`), short/missing HSTS max-age, and SameSite=None cookies without Secure. These are configuration observations from one HTTP response and require manual validation.


## v1.3 assessment history filtering
The History screen now supports case-insensitive search across assessment type, target, summary and timestamp; category filters for Web, Network and Other; and newest/oldest sorting. Filters operate on locally stored records only and do not alter or delete the underlying history.


## v1.4
TCP scan records now retain service-identification details, and current service results can be copied as escaped CSV for spreadsheet use. CSV export uses only results returned by the actual scan.


## v1.5 — scanner timeout control
- Added a user-selectable TCP connection timeout (400, 800, 1,500, or 2,500 ms).
- The selected timeout is applied consistently to port connection attempts and best-effort service identification waits.
- The chosen timeout is recorded in the saved scan summary so results retain important scan context.
- This improves control on different network conditions; it does not make the scanner equivalent to Nmap or guarantee service fingerprinting.


### v1.7 proxy hardening
The local loopback proxy accepts up to 12 concurrent clients, rejects additional clients with HTTP 503, caps request headers at 64 KiB, and applies a 15-second timeout while receiving request headers. It still does not decrypt HTTPS or inspect TLS-protected content.


### v1.8 cookie attribute validation
The passive web assessment parses Set-Cookie attributes by exact attribute name rather than searching the entire cookie string. This reduces false positives where a cookie name or value contains words such as "secure" or "httponly". It also checks recognized SameSite values and the attribute requirements for `__Secure-` and `__Host-` cookie name prefixes. These remain observations from response headers, not proof of exploitability.


### v1.9 local integration checks
The About screen includes an on-demand check of Android runtime, local history readability, and loopback TCP socket binding. The loopback check uses a temporary OS-assigned port and closes it immediately. These checks do not test external connectivity, scan remote systems, or certify every feature.


## v2.0.0 — first complete source release candidate
This version consolidates the implemented Android-compatible tools and documents the release gates. It is a **source release candidate**, not a verified installable APK. The source archive does not include generated Android Gradle scaffolding or a signed APK.

### Final release gates (must pass before calling the app production-ready)
1. In a configured Flutter/Android SDK environment, run `flutter pub get`, `flutter analyze`, and `flutter test`. Resolve every error and review all warnings.
2. Generate/verify the Android platform project and confirm the application ID, minimum/target SDK, Internet permission, and storage/file-picker behavior.
3. Build with `flutter build apk --release`; retain the build log and APK checksum.
4. Install on a physical non-rooted Android phone and exercise each supported tool with user-owned or explicitly authorized targets and real capture files.
5. Verify app lifecycle, network changes, timeouts/cancellation, history persistence, PDF/share flow, proxy stop/restart, malformed capture handling, and low-storage/error states.
6. Record device model, Android version, test results, known defects, and APK SHA-256 before publishing.

### v2.0 scope boundary
The release remains phone-first and non-rooted. It does not claim full Nmap, Wireshark live-capture, Burp Suite, OWASP ZAP, or Metasploit parity. Live packet capture, TLS interception/decryption, exploit execution, and unrestricted low-level network access are outside this release.


## v2.1 — NEO DEVICE CONTROL foundation
The Devices tab stores only devices the user manually enrolls. Inventory data is saved locally with SharedPreferences. The connection check attempts one TCP connection to the configured host and port with a three-second timeout, then closes the socket. A successful check means only that the TCP endpoint accepted a connection; it does not prove device identity, authenticate, or authorize management. A failed check can mean offline, filtered, closed, or unreachable.

This milestone does not yet pair Bluetooth devices, discover devices automatically, install companion software, control computers, administer routers, or operate cameras/IoT devices. Those require real device-side agents, vendor APIs, supported protocols, Android permissions, authenticated enrollment, and security testing. No credentials are collected or stored in this foundation.


## v2.2 — Bluetooth / BLE foundation

- Adds real foreground BLE scanning on Android 12+ using the phone's Bluetooth adapter.
- Adds explicit runtime Bluetooth scan/connect permission requests.
- Allows a user to connect to a selected BLE peripheral, discover GATT services, and read characteristics that explicitly support reads.
- Characteristic writes and background scanning are intentionally disabled. Classic Bluetooth-only devices and vendor-specific control protocols are not universally supported.
- See `docs/ANDROID_BLE_SETUP_v2.2.md` for required Android manifest permissions and platform limits.


### v2.3 ONVIF / IoT discovery
- Added a user-triggered ONVIF WS-Discovery probe to the standard local multicast group (`239.255.255.250:3702/UDP`).
- Parses responding ONVIF service URLs and basic advertised metadata; users can copy the endpoint for subsequent authenticated setup.
- Discovery is limited to local multicast and is read-only. No camera login, video, PTZ, settings changes, or universal IoT control is claimed.
- See `docs/ONVIF_IOT_v2.3.md` for network requirements and limitations.
- Updated source version to 2.3.0+23. Flutter compilation and physical-device testing remain outstanding.


## v2.4 — Android companion application foundation
- Added a separate `neo_android_companion/` Flutter project for installation on a second Android phone.
- Reads real Android device metadata locally (manufacturer, model, Android release, SDK and security patch).
- Displays the metadata and shares a report only after an explicit user tap using the Android share sheet.
- No automatic transmission, background listener, remote command execution, or access to private device content.
- This is not yet paired with the main NEO CYBER controller. Secure enrollment and authenticated communications are future work.
- Build instructions are in `neo_android_companion/README.md`.

## v2.5 — Optional Windows/Linux computer agent
- Added `computer_agent/`, a Python 3.10+ foreground agent for Windows/Linux.
- Provides authenticated read-only inventory and three allowlisted diagnostics (system, storage, network identity).
- No arbitrary shell execution, file access, process/service control, stealth, or persistence.
- Defaults to loopback HTTP; non-loopback binding requires TLS certificate and key. Use firewall restrictions and a long random bearer token.
- The Android app is not yet integrated with this agent. Secure enrollment, certificate validation and controller-side UI are future milestones.
- See `computer_agent/README.md`.


## v2.5 — Optional Windows/Linux computer agent
- Added `computer_agent/`, a Python 3.10+ foreground agent.
- Authenticated read-only inventory and three allowlisted diagnostics: system, storage, and network identity.
- No arbitrary shell execution, file access, process/service control, persistence, or stealth.
- Loopback HTTP is the default; LAN binding requires TLS certificate/key. Restrict LAN access with a host firewall and a long random bearer token.
- Not yet paired with the Android app. Secure enrollment, certificate validation and controller UI are future work.
- See `computer_agent/README.md`.


## v2.6 Router Diagnostics

The Device Control page now includes a user-authorized, read-only router
reachability check for one manually entered host. It tests TCP 80, 443, 8080
and 8443 with bounded timeouts and closes each socket. Results are explicitly
labelled as reachability only; there is no authentication, password guessing,
subnet scan, router configuration control, or connected-client inventory.
See `docs/ROUTER_DIAGNOSTICS_v2.6.md`.


## v2.7 Unified Device Control Centre

Adds a capability overview in the Device Control area and a session-only
activity log. The overview clearly identifies the Android companion and
computer agent as not yet paired/integrated, while showing the router, BLE and
ONVIF tools with their platform limitations. Router-check outcomes are added
to the in-memory log. See `docs/UNIFIED_DEVICE_CONTROL_v2.7.md`.


## v2.8 Secure computer-agent pairing

Adds a user-initiated HTTPS pairing panel for the optional computer agent.
The app authenticates with the configured bearer token against `/health` and
`/v1/inventory`, uses standard Android TLS validation, and clears the token
when disconnected or the screen is disposed. No token persistence or remote
commands are included. See `docs/SECURE_PAIRING_v2.8.md`.


## v2.9 Android companion enrollment

Adds a user-mediated offline enrollment bundle generated by the separate
Android companion and imported into the main app. The main app stores a local
record and supports local revocation. This is not a live pairing handshake;
the enrollment secret is stored in ordinary SharedPreferences in this
milestone. See `docs/ANDROID_COMPANION_ENROLLMENT_v2.9.md`.
