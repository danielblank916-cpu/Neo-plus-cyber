# NEO CYBER — Android standalone starter (0.2)

NEO CYBER is designed for a non-rooted Android phone and does not require a laptop at runtime.

## Implemented
- Flutter dark mobile dashboard and navigation.
- Bounded TCP connect scanner with explicit authorization acknowledgement and stop control.
- Passive HTTP(S) security-header checker.
- Local assessment history using SharedPreferences.
- Original uploaded Python modules preserved in `legacy_engine/` for review and future adaptation.

## Not implemented yet
The packet capture/VPN service, HTTP interception proxy, full web crawler/passive scanner, AI service, report export and lab validation remain roadmap items. The module names describe planned Android-compatible functionality, not bundled copies of Wireshark, Burp Suite, OWASP ZAP or Metasploit. Android's unrooted permission model limits low-level packet capture, Wi-Fi monitor mode, injection and some scan types.

## Build on Android
Install Flutter SDK and Android Studio with Android SDK. In this folder:

```bash
flutter pub get
flutter create --platforms=android --org com.neocyber .
flutter run
```

If the Android platform folder already exists, skip `flutter create`.

Add to `android/app/src/main/AndroidManifest.xml`, directly under `<manifest>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

Build a release APK:

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`.

## Safety
Only assess systems you own or have explicit permission to test. The authorization checkbox is a reminder, not proof of permission. This starter intentionally excludes exploitation, credential attacks, stealth and unauthorized access.
