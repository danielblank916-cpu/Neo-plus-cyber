import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const NeoCyberApp());

const _bg = Color(0xFF080D18);
const _panel = Color(0xFF111A2B);
const _blue = Color(0xFF36A7FF);
const _headers = <String, String>{
  'Strict-Transport-Security': 'Enforces HTTPS for supported browsers',
  'Content-Security-Policy': 'Helps reduce cross-site scripting and injection risk',
  'X-Frame-Options': 'Helps prevent clickjacking',
  'X-Content-Type-Options': 'Prevents MIME-type sniffing',
  'Referrer-Policy': 'Controls referrer information sent by the browser',
  'Permissions-Policy': 'Restricts access to browser features',
};

class NeoCyberApp extends StatelessWidget {
  const NeoCyberApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NEO CYBER',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: _bg,
          colorScheme: ColorScheme.fromSeed(
            seedColor: _blue,
            brightness: Brightness.dark,
          ),
          cardTheme: const CardThemeData(color: _panel, elevation: 0),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: _panel,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        home: const HomeShell(),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      DashboardPage(onOpenScanner: () => setState(() => index = 1),
          onOpenWebCheck: () => setState(() => index = 2)),
      const ScannerPage(),
      const WebCheckPage(),
      const HistoryPage(),
      const AboutPage(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        backgroundColor: _panel,
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.radar), label: 'Ports'),
          NavigationDestination(icon: Icon(Icons.language), label: 'Web'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'About'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  final VoidCallback onOpenScanner;
  final VoidCallback onOpenWebCheck;
  const DashboardPage({super.key, required this.onOpenScanner, required this.onOpenWebCheck});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 12),
          Row(children: [
            Container(width: 46, height: 46,
              decoration: BoxDecoration(color: _blue.withOpacity(.14), borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.shield_moon, color: _blue, size: 28)),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('NEO CYBER', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              Text('Mobile Security Assessment', style: TextStyle(color: Colors.white60)),
            ])),
            const Chip(label: Text('ANDROID')),
          ]),
          const SizedBox(height: 26),
          Container(padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF123B66), Color(0xFF14213A)]), borderRadius: BorderRadius.circular(22)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('YOUR MOBILE SECURITY LAB', style: TextStyle(color: Colors.white70, letterSpacing: 1.1, fontSize: 11)),
              SizedBox(height: 10), Text('Assess. Understand. Secure.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
              SizedBox(height: 8), Text('Run permitted checks directly from your Android phone. No root access or laptop required for supported features.', style: TextStyle(color: Colors.white70, height: 1.4)),
            ])),
          const SizedBox(height: 22),
          const Text('WORKING MODULES', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
          const SizedBox(height: 12),
          GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.25, children: [
            ToolTile(icon: Icons.radar, title: 'TCP Port Scanner', subtitle: 'Bounded connect scan', status: 'READY', onTap: onOpenScanner),
            ToolTile(icon: Icons.language, title: 'Web Header Check', subtitle: 'Passive HTTP checks', status: 'READY', onTap: onOpenWebCheck),
            const ToolTile(icon: Icons.graphic_eq, title: 'Packet Analyzer', subtitle: 'VPN capture design', status: 'PLANNED'),
            const ToolTile(icon: Icons.http, title: 'HTTP Proxy', subtitle: 'Request inspection', status: 'PLANNED'),
            const ToolTile(icon: Icons.bug_report_outlined, title: 'Metasploit Lab', subtitle: 'Safe lab validation', status: 'PLANNED'),
            const ToolTile(icon: Icons.psychology_outlined, title: 'NEO AI', subtitle: 'Finding explanations', status: 'PLANNED'),
          ]),
          const SizedBox(height: 16),
          const Text('Only test devices and websites you own or have explicit permission to assess.', style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      );
}

class ToolTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle, status;
  final VoidCallback? onTap;
  const ToolTile({super.key, required this.icon, required this.title, required this.subtitle, required this.status, this.onTap});

  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14),
          child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(icon, color: _blue, size: 24), const Spacer(), Text(status, style: const TextStyle(fontSize: 9, color: Colors.lightBlueAccent, fontWeight: FontWeight.bold))]),
            const Spacer(), Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
          ])),
        ),
      );
}

class ScanRecord {
  final String type, target, summary, timestamp;
  ScanRecord({required this.type, required this.target, required this.summary, required this.timestamp});
  Map<String, dynamic> toJson() => {'type': type, 'target': target, 'summary': summary, 'timestamp': timestamp};
  factory ScanRecord.fromJson(Map<String, dynamic> json) => ScanRecord(
    type: json['type'] as String? ?? 'Assessment', target: json['target'] as String? ?? '',
    summary: json['summary'] as String? ?? '', timestamp: json['timestamp'] as String? ?? '');
}

class HistoryStore {
  static const _key = 'neo_cyber_history_v1';
  static Future<void> add(ScanRecord record) async {
    final prefs = await SharedPreferences.getInstance();
    final items = prefs.getStringList(_key) ?? <String>[];
    items.insert(0, jsonEncode(record.toJson()));
    await prefs.setStringList(_key, items.take(100).toList());
  }
  static Future<List<ScanRecord>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final items = prefs.getStringList(_key) ?? <String>[];
    return items.map((s) {
      try { return ScanRecord.fromJson(jsonDecode(s) as Map<String, dynamic>); }
      catch (_) { return null; }
    }).whereType<ScanRecord>().toList();
  }
  static Future<void> clear() async => (await SharedPreferences.getInstance()).remove(_key);
}

String _now() => DateTime.now().toLocal().toString().substring(0, 16);

class ScannerPage extends StatefulWidget {
  const ScannerPage({super.key});
  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> {
  final host = TextEditingController();
  final start = TextEditingController(text: '1');
  final end = TextEditingController(text: '128');
  bool authorized = false, running = false, cancelRequested = false;
  int checked = 0;
  List<int> openPorts = [];
  String status = 'Ready';
  int total = 128;

  @override
  void dispose() { host.dispose(); start.dispose(); end.dispose(); super.dispose(); }

  Future<void> runScan() async {
    final target = host.text.trim();
    final first = int.tryParse(start.text);
    final last = int.tryParse(end.text);
    if (!authorized) { setState(() => status = 'Confirm authorization before scanning.'); return; }
    if (target.isEmpty || first == null || last == null || first < 1 || last > 65535 || first > last || last - first > 127) {
      setState(() => status = 'Enter a host and a valid range of up to 128 ports.'); return;
    }
    setState(() { running = true; cancelRequested = false; checked = 0; openPorts = []; total = last - first + 1; status = 'Scanning $target...'; });
    final found = <int>[];
    for (var p = first; p <= last; p++) {
      if (cancelRequested || !mounted) break;
      try {
        final socket = await Socket.connect(target, p, timeout: const Duration(milliseconds: 500));
        socket.destroy(); found.add(p);
      } on SocketException catch (_) {} on TimeoutException catch (_) {} catch (_) {}
      if (!mounted) return;
      setState(() { checked++; openPorts = List<int>.from(found); status = 'Checked $checked of $total ports'; });
    }
    final wasCancelled = cancelRequested;
    final summary = '${found.length} open port(s): ${found.isEmpty ? 'none detected' : found.join(', ')}';
    await HistoryStore.add(ScanRecord(type: 'TCP port scan', target: target, summary: wasCancelled ? 'Cancelled. $summary' : summary, timestamp: _now()));
    if (!mounted) return;
    setState(() { running = false; status = wasCancelled ? 'Scan cancelled. $summary' : 'Finished. $summary'; });
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('TCP PORT SCANNER', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6), const Text('A bounded Nmap-style TCP connect scan for explicitly authorized targets.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 20),
    TextField(controller: host, autocorrect: false, decoration: const InputDecoration(labelText: 'Target hostname or IP', hintText: 'e.g. 192.168.1.10')),
    const SizedBox(height: 12),
    Row(children: [Expanded(child: TextField(controller: start, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Start port'))), const SizedBox(width: 10), Expanded(child: TextField(controller: end, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'End port'))]),
    const SizedBox(height: 12),
    Card(child: CheckboxListTile(value: authorized, onChanged: running ? null : (v) => setState(() => authorized = v ?? false), title: const Text('I own this target or have written permission to test it.'), controlAffinity: ListTileControlAffinity.leading)),
    const SizedBox(height: 14),
    Row(children: [Expanded(child: FilledButton.icon(onPressed: running ? null : runScan, icon: const Icon(Icons.play_arrow), label: const Text('Start scan'))), if (running) ...[const SizedBox(width: 10), OutlinedButton.icon(onPressed: () => setState(() { cancelRequested = true; status = 'Stopping after current connection check...'; }), icon: const Icon(Icons.stop), label: const Text('Stop')]]]),
    const SizedBox(height: 14),
    if (running) LinearProgressIndicator(value: total == 0 ? 0 : (checked / total).clamp(0.0, 1.0)),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('SCAN STATUS', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), Text(status), const SizedBox(height: 12),
      Text('Open ports: ${openPorts.isEmpty ? 'None detected' : openPorts.join(', ')}', style: const TextStyle(color: Colors.lightBlueAccent)),
    ]))),
    const SizedBox(height: 12),
    const Text('This is a TCP connect scanner, not the full Nmap engine. Android permissions, routing and target firewalls affect results.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4)),
  ]);
}

class WebCheckPage extends StatefulWidget {
  const WebCheckPage({super.key});
  @override
  State<WebCheckPage> createState() => _WebCheckPageState();
}

class _WebCheckPageState extends State<WebCheckPage> {
  final urlController = TextEditingController();
  bool authorized = false, running = false;
  Uri? finalUri;
  Map<String, String> present = {};
  List<String> missing = [];
  String status = 'Ready';
  int? score;

  @override
  void dispose() { urlController.dispose(); super.dispose(); }

  Future<void> checkHeaders() async {
    if (!authorized) { setState(() => status = 'Confirm authorization before testing.'); return; }
    var raw = urlController.text.trim();
    if (raw.isEmpty) { setState(() => status = 'Enter a website hostname or URL.'); return; }
    if (!raw.contains('://')) raw = 'https://$raw';
    final uri = Uri.tryParse(raw);
    if (uri == null || !uri.hasAuthority || (uri.scheme != 'https' && uri.scheme != 'http')) {
      setState(() => status = 'Enter a valid HTTP or HTTPS URL.'); return;
    }
    setState(() { running = true; status = 'Checking security headers...'; present = {}; missing = []; score = null; finalUri = null; });
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10)..userAgent = 'NEO-CYBER-Mobile-Security-Checker/0.2';
    try {
      final request = await client.getUrl(uri).timeout(const Duration(seconds: 12));
      final response = await request.close().timeout(const Duration(seconds: 12));
      final found = <String, String>{};
      final absent = <String>[];
      for (final header in _headers.keys) {
        final value = response.headers.value(header);
        if (value != null) { found[header] = value; } else { absent.add(header); }
      }
      final resolved = response.redirects.isNotEmpty
          ? uri.resolveUri(response.redirects.last.location)
          : uri;
      await response.drain<void>();
      final calculated = (found.length * 100 / _headers.length).round();
      await HistoryStore.add(ScanRecord(type: 'Web header check', target: uri.host, summary: 'Header presence score: $calculated% (${found.length}/${_headers.length})', timestamp: _now()));
      if (!mounted) return;
      setState(() { present = found; missing = absent; score = calculated; finalUri = resolved; running = false; status = 'Completed. Review missing headers and site-specific requirements.'; });
    } on SocketException catch (e) {
      if (mounted) setState(() { running = false; status = 'Connection failed: ${e.message}'; });
    } on TimeoutException {
      if (mounted) setState(() { running = false; status = 'Request timed out.'; });
    } on HandshakeException {
      if (mounted) setState(() { running = false; status = 'TLS certificate or handshake error.'; });
    } catch (e) {
      if (mounted) setState(() { running = false; status = 'Request failed: $e'; });
    } finally { client.close(force: true); }
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('WEB SECURITY CHECK', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6), const Text('Passive inspection of common HTTP security headers. This does not prove a site is secure or vulnerable.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 20),
    TextField(controller: urlController, autocorrect: false, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Website URL', hintText: 'https://example.com')),
    const SizedBox(height: 12),
    Card(child: CheckboxListTile(value: authorized, onChanged: running ? null : (v) => setState(() => authorized = v ?? false), title: const Text('I own this website or have permission to assess it.'), controlAffinity: ListTileControlAffinity.leading)),
    const SizedBox(height: 14),
    FilledButton.icon(onPressed: running ? null : checkHeaders, icon: Icon(running ? Icons.hourglass_top : Icons.security), label: Text(running ? 'Checking...' : 'Check security headers')),
    const SizedBox(height: 14),
    if (running) const LinearProgressIndicator(),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('ASSESSMENT RESULT', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), Text(status),
      if (score != null) ...[
        const SizedBox(height: 12), Text('Header presence score: $score%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.lightBlueAccent)),
        if (finalUri != null) Text('Final URL: $finalUri', style: const TextStyle(color: Colors.white54, fontSize: 11)),
        const SizedBox(height: 12), const Text('PRESENT', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.greenAccent)),
        ...present.entries.map((e) => Padding(padding: const EdgeInsets.only(top: 6), child: Text('✓ ${e.key}: ${e.value}', style: const TextStyle(fontSize: 12)))),
        const SizedBox(height: 12), const Text('MISSING', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orangeAccent)),
        ...missing.map((h) => Padding(padding: const EdgeInsets.only(top: 6), child: Text('• $h — ${_headers[h]}', style: const TextStyle(fontSize: 12)))),
      ],
    ]))),
    const SizedBox(height: 12),
    const Text('A missing header is not automatically a vulnerability. Review the application architecture and deployment requirements before drawing conclusions.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4)),
  ]);
}

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  late Future<List<ScanRecord>> records;
  @override
  void initState() { super.initState(); records = HistoryStore.load(); }
  void refresh() => setState(() => records = HistoryStore.load());

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    Row(children: [const Expanded(child: Text('SCAN HISTORY', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))), IconButton(onPressed: refresh, icon: const Icon(Icons.refresh)), IconButton(onPressed: () async { await HistoryStore.clear(); refresh(); }, icon: const Icon(Icons.delete_outline))]),
    const SizedBox(height: 10),
    FutureBuilder<List<ScanRecord>>(future: records, builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()));
      final items = snapshot.data ?? <ScanRecord>[];
      if (items.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('No assessments saved yet. Completed scans will appear here.')));
      return Column(
        children: items.map((r) => Card(
          child: ListTile(
            leading: const Icon(Icons.fact_check_outlined, color: _blue),
            title: Text(r.type),
            subtitle: Text('${r.target}\n${r.summary}\n${r.timestamp}'),
            isThreeLine: true,
          ),
        )).toList(),
      );
    }),
  ]);
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [
    Text('ABOUT NEO CYBER', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    SizedBox(height: 14),
    Text('NEO CYBER is an Android-first security assessment app designed for non-rooted phones. It does not require a laptop.'),
    SizedBox(height: 16), Text('Implemented in this milestone', style: TextStyle(fontWeight: FontWeight.bold)),
    SizedBox(height: 8), Text('• Bounded TCP connect scanner with stop control.\n• Passive HTTP security-header checker.\n• Local assessment history.'),
    SizedBox(height: 16), Text('Planned modules', style: TextStyle(fontWeight: FontWeight.bold)),
    SizedBox(height: 8), Text('• VPN-based packet capture with explicit Android consent.\n• Local HTTP proxy and request viewer.\n• Expanded passive web assessment.\n• AI-assisted finding explanations.\n• Safe, controlled lab validation.'),
    SizedBox(height: 16), Text('The app only performs supported functions within Android permissions. It does not provide unrestricted Wireshark, Burp Suite, OWASP ZAP or Metasploit desktop functionality.'),
    SizedBox(height: 16), Text('Only assess systems you own or have explicit permission to test.'),
  ]);
}
