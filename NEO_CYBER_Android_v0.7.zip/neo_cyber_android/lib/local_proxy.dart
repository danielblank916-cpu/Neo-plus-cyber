import 'dart:async';
import 'dart:convert';
import 'dart:io';

class ProxyEvent {
  final DateTime time;
  final String method;
  final String host;
  final String target;
  final String note;

  ProxyEvent({required this.time, required this.method, required this.host,
    required this.target, required this.note});
}

/// Explicit, loopback-only HTTP forward proxy.
/// HTTPS CONNECT is passed through as an opaque tunnel: TLS is not intercepted
/// and certificates are never replaced. No request bodies are retained.
class LocalProxyController {
  static const int port = 8888;
  ServerSocket? _server;
  final Set<Socket> _clients = <Socket>{};
  final List<ProxyEvent> events = <ProxyEvent>[];
  void Function()? onChanged;
  bool get running => _server != null;

  Future<void> start() async {
    if (running) return;
    _server = await ServerSocket.bind(InternetAddress.loopbackIPv4, port,
        shared: false);
    _server!.listen(_accept, onError: (_) => stop());
    onChanged?.call();
  }

  Future<void> stop() async {
    final server = _server;
    _server = null;
    await server?.close();
    for (final socket in _clients.toList()) {
      socket.destroy();
    }
    _clients.clear();
    onChanged?.call();
  }

  void clearEvents() {
    events.clear();
    onChanged?.call();
  }

  void _record(String method, String host, String target, String note) {
    events.insert(0, ProxyEvent(time: DateTime.now(), method: method,
        host: host, target: target, note: note));
    if (events.length > 150) events.removeLast();
    onChanged?.call();
  }

  void _accept(Socket client) {
    _clients.add(client);
    client.setOption(SocketOption.tcpNoDelay, true);
    _handle(client).whenComplete(() {
      _clients.remove(client);
      client.destroy();
    });
  }

  Future<void> _handle(Socket client) async {
    final incoming = StreamIterator<List<int>>(client);
    final headerBuffer = <int>[];
    try {
      var boundary = -1;
      while (boundary < 0 && headerBuffer.length < 65536 && await incoming.moveNext()) {
        headerBuffer.addAll(incoming.current);
        boundary = _headerEnd(headerBuffer);
      }
      if (boundary < 0) {
        _record('REJECT', 'unknown', '', 'Invalid or oversized HTTP header');
        return;
      }
      final headerBytes = headerBuffer.sublist(0, boundary + 4);
      final remainder = headerBuffer.sublist(boundary + 4);
      final headerText = latin1.decode(headerBytes, allowInvalid: true);
      final lines = headerText.split('\r\n');
      if (lines.isEmpty) return;
      final requestParts = lines.first.trim().split(RegExp(r'\s+'));
      if (requestParts.length < 3) return;
      final method = requestParts[0].toUpperCase();
      final requestTarget = requestParts[1];
      final headers = <String, String>{};
      for (final line in lines.skip(1)) {
        final colon = line.indexOf(':');
        if (colon > 0) headers[line.substring(0, colon).trim().toLowerCase()] = line.substring(colon + 1).trim();
      }

      if (method == 'CONNECT') {
        final authority = Uri.parse('http://$requestTarget');
        final host = authority.host;
        final portNumber = authority.hasPort ? authority.port : 443;
        if (host.isEmpty || portNumber < 1 || portNumber > 65535) return;
        _record('CONNECT', host, '$host:$portNumber', 'Encrypted tunnel; HTTPS contents are not inspected');
        final upstream = await Socket.connect(host, portNumber,
            timeout: const Duration(seconds: 10));
        upstream.setOption(SocketOption.tcpNoDelay, true);
        client.add(utf8.encode('HTTP/1.1 200 Connection Established\r\nProxy-Agent: NEO-CYBER\r\n\r\n'));
        if (remainder.isNotEmpty) upstream.add(remainder);
        await _relay(client, incoming, upstream);
        return;
      }

      Uri? uri = Uri.tryParse(requestTarget);
      if (uri == null || !uri.hasAuthority || (uri.scheme != 'http' && uri.scheme != 'https')) {
        final hostHeader = headers['host'];
        if (hostHeader == null) return;
        uri = Uri.tryParse('http://$hostHeader$requestTarget');
      }
      if (uri == null || uri.host.isEmpty || (uri.scheme != 'http' && uri.scheme != 'https')) return;
      // This forward proxy handles ordinary HTTP requests. HTTPS uses CONNECT.
      if (uri.scheme != 'http') return;
      final host = uri.host;
      final portNumber = uri.hasPort ? uri.port : 80;
      _record(method, host, '${uri.path}${uri.hasQuery ? '?${uri.query}' : ''}', 'HTTP request forwarded; body not recorded');
      final upstream = await Socket.connect(host, portNumber,
          timeout: const Duration(seconds: 10));
      upstream.setOption(SocketOption.tcpNoDelay, true);
      final path = '${uri.path.isEmpty ? '/' : uri.path}${uri.hasQuery ? '?${uri.query}' : ''}';
      final outputHeaders = <String>[];
      for (final line in lines.skip(1)) {
        if (line.isEmpty) continue;
        final colon = line.indexOf(':');
        if (colon > 0) {
          final name = line.substring(0, colon).trim().toLowerCase();
          if (name == 'proxy-connection' || name == 'proxy-authorization' || name == 'connection') continue;
        }
        outputHeaders.add(line);
      }
      outputHeaders.add('Connection: close');
      upstream.add(utf8.encode('${requestParts[0]} $path ${requestParts[2]}\r\n${outputHeaders.join('\r\n')}\r\n\r\n'));
      if (remainder.isNotEmpty) upstream.add(remainder);
      await _relay(client, incoming, upstream);
    } catch (error) {
      _record('ERROR', 'local', '', error.toString());
    } finally {
      await incoming.cancel();
    }
  }

  Future<void> _relay(Socket client, StreamIterator<List<int>> incoming,
      Socket upstream) async {
    final responseDone = Completer<void>();
    late StreamSubscription<List<int>> responseSubscription;
    responseSubscription = upstream.listen((data) {
      try { client.add(data); } catch (_) {}
    }, onError: (_) {
      if (!responseDone.isCompleted) responseDone.complete();
    }, onDone: () {
      try { client.close(); } catch (_) {}
      if (!responseDone.isCompleted) responseDone.complete();
    });
    try {
      while (await incoming.moveNext()) {
        upstream.add(incoming.current);
      }
      await upstream.flush();
    } catch (_) {
      // Client disconnects and upstream resets are reflected in the event log.
    } finally {
      upstream.destroy();
    }
    try {
      await responseDone.future.timeout(const Duration(seconds: 20));
    } catch (_) {
      upstream.destroy();
    }
    await responseSubscription.cancel();
  }

  int _headerEnd(List<int> bytes) {
    for (var i = 3; i < bytes.length; i++) {
      if (bytes[i - 3] == 13 && bytes[i - 2] == 10 &&
          bytes[i - 1] == 13 && bytes[i] == 10) return i - 3;
    }
    return -1;
  }
}

class LocalProxyPage extends StatefulWidget {
  const LocalProxyPage({super.key});
  @override
  State<LocalProxyPage> createState() => _LocalProxyPageState();
}

class _LocalProxyPageState extends State<LocalProxyPage> {
  late final LocalProxyController controller;
  String status = 'Stopped';

  @override
  void initState() {
    super.initState();
    controller = LocalProxyController()..onChanged = () {
      if (mounted) setState(() => status = controller.running ? 'Listening on 127.0.0.1:${LocalProxyController.port}' : 'Stopped');
    };
  }

  @override
  void dispose() {
    controller.onChanged = null;
    controller.stop();
    super.dispose();
  }

  Future<void> _toggle() async {
    try {
      if (controller.running) {
        await controller.stop();
      } else {
        await controller.start();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not start local proxy: $e')));
    }
  }

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('LOCAL HTTP PROXY', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      const Text('An explicit, on-device forward proxy for traffic from a browser or app that you configure to use it.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(controller.running ? Icons.wifi_tethering : Icons.wifi_tethering_off, color: controller.running ? Colors.greenAccent : Colors.white54), const SizedBox(width: 10), Expanded(child: Text(status, style: const TextStyle(fontWeight: FontWeight.bold))), Container(width: 9, height: 9, decoration: BoxDecoration(shape: BoxShape.circle, color: controller.running ? Colors.greenAccent : Colors.white30))]),
        const SizedBox(height: 14),
        const SelectableText('Proxy host: 127.0.0.1\nProxy port: 8888', style: TextStyle(fontSize: 16, height: 1.6, color: Colors.lightBlueAccent, fontWeight: FontWeight.w600)),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _toggle, icon: Icon(controller.running ? Icons.stop : Icons.play_arrow), label: Text(controller.running ? 'Stop proxy' : 'Start proxy'))),
      ]))),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('SET UP A BROWSER', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
        SizedBox(height: 8),
        Text('1. Start the proxy above.\n2. In your browser or Wi-Fi network proxy settings, set the proxy host to 127.0.0.1 and port to 8888.\n3. Browse only sites you own or are authorized to test.\n4. Return here to review connection metadata.', style: TextStyle(color: Colors.white70, height: 1.55)),
      ]))),
      const SizedBox(height: 12),
      Card(color: const Color(0xFF332817), child: Padding(padding: const EdgeInsets.all(14), child: const Text('HTTPS uses CONNECT tunnelling. NEO CYBER records the destination host but does not decrypt HTTPS, install certificates, or capture passwords and page contents. This proxy listens only on the phone’s loopback interface and is not exposed to your Wi-Fi network.', style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.45)))),
      const SizedBox(height: 18),
      Row(children: [const Expanded(child: Text('CONNECTION LOG', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1))), TextButton.icon(onPressed: controller.events.isEmpty ? null : () => setState(controller.clearEvents), icon: const Icon(Icons.delete_outline, size: 17), label: const Text('Clear'))]),
      if (controller.events.isEmpty)
        const Padding(padding: EdgeInsets.symmetric(vertical: 22), child: Center(child: Text('No proxy connections recorded.', style: TextStyle(color: Colors.white54))))
      else
        ...controller.events.map((event) => Card(child: ListTile(
          dense: true,
          leading: CircleAvatar(radius: 17, child: Text(event.method.length > 4 ? event.method.substring(0, 4) : event.method, style: const TextStyle(fontSize: 8))),
          title: Text(event.host, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
          subtitle: Text('${event.target}\n${event.note}\n${event.time.toLocal()}', style: const TextStyle(fontSize: 10, height: 1.35)),
          isThreeLine: true,
        ))),
    ],
  );
}
