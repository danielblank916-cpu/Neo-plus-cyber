# NEO CYBER project status

## Confirmed requirements
- Android only; standalone phone operation.
- No root required.
- No laptop or Kali installation required at runtime.
- Flutter UI with Android-specific Kotlin integration where required.
- Local-first operation for supported assessment features.

## Milestone 0.3
- [x] Flutter dark dashboard and navigation
- [x] Bounded TCP connect scanner (up to 128 ports per run)
- [x] Explicit authorization acknowledgement
- [x] Stop control for an active port scan
- [x] Passive HTTP security-header checker
- [x] Local assessment history using SharedPreferences
- [x] Offline classic Ethernet PCAP reader: IPv4, TCP, UDP, ICMP, ARP metadata
- [x] Import PCAP from Android document picker; no root/live capture required
- [x] Preserve original Python toolkit under `legacy_engine/`
- [ ] Verify Android build on Flutter/Android SDK
- [ ] Add report export (JSON/PDF)
- [ ] Add optional Android VPN-based live packet capture with explicit consent
- [ ] Add local HTTP proxy and request/response viewer
- [ ] Add broader passive web checks
- [ ] Add NEO AI integration

## Packet analyzer scope
- Reads classic PCAP files with Ethernet link type.
- Decodes IPv4 source/destination addresses and TCP/UDP ports, plus ICMP and ARP labels.
- Displays packet lengths and protocol counts; does not display payload contents.
- Does not capture live traffic, decrypt HTTPS, or implement full Wireshark functionality.
- PCAPNG, non-Ethernet link types and IPv6 address decoding are not supported yet.
- Shows at most 300 packet rows in the UI; parses at most 10,000 records per import.

## Important compatibility notes
- The scanner is a conservative TCP connect scanner, not the full Nmap engine.
- The web checker performs a single HTTP(S) request and checks common response headers; it is not a full OWASP ZAP scan.
- The packet analyzer is an offline PCAP metadata viewer, not a live Wireshark replacement.
- HTTPS interception, Metasploit-compatible validation and AI are not implemented yet.
- Android unrooted permissions limit low-level packet capture, monitor mode, injection and some scan techniques.

## Build
Install Flutter and Android Studio with Android SDK. From this directory run:

```bash
flutter pub get
flutter create --platforms=android --org com.neocyber .
flutter run
```

If the Android platform folder already exists, do not recreate it; just run `flutter pub get` and `flutter run`.

Add these permissions inside `android/app/src/main/AndroidManifest.xml`, directly under `<manifest>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

Build an APK with:

```bash
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Safety
Use only on systems you own or have explicit permission to assess. The app's authorization checkbox is a reminder, not proof of permission. This starter does not implement exploitation, credential attacks, stealth or unauthorized access.

## Sample data
- `sample_captures/demo_ethernet.pcap` is a synthetic two-packet Ethernet capture for testing the offline viewer.
