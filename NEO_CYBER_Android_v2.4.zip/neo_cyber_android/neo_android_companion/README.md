# NEO Android Companion — v2.4 foundation

A separate Android-first companion app source project for devices enrolled into NEO CYBER.

## Implemented
- Reads manufacturer, model, Android release, SDK level, security patch level and physical-device flag using Android device-information APIs.
- Displays the information locally.
- Shares a device report only after the user taps **Share device report** and chooses a destination.
- No background service, network listener, remote command execution, camera/microphone access, file browsing, or automatic data transmission.

## Build
Install Flutter and Android Studio with Android SDK. From this directory run `flutter pub get`, then `flutter create --platforms=android --org com.neocyber .` and `flutter run`. If Android scaffolding already exists, do not recreate it.

## Integration boundary
This is the companion application's first foundation milestone, not yet a paired remote-control client. Secure enrollment, mutual authentication, controller discovery, and user-approved data exchange require a reviewed transport and threat model and are not implemented here.
