import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// User-initiated WS-Discovery probe for ONVIF devices on the local Wi-Fi/LAN.
/// Discovery only: it does not authenticate, stream video, or change settings.
class OnvifDiscoveryPanel extends StatefulWidget {
  const OnvifDiscoveryPanel({super.key});

  @override
  State<OnvifDiscoveryPanel> createState() => _OnvifDiscoveryPanelState();
}

class _OnvifDiscoveryPanelState extends State<OnvifDiscoveryPanel> {
  static final InternetAddress _group = InternetAddress('239.255.255.250');
  static const int _port = 3702;
  bool _scanning = false;
  String? _status;
  final Map<String, OnvifEndpoint> _found = {};

  Future<void> _discover() async {
    if (_scanning) return;
    setState(() {
      _scanning = true;
      _status = 'Searching the connected local network for ONVIF announcements…';
      _found.clear();
    });

    RawDatagramSocket? socket;
    StreamSubscription<RawSocketEvent>? subscription;
    try {
      socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0,
          reuseAddress: true, reusePort: false);
      socket.broadcastEnabled = true;
      socket.multicastHops = 2;
      socket.joinMulticast(_group);

      const probe = '''<?xml version="1.0" encoding="UTF-8"?>
<e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope" xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" xmlns:dn="http://www.onvif.org/ver10/network/wsdl">
<e:Header><w:MessageID>urn:uuid:9b8e1f5a-2a63-4a7f-a8c1-4e6d4f2b7c10</w:MessageID><w:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To><w:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action></e:Header>
<e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe></e:Body></e:Envelope>''';
      final payload = utf8.encode(probe);
      socket.send(payload, _group, _port);

      final done = Completer<void>();
      subscription = socket.listen((event) {
        if (event != RawSocketEvent.read) return;
        Datagram? datagram;
        while ((datagram = socket!.receive()) != null) {
          final body = utf8.decode(datagram!.data, allowMalformed: true);
          final xaddrs = _tag(body, 'XAddrs');
          if (xaddrs.isEmpty) continue;
          final scopes = _tag(body, 'Scopes');
          final types = _tag(body, 'Types');
          for (final address in xaddrs.split(RegExp(r'\s+'))) {
            final uri = Uri.tryParse(address.trim());
            if (uri == null || !uri.hasAuthority || !{'http', 'https'}.contains(uri.scheme)) continue;
            final item = OnvifEndpoint(uri.toString(), datagram!.address.address,
                scopes.isEmpty ? 'ONVIF camera / video device' : scopes,
                types.isEmpty ? 'Network video transmitter' : types);
            _found[item.xaddr] = item;
          }
          if (mounted) setState(() {});
        }
      }, onError: (Object error) {
        if (!done.isCompleted) done.completeError(error);
      });
      await Future<void>.delayed(const Duration(seconds: 6));
      if (!done.isCompleted) done.complete();
      await done.future;
      if (mounted) {
        setState(() => _status = _found.isEmpty
            ? 'No ONVIF response received. Check that you are on the same Wi-Fi/LAN and that the camera supports ONVIF discovery.'
            : 'Discovery finished. Found ${_found.length} ONVIF service endpoint(s).');
      }
    } on SocketException catch (e) {
      if (mounted) setState(() => _status = 'Local network discovery failed: ${e.message}');
    } catch (e) {
      if (mounted) setState(() => _status = 'Discovery could not complete: $e');
    } finally {
      await subscription?.cancel();
      socket?.close();
      if (mounted) setState(() => _scanning = false);
    }
  }

  static String _tag(String xml, String name) {
    final match = RegExp('<(?:[A-Za-z0-9_]+:)?$name\\b[^>]*>([\\s\\S]*?)</(?:[A-Za-z0-9_]+:)?$name\\s*>', caseSensitive: false).firstMatch(xml);
    return match?.group(1)?.replaceAll(RegExp(r'<[^>]+>'), '').trim() ?? '';
  }

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.videocam_outlined, color: Color(0xFF36A7FF)),
              const SizedBox(width: 8),
              const Expanded(child: Text('ONVIF CAMERA DISCOVERY', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: .6))),
              FilledButton.icon(
                onPressed: _scanning ? null : _discover,
                icon: _scanning
                    ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.radar, size: 17),
                label: Text(_scanning ? 'SEARCHING' : 'DISCOVER'),
              ),
            ]),
            const SizedBox(height: 8),
            const Text('Sends a standard ONVIF WS-Discovery probe to the local network multicast group. It only identifies devices that respond; it does not log in, access video, or modify camera settings.', style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.4)),
            if (_status != null) ...[
              const SizedBox(height: 10),
              Text(_status!, style: const TextStyle(color: Colors.lightBlueAccent, fontSize: 12)),
            ],
            ..._found.values.map((device) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.camera_alt_outlined, color: Colors.lightBlueAccent),
                  title: Text(device.xaddr, style: const TextStyle(fontSize: 12), maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text('Responded from ${device.sourceIp}\n${device.scopes}', maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: Colors.white60)),
                  trailing: IconButton(tooltip: 'Copy service URL', icon: const Icon(Icons.copy), onPressed: () {
                    Clipboard.setData(ClipboardData(text: device.xaddr));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ONVIF service URL copied.')));
                  }),
                )),
            const SizedBox(height: 4),
            const Text('Compatibility: devices must support ONVIF WS-Discovery and multicast must be allowed by the Wi-Fi access point and Android. Some guest networks block multicast. A discovered endpoint is not proof that credentials or camera functions are available.', style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.35)),
          ]),
        ),
      );
}

class OnvifEndpoint {
  final String xaddr;
  final String sourceIp;
  final String scopes;
  final String types;
  const OnvifEndpoint(this.xaddr, this.sourceIp, this.scopes, this.types);
}
