# NEO CYBER v2.3 — ONVIF and IoT discovery

## Included
- User-initiated ONVIF WS-Discovery probe from the Android app to `239.255.255.250:3702/UDP`.
- Parses ONVIF `XAddrs`, responding source IP, and advertised scope/type metadata.
- Displays discovered service URLs and allows copying a URL for later authenticated setup.
- Discovery is read-only. It does not request credentials, retrieve video, change camera settings, or send PTZ commands.
- Existing manual IoT/router/camera inventory and bounded TCP reachability checks remain available.

## Android/network requirements
- Ensure `android.permission.INTERNET` is declared in `android/app/src/main/AndroidManifest.xml`.
- The phone and camera must be on the same local network/VLAN, and the access point must pass WS-Discovery multicast traffic.
- Some Android Wi-Fi configurations and guest networks filter multicast. In that case discovery can return no results even when the camera is online. This source release does not include a native Android Wi-Fi multicast-lock implementation.
- The ONVIF endpoint returned by discovery is untrusted network data. Review it before opening or enrolling it. Discovery does not establish that the endpoint is reachable over HTTP(S), that credentials are valid, or that the device is fully ONVIF-conformant.

## Not included
- Camera login, RTSP video playback, snapshots, PTZ movement, configuration writes, or firmware operations.
- Universal IoT control. Smart plugs, lights, sensors, and routers use vendor- or protocol-specific APIs and must be integrated individually with authenticated, user-approved operations.
- Automatic scanning of arbitrary public IP ranges. The probe is sent only to the standard local multicast group.

## Validation
Source-level review and ZIP integrity checks only. Flutter analyzer/build and physical Android camera/network testing are required before treating this as a tested release. No APK is included.
