import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const NeoCyberApp());

const _bg = Color(0xFF080D18);
const _panel = Color(0xFF111A2B);
const _blue = Color(0xFF36A7FF);
const _headers = <String, String>{
  'Strict-Transport-Security': 'Enforces HTTPS for supported browsers',
  'Content-Security-Policy': 'Helps reduce cross-site scripting and injection risk',
  'X-Frame-Options': 'Helps prevent clickjacking',
  'X-Content-Type-Options': 'Prevents MIME-type sniffing',
  'Referrer-Policy': 'Controls referrer information sent by the browser',
  'Permissions-Policy': 'Restricts access to browser features',
};

class NeoCyberApp extends StatelessWidget {
  const NeoCyberApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NEO CYBER',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: _bg,
          colorScheme: ColorScheme.fromSeed(
            seedColor: _blue,
            brightness: Brightness.dark,
          ),
          cardTheme: const CardThemeData(color: _panel, elevation: 0),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: _panel,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        home: const HomeShell(),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      DashboardPage(onOpenScanner: () => setState(() => index = 1),
          onOpenWebCheck: () => setState(() => index = 2),
          onOpenPackets: () => setState(() => index = 3),
          onOpenProxy: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const HttpInspectorPage()))),
      const ScannerPage(),
      const WebCheckPage(),
      const PacketAnalyzerPage(),
      const HistoryPage(),
      const AboutPage(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        backgroundColor: _panel,
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.radar), label: 'Ports'),
          NavigationDestination(icon: Icon(Icons.language), label: 'Web'),
          NavigationDestination(icon: Icon(Icons.graphic_eq), label: 'Packets'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'About'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  final VoidCallback onOpenScanner;
  final VoidCallback onOpenWebCheck;
  final VoidCallback onOpenPackets;
  final VoidCallback onOpenProxy;
  const DashboardPage({super.key, required this.onOpenScanner, required this.onOpenWebCheck, required this.onOpenPackets, required this.onOpenProxy});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 12),
          Row(children: [
            Container(width: 46, height: 46,
              decoration: BoxDecoration(color: _blue.withOpacity(.14), borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.shield_moon, color: _blue, size: 28)),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('NEO CYBER', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              Text('Mobile Security Assessment', style: TextStyle(color: Colors.white60)),
            ])),
            const Chip(label: Text('ANDROID')),
          ]),
          const SizedBox(height: 26),
          Container(padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF123B66), Color(0xFF14213A)]), borderRadius: BorderRadius.circular(22)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('YOUR MOBILE SECURITY LAB', style: TextStyle(color: Colors.white70, letterSpacing: 1.1, fontSize: 11)),
              SizedBox(height: 10), Text('Assess. Understand. Secure.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
              SizedBox(height: 8), Text('Run permitted checks directly from your Android phone. No root access or laptop required for supported features.', style: TextStyle(color: Colors.white70, height: 1.4)),
            ])),
          const SizedBox(height: 22),
          const Text('AVAILABLE TOOLS', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
          const SizedBox(height: 12),
          GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.25, children: [
            ToolTile(icon: Icons.radar, title: 'TCP Port Scanner', subtitle: 'Bounded connect scan', status: 'READY', onTap: onOpenScanner),
            ToolTile(icon: Icons.language, title: 'Web Header Check', subtitle: 'Passive HTTP checks', status: 'READY', onTap: onOpenWebCheck),
            ToolTile(icon: Icons.graphic_eq, title: 'Packet Analyzer', subtitle: 'Import and inspect PCAP files', status: 'READY', onTap: onOpenPackets),
            ToolTile(icon: Icons.http, title: 'HTTP Inspector', subtitle: 'Manual request / response', status: 'READY', onTap: onOpenProxy),
          ]),
          const SizedBox(height: 16),
          const Text('Only test devices and websites you own or have explicit permission to assess.', style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      );
}

class ToolTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle, status;
  final VoidCallback? onTap;
  const ToolTile({super.key, required this.icon, required this.title, required this.subtitle, required this.status, this.onTap});

  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14),
          child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(icon, color: _blue, size: 24), const Spacer(), Text(status, style: const TextStyle(fontSize: 9, color: Colors.lightBlueAccent, fontWeight: FontWeight.bold))]),
            const Spacer(), Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
          ])),
        ),
      );
}

class ScanRecord {
  final String type, target, summary, timestamp;
  ScanRecord({required this.type, required this.target, required this.summary, required this.timestamp});
  Map<String, dynamic> toJson() => {'type': type, 'target': target, 'summary': summary, 'timestamp': timestamp};
  factory ScanRecord.fromJson(Map<String, dynamic> json) => ScanRecord(
    type: json['type'] as String? ?? 'Assessment', target: json['target'] as String? ?? '',
    summary: json['summary'] as String? ?? '', timestamp: json['timestamp'] as String? ?? '');
}

class HistoryStore {
  static const _key = 'neo_cyber_history_v1';
  static Future<void> add(ScanRecord record) async {
    final prefs = await SharedPreferences.getInstance();
    final items = prefs.getStringList(_key) ?? <String>[];
    items.insert(0, jsonEncode(record.toJson()));
    await prefs.setStringList(_key, items.take(100).toList());
  }
  static Future<List<ScanRecord>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final items = prefs.getStringList(_key) ?? <String>[];
    return items.map((s) {
      try { return ScanRecord.fromJson(jsonDecode(s) as Map<String, dynamic>); }
      catch (_) { return null; }
    }).whereType<ScanRecord>().toList();
  }
  static Future<void> clear() async => (await SharedPreferences.getInstance()).remove(_key);
}

String _now() => DateTime.now().toLocal().toString().substring(0, 16);

class ScannerPage extends StatefulWidget {
  const ScannerPage({super.key});
  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> {
  final host = TextEditingController();
  final start = TextEditingController(text: '1');
  final end = TextEditingController(text: '128');
  bool authorized = false, running = false, cancelRequested = false;
  int checked = 0;
  List<int> openPorts = [];
  String status = 'Ready';
  int total = 128;

  @override
  void dispose() { host.dispose(); start.dispose(); end.dispose(); super.dispose(); }

  Future<void> runScan() async {
    final target = host.text.trim();
    final first = int.tryParse(start.text);
    final last = int.tryParse(end.text);
    if (!authorized) { setState(() => status = 'Confirm authorization before scanning.'); return; }
    if (target.isEmpty || first == null || last == null || first < 1 || last > 65535 || first > last || last - first > 127) {
      setState(() => status = 'Enter a host and a valid range of up to 128 ports.'); return;
    }
    setState(() { running = true; cancelRequested = false; checked = 0; openPorts = []; total = last - first + 1; status = 'Scanning $target...'; });
    final found = <int>[];
    for (var p = first; p <= last; p++) {
      if (cancelRequested || !mounted) break;
      try {
        final socket = await Socket.connect(target, p, timeout: const Duration(milliseconds: 500));
        socket.destroy(); found.add(p);
      } on SocketException catch (_) {} on TimeoutException catch (_) {} catch (_) {}
      if (!mounted) return;
      setState(() { checked++; openPorts = List<int>.from(found); status = 'Checked $checked of $total ports'; });
    }
    final wasCancelled = cancelRequested;
    final summary = '${found.length} open port(s): ${found.isEmpty ? 'none detected' : found.join(', ')}';
    await HistoryStore.add(ScanRecord(type: 'TCP port scan', target: target, summary: wasCancelled ? 'Cancelled. $summary' : summary, timestamp: _now()));
    if (!mounted) return;
    setState(() { running = false; status = wasCancelled ? 'Scan cancelled. $summary' : 'Finished. $summary'; });
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('TCP PORT SCANNER', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6), const Text('A bounded Nmap-style TCP connect scan for explicitly authorized targets.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 20),
    TextField(controller: host, autocorrect: false, decoration: const InputDecoration(labelText: 'Target hostname or IP', hintText: 'e.g. 192.168.1.10')),
    const SizedBox(height: 12),
    Row(children: [Expanded(child: TextField(controller: start, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Start port'))), const SizedBox(width: 10), Expanded(child: TextField(controller: end, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'End port'))]),
    const SizedBox(height: 12),
    Card(child: CheckboxListTile(value: authorized, onChanged: running ? null : (v) => setState(() => authorized = v ?? false), title: const Text('I own this target or have written permission to test it.'), controlAffinity: ListTileControlAffinity.leading)),
    const SizedBox(height: 14),
    Row(children: [Expanded(child: FilledButton.icon(onPressed: running ? null : runScan, icon: const Icon(Icons.play_arrow), label: const Text('Start scan'))), if (running) ...[const SizedBox(width: 10), OutlinedButton.icon(onPressed: () => setState(() { cancelRequested = true; status = 'Stopping after current connection check...'; }), icon: const Icon(Icons.stop), label: const Text('Stop')]]]),
    const SizedBox(height: 14),
    if (running) LinearProgressIndicator(value: total == 0 ? 0 : (checked / total).clamp(0.0, 1.0)),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('SCAN STATUS', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), Text(status), const SizedBox(height: 12),
      Text('Open ports: ${openPorts.isEmpty ? 'None detected' : openPorts.join(', ')}', style: const TextStyle(color: Colors.lightBlueAccent)),
    ]))),
    const SizedBox(height: 12),
    const Text('This is a TCP connect scanner, not the full Nmap engine. Android permissions, routing and target firewalls affect results.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4)),
  ]);
}

class WebCheckPage extends StatefulWidget {
  const WebCheckPage({super.key});
  @override
  State<WebCheckPage> createState() => _WebCheckPageState();
}

class _WebCheckPageState extends State<WebCheckPage> {
  final urlController = TextEditingController();
  bool authorized = false, running = false;
  Uri? finalUri;
  Map<String, String> present = {};
  List<String> missing = [];
  String status = 'Ready';
  int? score;

  @override
  void dispose() { urlController.dispose(); super.dispose(); }

  Future<void> checkHeaders() async {
    if (!authorized) { setState(() => status = 'Confirm authorization before testing.'); return; }
    var raw = urlController.text.trim();
    if (raw.isEmpty) { setState(() => status = 'Enter a website hostname or URL.'); return; }
    if (!raw.contains('://')) raw = 'https://$raw';
    final uri = Uri.tryParse(raw);
    if (uri == null || !uri.hasAuthority || (uri.scheme != 'https' && uri.scheme != 'http')) {
      setState(() => status = 'Enter a valid HTTP or HTTPS URL.'); return;
    }
    setState(() { running = true; status = 'Checking security headers...'; present = {}; missing = []; score = null; finalUri = null; });
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10)..userAgent = 'NEO-CYBER-Mobile-Security-Checker/0.2';
    try {
      final request = await client.getUrl(uri).timeout(const Duration(seconds: 12));
      final response = await request.close().timeout(const Duration(seconds: 12));
      final found = <String, String>{};
      final absent = <String>[];
      for (final header in _headers.keys) {
        final value = response.headers.value(header);
        if (value != null) { found[header] = value; } else { absent.add(header); }
      }
      final resolved = response.redirects.isNotEmpty
          ? uri.resolveUri(response.redirects.last.location)
          : uri;
      await response.drain<void>();
      final calculated = (found.length * 100 / _headers.length).round();
      await HistoryStore.add(ScanRecord(type: 'Web header check', target: uri.host, summary: 'Header presence score: $calculated% (${found.length}/${_headers.length})', timestamp: _now()));
      if (!mounted) return;
      setState(() { present = found; missing = absent; score = calculated; finalUri = resolved; running = false; status = 'Completed. Review missing headers and site-specific requirements.'; });
    } on SocketException catch (e) {
      if (mounted) setState(() { running = false; status = 'Connection failed: ${e.message}'; });
    } on TimeoutException {
      if (mounted) setState(() { running = false; status = 'Request timed out.'; });
    } on HandshakeException {
      if (mounted) setState(() { running = false; status = 'TLS certificate or handshake error.'; });
    } catch (e) {
      if (mounted) setState(() { running = false; status = 'Request failed: $e'; });
    } finally { client.close(force: true); }
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('WEB SECURITY CHECK', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6), const Text('Passive inspection of common HTTP security headers. This does not prove a site is secure or vulnerable.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 20),
    TextField(controller: urlController, autocorrect: false, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Website URL', hintText: 'https://example.com')),
    const SizedBox(height: 12),
    Card(child: CheckboxListTile(value: authorized, onChanged: running ? null : (v) => setState(() => authorized = v ?? false), title: const Text('I own this website or have permission to assess it.'), controlAffinity: ListTileControlAffinity.leading)),
    const SizedBox(height: 14),
    FilledButton.icon(onPressed: running ? null : checkHeaders, icon: Icon(running ? Icons.hourglass_top : Icons.security), label: Text(running ? 'Checking...' : 'Check security headers')),
    const SizedBox(height: 14),
    if (running) const LinearProgressIndicator(),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('ASSESSMENT RESULT', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), Text(status),
      if (score != null) ...[
        const SizedBox(height: 12), Text('Header presence score: $score%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.lightBlueAccent)),
        if (finalUri != null) Text('Final URL: $finalUri', style: const TextStyle(color: Colors.white54, fontSize: 11)),
        const SizedBox(height: 12), const Text('PRESENT', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.greenAccent)),
        ...present.entries.map((e) => Padding(padding: const EdgeInsets.only(top: 6), child: Text('✓ ${e.key}: ${e.value}', style: const TextStyle(fontSize: 12)))),
        const SizedBox(height: 12), const Text('MISSING', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orangeAccent)),
        ...missing.map((h) => Padding(padding: const EdgeInsets.only(top: 6), child: Text('• $h — ${_headers[h]}', style: const TextStyle(fontSize: 12)))),
      ],
    ]))),
    const SizedBox(height: 12),
    const Text('A missing header is not automatically a vulnerability. Review the application architecture and deployment requirements before drawing conclusions.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4)),
  ]);
}

// Manual HTTP request/response workbench. This is not a transparent
// interception proxy: the user explicitly submits each request to a target
// they are authorized to assess. HTTPS uses normal platform certificate checks.
class HttpInspectorPage extends StatefulWidget {
  const HttpInspectorPage({super.key});
  @override
  State<HttpInspectorPage> createState() => _HttpInspectorPageState();
}

class _HttpInspectorPageState extends State<HttpInspectorPage> {
  final urlController = TextEditingController();
  final headersController = TextEditingController(text: 'User-Agent: NEO-CYBER-Android/0.4');
  final bodyController = TextEditingController();
  String method = 'GET';
  bool authorized = false, running = false;
  int? responseCode;
  Duration? elapsed;
  Map<String, String> responseHeaders = {};
  String responseBody = '', status = 'Ready — enter an authorized URL and send a request.';

  @override
  void dispose() {
    urlController.dispose(); headersController.dispose(); bodyController.dispose();
    super.dispose();
  }

  Map<String, String>? _parseHeaders(String raw) {
    final result = <String, String>{};
    for (final line in raw.split(RegExp(r'\r?\n'))) {
      if (line.trim().isEmpty) continue;
      final split = line.indexOf(':');
      if (split <= 0) return null;
      final name = line.substring(0, split).trim();
      final value = line.substring(split + 1).trim();
      if (!RegExp(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+").hasMatch(name) ||
          name.toLowerCase() == 'host' || name.toLowerCase() == 'content-length' ||
          name.toLowerCase() == 'connection') return null;
      result[name] = value;
    }
    return result;
  }

  Future<void> sendRequest() async {
    if (!authorized) { setState(() => status = 'Confirm that you own the target or have explicit permission.'); return; }
    var raw = urlController.text.trim();
    if (raw.isEmpty) { setState(() => status = 'Enter a URL.'); return; }
    if (!raw.contains('://')) raw = 'https://$raw';
    final uri = Uri.tryParse(raw);
    if (uri == null || !uri.hasAuthority || uri.host.isEmpty ||
        (uri.scheme != 'http' && uri.scheme != 'https') || uri.userInfo.isNotEmpty) {
      setState(() => status = 'Use a valid http:// or https:// URL without embedded credentials.'); return;
    }
    final customHeaders = _parseHeaders(headersController.text);
    if (customHeaders == null) { setState(() => status = 'Invalid header line. Use Name: value; Host and Content-Length are managed automatically.'); return; }
    if (method == 'POST' && bodyController.text.length > 16000) {
      setState(() => status = 'Request body is limited to 16 KB.'); return;
    }
    setState(() { running = true; status = 'Sending $method request...'; responseCode = null; responseHeaders = {}; responseBody = ''; elapsed = null; });
    final watch = Stopwatch()..start();
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 12)
      ..idleTimeout = const Duration(seconds: 5)
      ..maxConnectionsPerHost = 1
      ..userAgent = 'NEO-CYBER-Android/0.4';
    try {
      late HttpClientRequest request;
      switch (method) {
        case 'HEAD': request = await client.headUrl(uri).timeout(const Duration(seconds: 15)); break;
        case 'OPTIONS': request = await client.openUrl('OPTIONS', uri).timeout(const Duration(seconds: 15)); break;
        case 'POST': request = await client.postUrl(uri).timeout(const Duration(seconds: 15)); break;
        default: request = await client.getUrl(uri).timeout(const Duration(seconds: 15));
      }
      for (final entry in customHeaders.entries) {
        request.headers.set(entry.key, entry.value);
      }
      if (method == 'POST') {
        request.headers.contentType = ContentType('text', 'plain', charset: 'utf-8');
        request.write(bodyController.text);
      }
      final response = await request.close().timeout(const Duration(seconds: 20));
      final headerMap = <String, String>{};
      response.headers.forEach((name, values) => headerMap[name] = values.join(', '));
      final bytes = <int>[];
      var truncated = false;
      await for (final chunk in response.timeout(const Duration(seconds: 20))) {
        final remaining = 48 * 1024 - bytes.length;
        if (remaining <= 0) { truncated = true; break; }
        if (chunk.length > remaining) { bytes.addAll(chunk.take(remaining)); truncated = true; break; }
        bytes.addAll(chunk);
      }
      watch.stop();
      final contentType = response.headers.contentType?.mimeType ?? '';
      String bodyText;
      if (contentType.startsWith('text/') || contentType.contains('json') || contentType.contains('xml') || contentType.contains('javascript')) {
        bodyText = utf8.decode(bytes, allowMalformed: true);
      } else if (bytes.isEmpty) {
        bodyText = '(empty response body)';
      } else {
        bodyText = 'Non-text response: ${bytes.length} bytes. Binary payload is not displayed.';
      }
      if (truncated) bodyText += '\n\n[Display truncated at 48 KB]';
      await HistoryStore.add(ScanRecord(type: 'HTTP request inspector', target: uri.host,
        summary: '$method ${uri.path.isEmpty ? '/' : uri.path} → HTTP ${response.statusCode}', timestamp: _now()));
      if (!mounted) return;
      setState(() { running = false; responseCode = response.statusCode; responseHeaders = headerMap; responseBody = bodyText; elapsed = watch.elapsed; status = 'Completed. Inspect the response below.'; });
    } on SocketException catch (e) {
      if (mounted) setState(() { running = false; status = 'Connection failed: ${e.message}'; });
    } on TimeoutException {
      if (mounted) setState(() { running = false; status = 'Request timed out.'; });
    } on HandshakeException {
      if (mounted) setState(() { running = false; status = 'TLS validation failed. NEO CYBER does not bypass certificate checks.'; });
    } catch (e) {
      if (mounted) setState(() { running = false; status = 'Request failed: $e'; });
    } finally { client.close(force: true); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('HTTP Inspector'), backgroundColor: _bg),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('BURP-STYLE REQUEST WORKBENCH', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 7),
      const Text('Manually send a request to an authorized website and inspect its response. This is not a transparent browser interception proxy.', style: TextStyle(color: Colors.white60, height: 1.4)),
      const SizedBox(height: 16),
      TextField(controller: urlController, autocorrect: false, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Target URL', hintText: 'https://your-test-site.example')),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: method, decoration: const InputDecoration(labelText: 'HTTP method'), items: const ['GET', 'HEAD', 'OPTIONS', 'POST'].map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(), onChanged: running ? null : (v) => setState(() => method = v ?? 'GET')),
      const SizedBox(height: 10),
      TextField(controller: headersController, minLines: 2, maxLines: 5, autocorrect: false, decoration: const InputDecoration(labelText: 'Request headers (one per line)', hintText: 'Accept: application/json')),
      if (method == 'POST') ...[
        const SizedBox(height: 10),
        TextField(controller: bodyController, minLines: 3, maxLines: 7, decoration: const InputDecoration(labelText: 'Plain-text request body (max 16 KB)')),
      ],
      const SizedBox(height: 10),
      Card(child: CheckboxListTile(value: authorized, onChanged: running ? null : (v) => setState(() => authorized = v ?? false), title: const Text('I own this target or have explicit permission to test it.'), controlAffinity: ListTileControlAffinity.leading)),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: running ? null : sendRequest, icon: Icon(running ? Icons.hourglass_top : Icons.send), label: Text(running ? 'Sending...' : 'Send request')),
      if (running) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('RESPONSE', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.bold, fontSize: 11)),
        const SizedBox(height: 8), Text(status),
        if (responseCode != null) ...[
          const SizedBox(height: 8),
          Text('HTTP $responseCode  •  ${elapsed?.inMilliseconds ?? 0} ms', style: const TextStyle(color: Colors.lightBlueAccent, fontWeight: FontWeight.bold, fontSize: 17)),
          const SizedBox(height: 12), const Text('RESPONSE HEADERS', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.bold, fontSize: 11)),
          ...responseHeaders.entries.map((e) => Padding(padding: const EdgeInsets.only(top: 5), child: SelectableText('${e.key}: ${e.value}', style: const TextStyle(fontSize: 11)))),
          const SizedBox(height: 12), const Text('RESPONSE BODY', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.bold, fontSize: 11)),
          const SizedBox(height: 5), SelectableText(responseBody, style: const TextStyle(fontFamily: 'monospace', fontSize: 11, height: 1.35)),
        ],
      ]))),
      const SizedBox(height: 10),
      const Text('Safety and scope: use only systems you own or are authorized to assess. NEO CYBER uses normal Android TLS certificate validation, does not install a CA, does not decrypt other apps’ traffic, and limits displayed response data.', style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.4)),
    ]),
  );
}

// Offline classic-PCAP reader. It deliberately displays packet metadata only;
// it does not capture traffic or expose application payloads.
class CapturedPacket {
  final int number, timestampSeconds, capturedLength, originalLength;
  final String protocol, source, destination, details;
  const CapturedPacket({required this.number, required this.timestampSeconds,
    required this.capturedLength, required this.originalLength,
    required this.protocol, required this.source, required this.destination,
    required this.details});
}

class PcapSummary {
  final String fileName;
  final int totalPackets;
  final List<CapturedPacket> packets;
  final Map<String, int> protocols;
  const PcapSummary({required this.fileName, required this.totalPackets,
    required this.packets, required this.protocols});
}

class PcapParser {
  static PcapSummary parse(Uint8List bytes, String fileName) {
    if (bytes.length < 12) throw const FormatException('Capture file is too small or incomplete.');
    final data = ByteData.sublistView(bytes);
    final magic = data.getUint32(0, Endian.big);
    if (magic == 0x0a0d0d0a) return _parsePcapNg(bytes, fileName);
    return _parseClassic(bytes, fileName);
  }

  static PcapSummary _parseClassic(Uint8List bytes, String fileName) {
    if (bytes.length < 24) throw const FormatException('File is too small to be a classic PCAP capture.');
    final data = ByteData.sublistView(bytes);
    final magic = data.getUint32(0, Endian.big);
    late final Endian endian;
    if (magic == 0xa1b2c3d4 || magic == 0xa1b23c4d) {
      endian = Endian.big;
    } else if (magic == 0xd4c3b2a1 || magic == 0x4d3cb2a1) {
      endian = Endian.little;
    } else {
      throw const FormatException('Unrecognized capture format. Select a PCAP or PCAPNG file.');
    }
    if (data.getUint16(4, endian) != 2) throw const FormatException('Unsupported PCAP version.');
    final linkType = data.getUint32(20, endian);
    if (linkType != 1) throw FormatException('Unsupported link type $linkType. Ethernet captures are supported.');
    final packets = <CapturedPacket>[];
    var offset = 24;
    while (offset + 16 <= bytes.length && packets.length < 10000) {
      final seconds = data.getUint32(offset, endian);
      final included = data.getUint32(offset + 8, endian);
      final original = data.getUint32(offset + 12, endian);
      offset += 16;
      if (included > bytes.length - offset) throw const FormatException('Capture contains a truncated packet record.');
      final frame = Uint8List.sublistView(bytes, offset, offset + included);
      offset += included;
      packets.add(_decodePacket(packets.length + 1, seconds, included, original, frame));
    }
    if (packets.isEmpty) throw const FormatException('No packet records were found in this capture.');
    return _summary(fileName, packets);
  }

  static PcapSummary _parsePcapNg(Uint8List bytes, String fileName) {
    var offset = 0;
    Endian? endian;
    final interfaces = <int>[];
    final packets = <CapturedPacket>[];
    final view = ByteData.sublistView(bytes);
    while (offset + 12 <= bytes.length && packets.length < 10000) {
      final isSection = bytes[offset] == 0x0a && bytes[offset + 1] == 0x0d &&
          bytes[offset + 2] == 0x0d && bytes[offset + 3] == 0x0a;
      if (isSection) {
        if (offset + 12 > bytes.length) throw const FormatException('Truncated PCAPNG section header.');
        final bom = view.getUint32(offset + 8, Endian.big);
        if (bom == 0x1a2b3c4d) { endian = Endian.big; }
        else if (bom == 0x4d3c2b1a) { endian = Endian.little; }
        else { throw const FormatException('Invalid PCAPNG byte-order marker.'); }
        interfaces.clear();
      }
      if (endian == null) throw const FormatException('PCAPNG section header is missing.');
      final blockType = view.getUint32(offset, endian);
      final blockLength = view.getUint32(offset + 4, endian);
      if (blockLength < 12 || blockLength % 4 != 0 || blockLength > bytes.length - offset) {
        throw const FormatException('Invalid or truncated PCAPNG block.');
      }
      final blockEnd = offset + blockLength;
      if (view.getUint32(blockEnd - 4, endian) != blockLength) {
        throw const FormatException('PCAPNG block length trailer does not match.');
      }
      if (blockType == 0x0a0d0d0a) {
        // Section Header Block: section state was reset above.
      } else if (blockType == 1) {
        if (blockLength < 20) throw const FormatException('Invalid PCAPNG interface block.');
        interfaces.add(view.getUint16(offset + 8, endian));
      } else if (blockType == 6) {
        if (blockLength < 32) throw const FormatException('Invalid PCAPNG packet block.');
        final interfaceId = view.getUint32(offset + 8, endian);
        final high = view.getUint32(offset + 12, endian);
        final low = view.getUint32(offset + 16, endian);
        final captured = view.getUint32(offset + 20, endian);
        final original = view.getUint32(offset + 24, endian);
        final padded = (captured + 3) & ~3;
        if (28 + padded + 4 > blockLength) throw const FormatException('PCAPNG packet data is truncated.');
        if (interfaceId >= interfaces.length) throw const FormatException('PCAPNG packet references an unknown interface.');
        if (interfaces[interfaceId] != 1) throw FormatException('Unsupported PCAPNG link type ${interfaces[interfaceId]}. Ethernet captures are supported.');
        final frame = Uint8List.sublistView(bytes, offset + 28, offset + 28 + captured);
        final timestampMicros = (high * 0x100000000) + low;
        packets.add(_decodePacket(packets.length + 1, timestampMicros ~/ 1000000, captured, original, frame));
      } else if (blockType == 3) {
        if (blockLength < 16) throw const FormatException('Invalid PCAPNG simple packet block.');
        if (interfaces.isNotEmpty && interfaces.first != 1) throw FormatException('Unsupported PCAPNG link type ${interfaces.first}. Ethernet captures are supported.');
        final original = view.getUint32(offset + 8, endian);
        final captured = (blockLength - 16).clamp(0, original).toInt();
        final frame = Uint8List.sublistView(bytes, offset + 12, offset + 12 + captured);
        packets.add(_decodePacket(packets.length + 1, 0, captured, original, frame));
      }
      offset = blockEnd;
    }
    if (packets.isEmpty) throw const FormatException('No supported Ethernet packet records were found in this PCAPNG capture.');
    return _summary(fileName, packets);
  }

  static CapturedPacket _decodePacket(int number, int seconds, int included, int original, Uint8List frame) {
    var protocol = 'Other';
    var source = '—';
    var destination = '—';
    var details = 'Ethernet frame';
    if (frame.length >= 14) {
      var etherType = (frame[12] << 8) | frame[13];
      var l3 = 14;
      if ((etherType == 0x8100 || etherType == 0x88a8 || etherType == 0x9100) && frame.length >= 18) {
        etherType = (frame[16] << 8) | frame[17];
        l3 = 18;
      }
      if (etherType == 0x0800 && frame.length >= l3 + 20) {
        final ihl = (frame[l3] & 0x0f) * 4;
        if (ihl >= 20 && frame.length >= l3 + ihl) {
          source = '${frame[l3+12]}.${frame[l3+13]}.${frame[l3+14]}.${frame[l3+15]}';
          destination = '${frame[l3+16]}.${frame[l3+17]}.${frame[l3+18]}.${frame[l3+19]}';
          final ipProto = frame[l3 + 9];
          final transport = l3 + ihl;
          if (ipProto == 6 && frame.length >= transport + 20) {
            protocol = 'TCP'; details = '${_u16(frame, transport)} → ${_u16(frame, transport + 2)}';
          } else if (ipProto == 17 && frame.length >= transport + 8) {
            protocol = 'UDP'; details = '${_u16(frame, transport)} → ${_u16(frame, transport + 2)}';
          } else if (ipProto == 1) { protocol = 'ICMP'; details = 'IPv4 ICMP'; }
          else { protocol = 'IPv4'; details = 'IP protocol $ipProto'; }
        }
      } else if (etherType == 0x86dd && frame.length >= l3 + 40) {
        source = _ipv6(frame, l3 + 8);
        destination = _ipv6(frame, l3 + 24);
        var nextHeader = frame[l3 + 6];
        var transport = l3 + 40;
        var guard = 0;
        while ((nextHeader == 0 || nextHeader == 43 || nextHeader == 60 || nextHeader == 44 || nextHeader == 51) && guard++ < 8) {
          if (transport + 2 > frame.length) break;
          final following = frame[transport];
          final extLength = nextHeader == 44 ? 8 : (nextHeader == 51 ? (frame[transport + 1] + 2) * 4 : (frame[transport + 1] + 1) * 8);
          if (extLength < 8 || transport + extLength > frame.length) break;
          transport += extLength;
          nextHeader = following;
        }
        if (nextHeader == 6 && frame.length >= transport + 20) { protocol = 'TCPv6'; details = '${_u16(frame, transport)} → ${_u16(frame, transport + 2)}'; }
        else if (nextHeader == 17 && frame.length >= transport + 8) { protocol = 'UDPv6'; details = '${_u16(frame, transport)} → ${_u16(frame, transport + 2)}'; }
        else if (nextHeader == 58) { protocol = 'ICMPv6'; details = 'IPv6 ICMP'; }
        else { protocol = 'IPv6'; details = 'Next header $nextHeader'; }
      } else if (etherType == 0x0806) { protocol = 'ARP'; details = 'Address resolution'; }
    }
    return CapturedPacket(number: number, timestampSeconds: seconds, capturedLength: included,
      originalLength: original, protocol: protocol, source: source, destination: destination, details: details);
  }

  static int _u16(Uint8List b, int o) => (b[o] << 8) | b[o + 1];
  static String _ipv6(Uint8List b, int o) {
    final groups = <int>[];
    for (var i = 0; i < 16; i += 2) groups.add((b[o + i] << 8) | b[o + i + 1]);
    return groups.map((v) => v.toRadixString(16)).join(':');
  }
  static PcapSummary _summary(String name, List<CapturedPacket> packets) {
    final counts = <String, int>{};
    for (final packet in packets) { counts[packet.protocol] = (counts[packet.protocol] ?? 0) + 1; }
    return PcapSummary(fileName: name, totalPackets: packets.length, packets: packets, protocols: counts);
  }
}
class PacketAnalyzerPage extends StatefulWidget {
  const PacketAnalyzerPage({super.key});
  @override
  State<PacketAnalyzerPage> createState() => _PacketAnalyzerPageState();
}

class _PacketAnalyzerPageState extends State<PacketAnalyzerPage> {
  PcapSummary? summary;
  String status = 'Import a classic Ethernet .pcap file to inspect packet metadata.';
  bool loading = false;

  Future<void> importCapture() async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.custom,
        allowedExtensions: ['pcap', 'pcapng'], withData: true);
      if (result == null) return;
      final file = result.files.single;
      final bytes = file.bytes;
      if (bytes == null) throw const FormatException('Could not read the selected file. Try choosing it again.');
      setState(() { loading = true; status = 'Analyzing ${file.name}...'; });
      await Future<void>.delayed(Duration.zero);
      final parsed = PcapParser.parse(bytes, file.name);
      await HistoryStore.add(ScanRecord(type: 'PCAP analysis', target: file.name,
        summary: '${parsed.totalPackets} packets; ${parsed.protocols.length} protocols', timestamp: _now()));
      if (!mounted) return;
      setState(() { summary = parsed; loading = false; status = 'Analysis complete. Displaying packet metadata only.'; });
    } on FormatException catch (e) {
      if (mounted) setState(() { loading = false; status = e.message; });
    } catch (e) {
      if (mounted) setState(() { loading = false; status = 'Could not analyze capture: $e'; });
    }
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('PACKET ANALYZER', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6),
    const Text('Offline packet-capture inspection for Ethernet PCAP and PCAPNG files. No root access is required.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 18),
    FilledButton.icon(onPressed: loading ? null : importCapture,
      icon: Icon(loading ? Icons.hourglass_top : Icons.file_open),
      label: Text(loading ? 'Analyzing...' : 'Import PCAP / PCAPNG')),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(status))),
    if (summary != null) ...[
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(summary!.fileName, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6), Text('${summary!.totalPackets} packets analyzed', style: const TextStyle(color: Colors.lightBlueAccent, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12), const Text('PROTOCOL BREAKDOWN', style: TextStyle(fontSize: 11, color: Colors.white54, fontWeight: FontWeight.bold)),
        ...summary!.protocols.entries.map((e) => Padding(padding: const EdgeInsets.only(top: 7), child: Row(children: [Expanded(child: Text(e.key)), Text('${e.value}')]))),
      ]))),
      const SizedBox(height: 12),
      const Text('PACKET LIST', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      const SizedBox(height: 8),
      ...summary!.packets.take(300).map((p) => Card(child: ListTile(
        dense: true, leading: CircleAvatar(radius: 16, child: Text('${p.number}', style: const TextStyle(fontSize: 10)),),
        title: Text('${p.protocol}  ${p.details}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
        subtitle: Text('${p.source}  →  ${p.destination}\n${p.capturedLength} bytes captured / ${p.originalLength} bytes on wire', style: const TextStyle(fontSize: 11)),
        isThreeLine: true,
      ))),
      if (summary!.totalPackets > 300) const Text('Showing the first 300 packets for mobile performance.', style: TextStyle(color: Colors.white54, fontSize: 12)),
    ],
    const SizedBox(height: 12),
    const Text('Packet metadata is read from the capture file you select. This analyzer does not capture live traffic, decrypt HTTPS, or inspect application payloads. Ethernet captures are supported; unsupported link types are reported.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4)),
  ]);
}

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  late Future<List<ScanRecord>> records;
  @override
  void initState() { super.initState(); records = HistoryStore.load(); }
  void refresh() => setState(() => records = HistoryStore.load());

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    Row(children: [const Expanded(child: Text('SCAN HISTORY', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))), IconButton(onPressed: refresh, icon: const Icon(Icons.refresh)), IconButton(onPressed: () async { await HistoryStore.clear(); refresh(); }, icon: const Icon(Icons.delete_outline))]),
    const SizedBox(height: 10),
    FutureBuilder<List<ScanRecord>>(future: records, builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()));
      final items = snapshot.data ?? <ScanRecord>[];
      if (items.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('No assessments saved yet. Completed scans will appear here.')));
      return Column(
        children: items.map((r) => Card(
          child: ListTile(
            leading: const Icon(Icons.fact_check_outlined, color: _blue),
            title: Text(r.type),
            subtitle: Text('${r.target}\n${r.summary}\n${r.timestamp}'),
            isThreeLine: true,
          ),
        )).toList(),
      );
    }),
  ]);
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [
    Text('ABOUT NEO CYBER', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    SizedBox(height: 14),
    Text('NEO CYBER is an Android-first security assessment app designed for non-rooted phones. It does not require a laptop.'),
    SizedBox(height: 16), Text('Available functions', style: TextStyle(fontWeight: FontWeight.bold)),
    SizedBox(height: 8), Text('• Bounded TCP connect scanner with stop control.\n• Passive HTTP security-header checker.\n• Manual HTTP request/response inspector.\n• Offline Ethernet PCAP and PCAPNG metadata analyzer with IPv4/IPv6 endpoint decoding.\n• Local assessment history.'),
    SizedBox(height: 16), Text('The app only performs supported functions within Android permissions. It does not provide unrestricted Wireshark, Burp Suite, OWASP ZAP or Metasploit desktop functionality.'),
    SizedBox(height: 16), Text('Only assess systems you own or have explicit permission to test.'),
  ]);
}
