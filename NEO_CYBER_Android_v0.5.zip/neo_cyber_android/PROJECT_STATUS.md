# NEO CYBER project status — 0.5.0

## Confirmed product requirements
- Android only; standalone phone operation.
- No root required.
- No laptop, Kali installation, or remote computer required at runtime.
- Local-first operation for supported security assessments.
- No demo screens, sample capture files, mock findings, or fake scan output in the application/package.

## Implemented in source
- [x] Flutter dark mobile dashboard and navigation.
- [x] Bounded TCP connect scanner (up to 128 ports per run), explicit authorization acknowledgement, and stop control.
- [x] Passive HTTP(S) security-header checker.
- [x] Manual HTTP request/response workbench (GET, HEAD, OPTIONS, POST) with normal TLS validation and bounded response display.
- [x] Offline Ethernet PCAP reader.
- [x] Offline PCAPNG reader for Section Header, Interface Description, Enhanced Packet and Simple Packet blocks.
- [x] IPv4 and IPv6 endpoint decoding; TCP/UDP port and ICMP/ICMPv6/ARP identification.
- [x] Local assessment history.
- [x] Original uploaded Python project retained under `legacy_engine/`.
- [x] Removed synthetic capture file and unimplemented placeholder tiles from the app.

## Explicit limitations
- Port scanner is a conservative TCP connect scanner, not the full Nmap engine.
- Web checker is a single passive HTTP(S) header check, not OWASP ZAP.
- HTTP Inspector is a manual request workbench, not a transparent Burp-style interception proxy.
- Packet analyzer reads user-selected files; it does not capture live traffic, decrypt HTTPS, or inspect payloads. PCAPNG timestamp-resolution options are not yet interpreted.
- Wi-Fi monitor mode, packet injection, and unrestricted low-level capture are unavailable on ordinary non-rooted Android devices.
- Full Metasploit Framework and NEO AI are not part of this build. They are not shown as working app modules.

## Build verification
Flutter and the Android SDK are not available in the current build environment. Source has not been compiled into an APK or device-tested here. Build using `flutter pub get` and `flutter build apk --release` in a configured Flutter/Android environment.

## Safety
Use only on systems you own or have explicit permission to assess. The in-app authorization acknowledgement is a reminder, not proof of permission.
