# NEO CYBER — Android standalone application (0.5.0)

NEO CYBER is designed to run directly on a non-rooted Android phone. It does not require a laptop, Kali installation, or a remote computer.

## Functions present in this build
- Flutter mobile dashboard and navigation.
- Bounded TCP connect port scanner with explicit authorization acknowledgement and stop control. This is an Nmap-style subset, not the Nmap engine.
- Passive HTTP(S) security-header checker.
- Manual HTTP request/response workbench for GET, HEAD, OPTIONS and POST. It is not a transparent interception proxy.
- Offline Ethernet PCAP and PCAPNG metadata analyzer.
- IPv4 and IPv6 endpoint decoding, TCP/UDP port display, ICMP/ICMPv6 and ARP identification.
- Local assessment history.
- Original uploaded Python modules preserved under `legacy_engine/` for future porting and review.

## Packet analyzer limits
The analyzer imports capture files selected by the user. It does not perform live traffic capture, decrypt HTTPS, or display application payloads. PCAPNG support covers Section Header, Interface Description, Enhanced Packet and Simple Packet blocks for Ethernet interfaces. PCAPNG timestamp resolution options are not yet interpreted; displayed timestamps are approximate seconds. Unsupported link types are rejected. Up to 10,000 packets are parsed and up to 300 are displayed.

## Not included in this build
There are no bundled sample captures, fake findings, mock scan results, demo screens, or placeholder tool modules. A module is shown in the app only when its function is implemented. Live VPN capture, a full interception proxy, full OWASP ZAP functionality, the Metasploit Framework, and NEO AI are not included yet.

## Android build
Install Flutter and Android Studio with the Android SDK. From this directory run:

```bash
flutter pub get
flutter create --platforms=android --org com.neocyber .
flutter run
```

If the Android platform folder already exists, skip `flutter create`. Add these permissions directly under the `<manifest>` element in `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

Build a release APK with:

```bash
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Safety
Only assess systems you own or have explicit permission to test. The authorization checkbox is a reminder, not proof of permission. The app does not provide exploitation, credential attacks, stealth, or unauthorized access. Android's non-root permission model limits low-level capture, Wi-Fi monitor mode, injection, and some scan techniques.
