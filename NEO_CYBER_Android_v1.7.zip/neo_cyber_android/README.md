# NEO CYBER — Android standalone application (1.6.0)

NEO CYBER is designed to run directly on a non-rooted Android phone. It does not require a laptop, Kali installation, or remote computer at runtime. The app contains mobile-compatible assessment functions; it does not claim to bundle full desktop versions of Nmap, Wireshark, Burp Suite, OWASP ZAP, or Metasploit.

## Functions in this source build
- Dark Flutter mobile dashboard and navigation.
- Bounded TCP connect scanner (up to 128 ports per run), common-port service hints, and best-effort banner checks.
- Passive HTTP(S) security-header checker.
- **Web vulnerability/configuration assessment:** one-request inspection of transport security, HSTS, CSP, anti-framing headers, MIME-sniffing protection, referrer/permissions policies, cookie attributes, and technology-banner disclosure. Displays evidence and remediation guidance; supports copying a plain-text report.
- Manual HTTP request/response workbench for GET, HEAD, OPTIONS and POST; HTTPS uses normal platform certificate validation.
- Offline Ethernet PCAP and PCAPNG metadata analyzer with microsecond/nanosecond and per-interface PCAPNG timestamp resolution support; no live packet capture or payload decryption.
- Local assessment history.
- Explicit loopback HTTP forward proxy at `127.0.0.1:8888`; HTTPS CONNECT is an opaque tunnel and remains encrypted.
- Original uploaded Python modules retained under `legacy_engine/`.

- **PDF report export:** creates a formatted PDF with target, timestamp, HTTP status, severity counts, evidence, recommendations, and scope limitations; invokes Android share/print sheet. Completed web assessments are also recorded in local assessment history.

## Vulnerability assessment limitations
The new assessment makes one ordinary GET request and checks observable response headers and cookies. It does not crawl, fuzz, authenticate, exploit, or test application input handling. Missing headers are not proof of exploitability. It does not test SQL injection, XSS, access control, authentication, business logic, dependencies, or server-side code. The PDF is a summary of the same passive observations; it does not add deeper testing or establish exploitability.

## Other limitations
The scanner is not the Nmap engine and does not perform SYN/UDP scans, OS detection, NSE scripts, or exploit checks. The HTTP workbench is not a transparent Burp proxy. The local proxy does not decrypt TLS. The packet analyzer imports Ethernet PCAP/PCAPNG files and displays packet metadata/timestamps; it does not capture live traffic, decrypt HTTPS, or inspect application payloads. Rootless Android restricts monitor mode, packet injection, and low-level capture.

## Android build
Install Flutter and Android Studio with the Android SDK. From this directory run:

```bash
flutter pub get
flutter create --platforms=android --org com.neocyber .
flutter run
```

If the Android platform folder already exists, skip `flutter create`. Add `INTERNET` and `ACCESS_NETWORK_STATE` permissions under the `<manifest>` element in `android/app/src/main/AndroidManifest.xml`.

Build a release APK with:

```bash
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Safety
Only assess systems you own or have explicit permission to test. The authorization checkbox is a reminder, not proof of permission.


## v1.0 history improvements
Completed passive web assessments now save their individual observations, evidence, and recommendations in local history. Open a history item to review it, delete one item, or clear all history after confirmation. Older records remain compatible. PDF export is available from the current assessment result; re-exporting PDFs from history is not included.


## v1.1 history PDF export
Saved web vulnerability assessments with detailed observations can now be exported again from the History screen using the PDF icon or the record details dialog. The report reproduces the stored target, timestamp, summary, observations, evidence, and recommendations; it does not run a new scan or validate old observations. Older summary-only records remain viewable but are not offered the detailed PDF action.


### v1.2 passive web policy checks
The web assessment now flags selected CSP policy weaknesses (`unsafe-inline`, `unsafe-eval`, wildcard `default-src`), short/missing HSTS max-age, and SameSite=None cookies without Secure. These are configuration observations from one HTTP response and require manual validation.


## v1.3 assessment history filtering
The History screen now supports case-insensitive search across assessment type, target, summary and timestamp; category filters for Web, Network and Other; and newest/oldest sorting. Filters operate on locally stored records only and do not alter or delete the underlying history.


## v1.4
TCP scan records now retain service-identification details, and current service results can be copied as escaped CSV for spreadsheet use. CSV export uses only results returned by the actual scan.


## v1.5 — scanner timeout control
- Added a user-selectable TCP connection timeout (400, 800, 1,500, or 2,500 ms).
- The selected timeout is applied consistently to port connection attempts and best-effort service identification waits.
- The chosen timeout is recorded in the saved scan summary so results retain important scan context.
- This improves control on different network conditions; it does not make the scanner equivalent to Nmap or guarantee service fingerprinting.


### v1.7 proxy hardening
The local loopback proxy accepts up to 12 concurrent clients, rejects additional clients with HTTP 503, caps request headers at 64 KiB, and applies a 15-second timeout while receiving request headers. It still does not decrypt HTTPS or inspect TLS-protected content.
