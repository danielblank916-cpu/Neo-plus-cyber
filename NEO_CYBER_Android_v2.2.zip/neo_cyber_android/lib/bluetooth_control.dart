import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

/// Real, user-initiated BLE discovery and read-only GATT inspection.
/// No characteristic writes or background scanning are performed.
class BluetoothControlPanel extends StatefulWidget {
  const BluetoothControlPanel({super.key});

  @override
  State<BluetoothControlPanel> createState() => _BluetoothControlPanelState();
}

class _BluetoothControlPanelState extends State<BluetoothControlPanel> {
  bool _starting = false;
  bool _connecting = false;
  BluetoothDevice? _connected;
  List<BluetoothService> _services = const [];
  String? _message;

  Future<bool> _requestPermissions() async {
    if (!Platform.isAndroid) {
      setState(() => _message = 'This build currently enables BLE controls on Android only.');
      return false;
    }
    final scan = await Permission.bluetoothScan.request();
    final connect = await Permission.bluetoothConnect.request();
    if (!scan.isGranted || !connect.isGranted) {
      setState(() => _message = 'Bluetooth scan and connect permissions are required. Enable them in Android app settings to continue.');
      return false;
    }
    return true;
  }

  Future<void> _scan() async {
    if (_starting) return;
    setState(() { _starting = true; _message = null; });
    try {
      if (!await _requestPermissions()) return;
      final supported = await FlutterBluePlus.isSupported;
      if (!supported) {
        setState(() => _message = 'Bluetooth Low Energy is not supported by this phone.');
        return;
      }
      final state = await FlutterBluePlus.adapterState.first;
      if (state != BluetoothAdapterState.on) {
        setState(() => _message = 'Turn on Bluetooth, then scan again.');
        return;
      }
      await FlutterBluePlus.stopScan();
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 10));
      setState(() => _message = 'Scanning for nearby BLE advertisements for 10 seconds…');
    } catch (e) {
      setState(() => _message = 'Bluetooth scan failed: $e');
    } finally {
      if (mounted) setState(() => _starting = false);
    }
  }

  Future<void> _connect(BluetoothDevice device) async {
    if (_connecting) return;
    setState(() { _connecting = true; _message = 'Connecting to ${device.platformName.isEmpty ? device.remoteId.str : device.platformName}…'; });
    try {
      if (!await _requestPermissions()) return;
      if (_connected != null && _connected!.remoteId != device.remoteId) {
        await _connected!.disconnect();
      }
      await device.connect(timeout: const Duration(seconds: 15), autoConnect: false);
      final services = await device.discoverServices();
      if (!mounted) return;
      setState(() {
        _connected = device;
        _services = services;
        _message = 'Connected. GATT inspection is read-only; no device settings or values will be changed.';
      });
    } catch (e) {
      if (mounted) setState(() => _message = 'Connection or service discovery failed: $e');
    } finally {
      if (mounted) setState(() => _connecting = false);
    }
  }

  Future<void> _disconnect() async {
    final device = _connected;
    if (device == null) return;
    try { await device.disconnect(); } catch (_) {}
    if (mounted) setState(() { _connected = null; _services = const []; _message = 'Disconnected.'; });
  }

  Future<void> _read(BluetoothCharacteristic characteristic) async {
    try {
      final value = await characteristic.read();
      final hex = value.map((b) => b.toRadixString(16).padLeft(2, '0')).join(' ');
      if (!mounted) return;
      showDialog<void>(context: context, builder: (context) => AlertDialog(
        title: const Text('Characteristic value'),
        content: SelectableText(value.isEmpty ? '(empty value)' : hex),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CLOSE'))],
      ));
    } catch (e) {
      if (mounted) setState(() => _message = 'Read failed: $e');
    }
  }

  @override
  void dispose() {
    // Do not leave a scan running after this panel is removed.
    FlutterBluePlus.stopScan();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.bluetooth_searching, color: Color(0xFF36A7FF)),
          const SizedBox(width: 8),
          const Expanded(child: Text('BLUETOOTH / BLE', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: .7))),
          FilledButton.icon(onPressed: _starting ? null : _scan, icon: _starting ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.radar, size: 17), label: const Text('SCAN')),
        ]),
        const SizedBox(height: 8),
        const Text('Find nearby Bluetooth Low Energy advertisements, connect to a device you own or are authorized to inspect, and read exposed GATT characteristics. This does not pair with every classic Bluetooth device or grant general remote control.', style: TextStyle(color: Colors.white70, height: 1.35, fontSize: 12)),
        if (_message != null) ...[
          const SizedBox(height: 9),
          Text(_message!, style: const TextStyle(color: Colors.lightBlueAccent, fontSize: 12)),
        ],
        StreamBuilder<List<ScanResult>>(
          stream: FlutterBluePlus.scanResults,
          initialData: const [],
          builder: (context, snapshot) {
            final results = snapshot.data ?? const <ScanResult>[];
            if (results.isEmpty) return const Padding(padding: EdgeInsets.only(top: 12), child: Text('No BLE devices discovered in the latest scan.', style: TextStyle(color: Colors.white54, fontSize: 12)));
            return Column(children: results.map((result) {
              final device = result.device;
              final name = result.advertisementData.advName.isNotEmpty ? result.advertisementData.advName : (device.platformName.isNotEmpty ? device.platformName : 'Unnamed BLE device');
              final connected = _connected?.remoteId == device.remoteId;
              return ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.bluetooth, color: Color(0xFF36A7FF)),
                title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${device.remoteId.str} • RSSI ${result.rssi} dBm', style: const TextStyle(fontSize: 10, color: Colors.white54)),
                trailing: connected ? const Icon(Icons.link, color: Colors.lightGreenAccent) : TextButton(onPressed: _connecting ? null : () => _connect(device), child: const Text('CONNECT')),
              );
            }).toList());
          },
        ),
        if (_connected != null) ...[
          const Divider(),
          Row(children: [Expanded(child: Text('GATT SERVICES • ${_services.length}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12))), TextButton(onPressed: _disconnect, child: const Text('DISCONNECT'))]),
          ..._services.map((service) => ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: Text(service.uuid.str, style: const TextStyle(fontSize: 12)),
            subtitle: Text('${service.characteristics.length} characteristics', style: const TextStyle(color: Colors.white54, fontSize: 10)),
            children: service.characteristics.map((characteristic) => ListTile(
              dense: true,
              title: Text(characteristic.uuid.str, style: const TextStyle(fontSize: 11)),
              subtitle: Text('Read: ${characteristic.properties.read ? 'yes' : 'no'} • Write: ${characteristic.properties.write || characteristic.properties.writeWithoutResponse ? 'supported (disabled)' : 'no'} • Notify: ${characteristic.properties.notify ? 'yes' : 'no'}', style: const TextStyle(fontSize: 10, color: Colors.white54)),
              trailing: characteristic.properties.read ? IconButton(tooltip: 'Read value', onPressed: () => _read(characteristic), icon: const Icon(Icons.download, color: Color(0xFF36A7FF))) : null,
            )).toList(),
          )),
        ],
      ]),
    ),
  );
}
