import requests
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup


def crawl(base_url, max_pages=50, timeout=5):
    """Real crawler: fetches base_url, follows same-domain links it finds
    in <a href>, <script src>, <link href>, <img src>, up to max_pages.
    Returns a sorted list of every unique URL found (including base_url)."""
    if not base_url.startswith(("http://", "https://")):
        base_url = "https://" + base_url
    domain = urlparse(base_url).netloc

    seen = {base_url}
    to_visit = [base_url]
    found = set()

    while to_visit and len(seen) <= max_pages:
        url = to_visit.pop(0)
        try:
            resp = requests.get(url, timeout=timeout, headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0 Safari/537.36"
                )
            })
        except requests.RequestException:
            continue

        found.add(url)
        content_type = resp.headers.get("Content-Type", "")
        if "text/html" not in content_type:
            continue

        soup = BeautifulSoup(resp.text, "html.parser")
        tags = (
            ("a", "href"), ("script", "src"), ("link", "href"), ("img", "src")
        )
        for tag, attr in tags:
            for el in soup.find_all(tag):
                link = el.get(attr)
                if not link:
                    continue
                full = urljoin(url, link)
                full = full.split("#")[0]  # drop fragment
                parsed = urlparse(full)
                if parsed.netloc != domain:
                    continue  # stay on same domain
                found.add(full)
                if full not in seen and len(seen) <= max_pages:
                    seen.add(full)
                    if parsed.path and not any(
                        full.lower().endswith(ext)
                        for ext in (".jpg", ".png", ".gif", ".css", ".js", ".svg", ".woff", ".woff2", ".ico")
                    ):
                        to_visit.append(full)

    return sorted(found)


def run(target):
    max_pages = input("Max pages to crawl [50]: ").strip()
    max_pages = int(max_pages) if max_pages else 50
    print(f"Crawling {target} (real HTTP requests, same-domain only) ...")
    urls = crawl(target, max_pages=max_pages)
    print(f"Found {len(urls)} URLs:")
    for u in urls:
        print(f"  {u}")
    if len(urls) <= 1:
        print()
        print("  Only the base page was found. This usually means either:")
        print("  - the site blocked the request (check for a 403/empty response)")
        print("  - it's a single-page app (React/Vue/Next.js) whose real pages")
        print("    are rendered by JavaScript in the browser, not linked in the")
        print("    server's HTML - a crawler like this can't see those routes.")
    return urls
