"""
Path Finder - ALL-IN-ONE.

Covers every "what paths/pages exist on this site" technique in one place,
since they all share the same underlying method (a real HTTP GET per
candidate path) and were previously split across separate modules that
duplicated the same logic:

  A) COMMON PATHS   - general recon paths (/backup, /config, /.git, /.env,
                       /uploads, etc.)
  B) ADMIN PATHS    - known admin/control-panel paths for popular platforms
                       and CMSes (/admin, /wp-admin, /phpmyadmin, /cpanel...)
  C) SITE CLUES     - real crawl of the site + real fetch of robots.txt and
                       sitemap.xml, keyword-matched for admin-related terms.
                       Catches CUSTOM names a fixed list would miss (e.g.
                       "/platform", "/staffzone") because it reads what the
                       site actually links to or lists.

Every result only means a path responded (status < 400) or was referenced
somewhere on the site - it never confirms a real panel/page exists there,
and nothing here attempts logins, credential guessing, or exploitation.
"""
import requests
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

import url_crawler

COMMON_PATHS = [
    "backup", "config", "uploads", "images", "scripts", "css", "js",
    "api", "test", "dev", ".git", ".env", "robots.txt", "sitemap.xml",
    "old", "tmp", "data", "private",
]

ADMIN_PATHS = [
    "admin", "admin/", "admin/login", "admin/login.php", "admin.php",
    "administrator", "administrator/", "wp-admin", "wp-admin/",
    "wp-login.php", "phpmyadmin", "phpMyAdmin", "cpanel", "cPanel",
    "manager/html", "console", "controlpanel", "control-panel",
    "backend", "backoffice", "moderator", "webadmin", "adminpanel",
    "admin-console", "admincp", "useradmin", "sysadmin", "root",
    "login", "login.php", "login.html", "signin", "user/login",
    "account/login", "portal", "panel", "management", "dashboard",
    "platform", "platform/", "platform/login", "platform/admin",
]

ADMIN_KEYWORDS = [
    "admin", "administrator", "panel", "platform", "dashboard",
    "cpanel", "control", "backend", "backoffice", "manage", "mgmt",
    "management", "console", "portal", "staff", "moderator", "mod",
    "superuser", "root", "sysadmin", "webadmin", "login", "signin",
    "auth", "secure", "private", "internal", "employee", "operator",
]


def _normalize(base_url):
    if not base_url.startswith(("http://", "https://")):
        base_url = "https://" + base_url
    return base_url.rstrip("/")


def _get_baseline(base_url, timeout=5):
    """Request a path that almost certainly doesn't exist, to see how this
    site responds to a 'not found' page. Many sites return HTTP 200 (not
    404) for every unknown path and just show the homepage or a custom
    error page - this is called a 'soft 404'. If we don't detect this,
    EVERY real path we check will look like a match, even though none of
    them actually exist. Returns (status_code, content_length, body_sample)
    for the fake path, or None if the request failed."""
    import uuid
    fake_path = f"this-path-should-not-exist-{uuid.uuid4().hex[:12]}"
    url = f"{base_url}/{fake_path}"
    try:
        resp = requests.get(url, timeout=timeout, allow_redirects=False,
                             headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0 Safari/537.36"
                )
            })
        return resp.status_code, len(resp.content), resp.text[:500]
    except requests.RequestException:
        return None


_UA = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0 Safari/537.36"
    )
}


def check_paths(base_url, wordlist, timeout=5, stats=None):
    """Real HTTP GET for each path in wordlist against base_url.
    Returns {url: status_code} for anything that responded (status < 400)
    AND looks genuinely different from this site's 'soft 404' baseline -
    i.e. not just the same homepage/error page served for every path.

    If a `stats` dict is passed, it's updated in place with counts so the
    caller can report WHY nothing was found (blocked/erroring vs genuinely
    not there), instead of just silently returning an empty result."""
    base_url = _normalize(base_url)
    baseline = _get_baseline(base_url, timeout)
    results = {}
    for path in wordlist:
        url = f"{base_url}/{path}"
        if stats is not None:
            stats["checked"] = stats.get("checked", 0) + 1
        try:
            resp = requests.get(url, timeout=timeout, allow_redirects=False, headers=_UA)
        except requests.RequestException as e:
            if stats is not None:
                stats["errors"] = stats.get("errors", 0) + 1
                stats.setdefault("last_error", str(e))
            continue
        if resp.status_code >= 400:
            if stats is not None:
                stats["blocked_or_404"] = stats.get("blocked_or_404", 0) + 1
                if resp.status_code in (401, 403, 429):
                    stats["saw_block_status"] = resp.status_code
            continue
        if baseline:
            base_status, base_len, base_sample = baseline
            same_status = resp.status_code == base_status
            # allow small size differences (a few bytes of dynamic content)
            similar_length = abs(len(resp.content) - base_len) < 50
            same_sample = resp.text[:500] == base_sample
            if same_status and (similar_length or same_sample):
                if stats is not None:
                    stats["filtered_soft404"] = stats.get("filtered_soft404", 0) + 1
                continue  # looks like the site's generic "not found" response
        results[url] = resp.status_code
    return results


def _fetch_text(url, timeout=5):
    try:
        resp = requests.get(url, timeout=timeout, headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0 Safari/537.36"
                )
            })
        if resp.status_code < 400:
            return resp.text
    except requests.RequestException:
        pass
    return ""


def gather_clues(base_url, max_pages=50, timeout=5):
    """Real crawl + real fetch of robots.txt/sitemap.xml, keyword-matched
    against ADMIN_KEYWORDS. Returns {url: [matched_keywords]}."""
    base_url = _normalize(base_url)
    domain = urlparse(base_url).netloc
    candidates = set()

    candidates.update(url_crawler.crawl(base_url, max_pages=max_pages, timeout=timeout))

    robots_text = _fetch_text(f"{base_url}/robots.txt", timeout)
    for line in robots_text.splitlines():
        line = line.strip()
        if ":" in line and line.lower().startswith(("disallow", "allow", "sitemap")):
            p = line.split(":", 1)[1].strip()
            if p:
                candidates.add(urljoin(base_url + "/", p.lstrip("/")))

    sitemap_text = _fetch_text(f"{base_url}/sitemap.xml", timeout)
    if sitemap_text:
        try:
            soup = BeautifulSoup(sitemap_text, "xml")
        except Exception:
            soup = BeautifulSoup(sitemap_text, "html.parser")
        for loc in soup.find_all("loc"):
            if loc.text:
                candidates.add(loc.text.strip())

    clues = {}
    for url in candidates:
        parsed = urlparse(url)
        if parsed.netloc and parsed.netloc != domain:
            continue
        matched = [kw for kw in ADMIN_KEYWORDS if kw in parsed.path.lower()]
        if matched:
            clues[url] = matched

    return clues


def find_everything(base_url, include_clues=True, max_pages=50, timeout=5, stats=None):
    """Run all three techniques and merge into one combined, de-duplicated
    report: {url: {"category": [...], "status": int|None, "keywords": [...]}}
    category entries: "common_path", "admin_path", "clue". Pass a dict as
    `stats` to get counts explaining why something was or wasn't found."""
    base_url = _normalize(base_url)
    combined = {}

    for url, status in check_paths(base_url, COMMON_PATHS, timeout, stats).items():
        combined.setdefault(url, {"category": [], "status": None, "keywords": []})
        combined[url]["category"].append("common_path")
        combined[url]["status"] = status

    for url, status in check_paths(base_url, ADMIN_PATHS, timeout, stats).items():
        combined.setdefault(url, {"category": [], "status": None, "keywords": []})
        combined[url]["category"].append("admin_path")
        combined[url]["status"] = status

    if include_clues:
        for url, keywords in gather_clues(base_url, max_pages, timeout).items():
            combined.setdefault(url, {"category": [], "status": None, "keywords": []})
            combined[url]["category"].append("clue")
            combined[url]["keywords"] = keywords

    return combined


def run(target):
    print(f"Finding paths on {target} (real requests: common + admin paths + site clues) ...")
    base_url = _normalize(target)
    baseline = _get_baseline(base_url)
    if baseline and baseline[0] < 400:
        print(f"  Note: this site returns HTTP {baseline[0]} even for a path that")
        print("  doesn't exist (a 'soft 404'). Results below have been filtered to")
        print("  exclude pages that just look like this generic response.")
    stats = {}
    results = find_everything(target, stats=stats)
    if not results:
        checked = stats.get("checked", 0)
        errors = stats.get("errors", 0)
        blocked = stats.get("blocked_or_404", 0)
        filtered = stats.get("filtered_soft404", 0)
        saw_block = stats.get("saw_block_status")
        print(f"  Nothing found. Checked {checked} paths: "
              f"{errors} failed to connect, {blocked} returned 4xx/5xx, "
              f"{filtered} looked like the site's soft-404 page.")
        if saw_block in (401, 403, 429):
            print(f"  Note: saw HTTP {saw_block} responses - the site may be")
            print("  blocking automated requests (rate limiting or a WAF/firewall).")
        if errors and stats.get("last_error"):
            print(f"  Example connection error: {stats['last_error']}")
        return results
    for url, info in sorted(results.items()):
        tags = "+".join(info["category"])
        extra = ""
        if info["status"] is not None:
            extra += f" status={info['status']}"
        if info["keywords"]:
            extra += f" keywords={','.join(info['keywords'])}"
        print(f"  [+] {url}  [{tags}]{extra}")
    print()
    print("  A result here means something responded, or the URL/term was")
    print("  found on the site - it does NOT confirm a real page/panel or a")
    print("  vulnerability. Verify manually; no logins are attempted.")
    return results
