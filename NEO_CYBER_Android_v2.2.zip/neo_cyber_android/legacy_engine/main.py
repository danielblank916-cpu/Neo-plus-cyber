"""Interactive menu mode. For scripted/automated use, run cli.py instead."""
import port_scanner
import banner_grabber
import header_checker
import path_finder
import hash_auditor
import url_crawler
from report import save_report_json, save_report_html
from utils import banner, ok, warn, err, info

MENU = """
1) Port scanner (real TCP connect scan)
2) Banner grabber (real service response)
3) Security header checker (real HTTP request)
4) Path finder (common paths + admin paths + site clues, all in one)
5) Hash auditor (dictionary match)
6) URL crawler (real site crawl, finds all URLs)
7) Save session report (JSON + HTML)
8) Quit
"""


def main():
    banner("Pentest Toolkit v1.0 (educational)")
    warn("All modules perform real network requests/connections - nothing is simulated.")
    warn("Only test systems you own or have written permission to test.")

    if input("Confirm you have authorization to test your target (yes/no): ").strip().lower() != "yes":
        err("Authorization not confirmed. Exiting.")
        return

    log = []
    last_target = None
    while True:
        print(MENU)
        choice = input("Choose: ").strip()
        if choice == "8":
            info("Goodbye.")
            break
        if choice == "7":
            if log:
                json_path = save_report_json(log)
                html_path = save_report_html(log, target=last_target or "(multiple)")
                ok(f"Reports saved: {json_path}, {html_path}")
            else:
                warn("Nothing to save yet.")
            continue
        if choice not in {"1", "2", "3", "4", "5", "6"}:
            err("Invalid choice.")
            continue

        if choice == "5":
            hash_auditor.run()
            log.append({"module": "hash_auditor", "target": None, "result": "see console output"})
            continue

        target = input("Target (host or URL): ").strip()
        last_target = target
        if choice == "1":
            port_scanner.run(target)
            log.append({"module": "port_scanner", "target": target})
        elif choice == "2":
            banner_grabber.run(target)
            log.append({"module": "banner_grabber", "target": target})
        elif choice == "3":
            header_checker.run(target)
            log.append({"module": "header_checker", "target": target})
        elif choice == "4":
            results = path_finder.run(target)
            log.append({"module": "path_finder", "target": target, "result": results})
        else:
            urls = url_crawler.run(target)
            log.append({"module": "url_crawler", "target": target, "result": urls})


if __name__ == "__main__":
    main()
