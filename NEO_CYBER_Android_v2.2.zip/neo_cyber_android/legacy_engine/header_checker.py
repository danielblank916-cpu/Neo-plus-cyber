import requests

SECURITY_HEADERS = {
    "Strict-Transport-Security": "Forces HTTPS (HSTS)",
    "Content-Security-Policy": "Helps prevent XSS and injection",
    "X-Frame-Options": "Prevents clickjacking",
    "X-Content-Type-Options": "Prevents MIME sniffing",
    "Referrer-Policy": "Controls referrer information",
    "Permissions-Policy": "Restricts browser features",
}


def check_headers(url, timeout=10):
    """Return (present, missing) dicts of security headers for a URL.
    Raises requests.RequestException (with the real underlying reason)
    if the request itself fails - e.g. DNS failure, TLS error, timeout,
    or the site blocking the request."""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    resp = requests.get(
        url,
        timeout=timeout,
        allow_redirects=True,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0 Safari/537.36"
            )
        },
    )
    resp.raise_for_status()
    present = {h: resp.headers[h] for h in SECURITY_HEADERS if h in resp.headers}
    missing = {h: d for h, d in SECURITY_HEADERS.items() if h not in resp.headers}
    return present, missing


def run(target):
    try:
        present, missing = check_headers(target)
    except requests.exceptions.SSLError as e:
        print(f"TLS/certificate error - the site's HTTPS certificate could not be verified: {e}")
        return
    except requests.exceptions.ConnectionError as e:
        print(f"Connection failed - site unreachable, DNS failure, or it refused the connection: {e}")
        return
    except requests.exceptions.Timeout:
        print("Request timed out - the site took too long to respond.")
        return
    except requests.exceptions.HTTPError as e:
        print(f"Site responded with an error status: {e}")
        return
    except requests.RequestException as e:
        print(f"Request failed: {e}")
        return
    print("Present:")
    for h, v in present.items():
        print(f"  [+] {h}: {v}")
    print("Missing:")
    for h, why in missing.items():
        print(f"  [-] {h} - {why}")
    score = len(present) * 100 // len(SECURITY_HEADERS)
    print(f"Header score: {score}%")
