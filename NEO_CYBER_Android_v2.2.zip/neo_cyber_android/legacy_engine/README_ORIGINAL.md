# Pentest Toolkit

An educational reconnaissance toolkit built for a cyber security course
project. Every module performs **real** network requests/connections
against the target you supply - nothing is simulated or faked.

## Setup

```bash
pip install -r requirements.txt
```

## Usage

### Interactive mode
```bash
python main.py
```
Menu-driven; confirms authorization, then lets you run each module,
and save a report (JSON + HTML) at the end.

### CLI mode (scriptable)
```bash
python cli.py example.com --all --report both -y
python cli.py example.com --ports --headers --report json
python cli.py example.com --clues
```
Run `python cli.py --help` for all flags.

## Modules

| Module                | What it does                                                        |
|------------------------|----------------------------------------------------------------------|
| Port scanner           | Real TCP connect scan + service name lookup                         |
| Banner grabber         | Reads the real response a service sends on connect                  |
| Security header checker| Real HTTP GET, inspects actual response headers                     |
| Path finder            | Real HTTP requests: common recon paths + known admin paths + real site crawl/robots.txt/sitemap keyword clues - all merged into one report |
| URL crawler            | Real HTML parsing, follows same-domain links, lists every URL found |
| Hash auditor           | Dictionary match of a real hash (md5/sha1/sha256) you provide       |
| Report                 | Saves a JSON and a styled HTML report of what ran and what was found|

A log of every run is also written to `pentest_toolkit.log`.

## Legal notice

Use only on systems you own or have explicit written permission to
test (e.g. localhost, a lab VM, `scanme.nmap.org`, or a target your
lecturer has authorized). Testing systems without authorization is
illegal in most jurisdictions. Panel/path finders report only that a
URL responded - they do not attempt logins, credential guessing, or
exploitation of anything they find.
