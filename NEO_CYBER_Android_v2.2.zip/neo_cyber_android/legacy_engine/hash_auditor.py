import hashlib

COMMON_PASSWORDS = [
    "123456", "password", "123456789", "12345678", "12345",
    "qwerty", "abc123", "letmein", "admin", "welcome",
]


def _hash(algo, text):
    h = hashlib.new(algo)
    h.update(text.encode())
    return h.hexdigest()


def crack_hash(target_hash, algo="sha256", wordlist=None):
    """Try to match target_hash against a wordlist of plaintext candidates.
    Returns the matching plaintext, or None if not found."""
    words = wordlist or COMMON_PASSWORDS
    target_hash = target_hash.strip().lower()
    for word in words:
        if _hash(algo, word) == target_hash:
            return word
    return None


def run(_target=None):
    algo = input("Hash algorithm (md5/sha1/sha256) [sha256]: ").strip() or "sha256"
    target_hash = input("Hash to audit: ").strip()
    wl_path = input("Wordlist file (blank = built-in common passwords): ").strip()
    wordlist = None
    if wl_path:
        try:
            with open(wl_path, encoding="utf-8", errors="ignore") as f:
                wordlist = [line.strip() for line in f if line.strip()]
        except OSError as e:
            print(f"Could not read wordlist: {e}")
            return
    print("Auditing ...")
    result = crack_hash(target_hash, algo, wordlist)
    if result:
        print(f"  [+] Match found: '{result}'")
    else:
        print("  [-] No match in wordlist.")
