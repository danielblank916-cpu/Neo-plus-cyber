"""Shared helpers: colored console output and simple logging."""
import logging
from datetime import datetime
from colorama import Fore, Style, init as colorama_init

colorama_init(autoreset=True)

logging.basicConfig(
    filename="pentest_toolkit.log",
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("pentest_toolkit")


def banner(text):
    line = "=" * (len(text) + 4)
    print(f"{Fore.CYAN}{line}\n  {text}\n{line}{Style.RESET_ALL}")


def ok(msg):
    print(f"{Fore.GREEN}[+] {msg}{Style.RESET_ALL}")
    log.info(f"[+] {msg}")


def warn(msg):
    print(f"{Fore.YELLOW}[!] {msg}{Style.RESET_ALL}")
    log.warning(msg)


def err(msg):
    print(f"{Fore.RED}[-] {msg}{Style.RESET_ALL}")
    log.error(msg)


def info(msg):
    print(f"{Fore.BLUE}[*] {msg}{Style.RESET_ALL}")
    log.info(msg)


def timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
