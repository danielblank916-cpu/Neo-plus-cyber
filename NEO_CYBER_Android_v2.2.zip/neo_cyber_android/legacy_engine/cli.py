"""Command-line (non-interactive) mode for scripting / automation."""
import argparse
import sys

import port_scanner
import header_checker
import path_finder
import url_crawler
from report import save_report_json, save_report_html
from utils import banner, info, err


def build_parser():
    p = argparse.ArgumentParser(
        prog="pentest-toolkit",
        description="Educational pentest toolkit - real network requests only. "
                     "Use only on systems you own or have written authorization to test.",
    )
    p.add_argument("target", help="Host or URL to test (e.g. example.com)")
    p.add_argument("--ports", action="store_true", help="Run port scanner")
    p.add_argument("--start-port", type=int, default=1)
    p.add_argument("--end-port", type=int, default=1024)
    p.add_argument("--headers", action="store_true", help="Run security header checker")
    p.add_argument("--paths", action="store_true",
                    help="Run path finder (common paths + admin paths + site clues, all in one)")
    p.add_argument("--crawl", action="store_true", help="Run URL crawler")
    p.add_argument("--all", action="store_true", help="Run every module")
    p.add_argument("--report", choices=["json", "html", "both"], default=None,
                    help="Save a report after running")
    p.add_argument("-y", "--yes", action="store_true",
                    help="Confirm you have authorization (skips the prompt)")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    banner("Pentest Toolkit - CLI mode")

    if not args.yes:
        reply = input(f"Confirm you have authorization to test '{args.target}' (yes/no): ")
        if reply.strip().lower() != "yes":
            err("Authorization not confirmed. Exiting.")
            sys.exit(1)

    log = []

    def run_ports():
        info(f"Port scanning {args.target} ({args.start_port}-{args.end_port})")
        open_ports = port_scanner.scan_ports(args.target, args.start_port, args.end_port)
        log.append({"module": "port_scanner", "target": args.target, "result": open_ports})

    def run_headers():
        info(f"Checking security headers on {args.target}")
        present, missing = header_checker.check_headers(args.target)
        log.append({"module": "header_checker", "target": args.target,
                    "result": {"present": present, "missing": missing}})

    def run_paths():
        info(f"Finding paths on {args.target} (common + admin + site clues)")
        results = path_finder.find_everything(args.target)
        log.append({"module": "path_finder", "target": args.target, "result": results})

    def run_crawl():
        info(f"Crawling {args.target}")
        urls = url_crawler.crawl(args.target)
        log.append({"module": "url_crawler", "target": args.target, "result": urls})

    tasks = {"ports": run_ports, "headers": run_headers, "paths": run_paths, "crawl": run_crawl}

    ran_any = False
    for name, fn in tasks.items():
        if args.all or getattr(args, name):
            fn()
            ran_any = True

    if not ran_any:
        err("No module selected. Use --all or a specific flag (see --help).")
        sys.exit(1)

    if args.report:
        if args.report in ("json", "both"):
            path = save_report_json(log)
            info(f"JSON report saved to {path}")
        if args.report in ("html", "both"):
            path = save_report_html(log, target=args.target)
            info(f"HTML report saved to {path}")

    info("Done.")


if __name__ == "__main__":
    main()
