import socket
import ssl

COMMON_TLS_PORTS = {443, 8443, 465, 993, 995}


def _grab_plain(host, port, timeout):
    with socket.create_connection((host, port), timeout=timeout) as s:
        s.settimeout(timeout)
        try:
            data = s.recv(1024)
        except socket.timeout:
            # Some services (like plain HTTP) wait for a request first
            s.sendall(b"HEAD / HTTP/1.0\r\nHost: %b\r\n\r\n" % host.encode())
            data = s.recv(1024)
        return data


def _grab_tls(host, port, timeout):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE  # we're only reading a banner, not validating trust
    with socket.create_connection((host, port), timeout=timeout) as raw:
        with ctx.wrap_socket(raw, server_hostname=host) as s:
            s.settimeout(timeout)
            try:
                data = s.recv(1024)
            except socket.timeout:
                s.sendall(b"HEAD / HTTP/1.0\r\nHost: %b\r\n\r\n" % host.encode())
                data = s.recv(1024)
            return data


def grab_banner(host, port, timeout=3.0):
    """Connect to a port and return whatever banner the service sends.
    Tries a plain TCP connection first; if that's refused or yields
    garbage (common on HTTPS-only ports like 443), retries over TLS -
    plain sockets can't read anything from a TLS port because the
    server is waiting for a TLS handshake, not plain text."""
    try:
        if port in COMMON_TLS_PORTS:
            data = _grab_tls(host, port, timeout)
        else:
            data = _grab_plain(host, port, timeout)
        text = data.decode(errors="ignore").strip()
        if text:
            return text
    except (OSError, ssl.SSLError):
        pass

    # Fallback: try the other mode in case our port-based guess was wrong
    try:
        if port in COMMON_TLS_PORTS:
            data = _grab_plain(host, port, timeout)
        else:
            data = _grab_tls(host, port, timeout)
        return data.decode(errors="ignore").strip()
    except (OSError, ssl.SSLError) as e:
        return f"Error: {e}"


def run(host):
    port = int(input("Port [443]: ") or 443)
    print(f"Banner from {host}:{port}")
    print(grab_banner(host, port) or "(no banner - service sent nothing readable)")
