import socket
from concurrent.futures import ThreadPoolExecutor


def _check(host, port, timeout):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return port
    except OSError:
        return None


def scan_ports(host, start=1, end=1024, timeout=1.0, threads=100):
    """Return a sorted list of open TCP ports on host."""
    ports = range(start, end + 1)
    with ThreadPoolExecutor(threads) as ex:
        results = ex.map(lambda p: _check(host, p, timeout), ports)
    return [p for p in results if p]


def run(host):
    start = int(input("Start port [1]: ") or 1)
    end = int(input("End port [1024]: ") or 1024)
    print(f"Scanning {host} ports {start}-{end} ...")
    open_ports = scan_ports(host, start, end)
    if open_ports:
        for p in open_ports:
            try:
                service = socket.getservbyport(p)
            except OSError:
                service = "unknown"
            print(f"  [+] Port {p} open ({service})")
    else:
        print("  No open ports found.")
