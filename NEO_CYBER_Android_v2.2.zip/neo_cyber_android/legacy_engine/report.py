import json
from datetime import datetime, timezone


def save_report_json(entries, path="report.json"):
    report = {"generated": datetime.now(timezone.utc).isoformat(), "entries": entries}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    return path


def save_report_html(entries, path="report.html", target="(multiple)"):
    rows = ""
    for e in entries:
        module = e.get("module", "")
        tgt = e.get("target", "") or ""
        result = e.get("result", "")
        if isinstance(result, (list, dict)):
            result_html = "<pre>" + json.dumps(result, indent=2) + "</pre>"
        else:
            result_html = str(result)
        rows += (
            f"<tr><td>{module}</td><td>{tgt}</td><td>{result_html}</td></tr>\n"
        )

    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Pentest Toolkit Report</title>
<style>
  body {{ font-family: Arial, sans-serif; margin: 2rem; background: #0f172a; color: #e2e8f0; }}
  h1 {{ color: #38bdf8; }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 1rem; }}
  th, td {{ border: 1px solid #334155; padding: 8px; text-align: left; vertical-align: top; }}
  th {{ background: #1e293b; color: #38bdf8; }}
  tr:nth-child(even) {{ background: #1e293b; }}
  pre {{ white-space: pre-wrap; word-break: break-all; margin: 0; }}
  .meta {{ color: #94a3b8; }}
</style>
</head>
<body>
  <h1>Pentest Toolkit Report</h1>
  <p class="meta">Target: {target}<br>Generated: {datetime.now(timezone.utc).isoformat()}</p>
  <table>
    <tr><th>Module</th><th>Target</th><th>Result</th></tr>
    {rows}
  </table>
</body>
</html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return path
