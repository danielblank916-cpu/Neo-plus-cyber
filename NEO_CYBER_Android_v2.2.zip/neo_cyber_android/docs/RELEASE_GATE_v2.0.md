# NEO CYBER v2.0 release gate

Status: source release candidate; not yet production-certified.

## Automated build checks
- [ ] `flutter pub get` completes successfully.
- [ ] `flutter analyze` completes with no errors; all warnings reviewed.
- [ ] `flutter test` passes.
- [ ] Android platform project and Gradle configuration are present and valid.
- [ ] Android manifest includes only required permissions, including INTERNET for network functions.
- [ ] `flutter build apk --release` succeeds.
- [ ] APK SHA-256 and build logs are archived.

## Physical Android acceptance checks
- [ ] Install and launch on a non-rooted Android phone.
- [ ] TCP scanner: authorized target, bounded ports, timeout, cancellation, and history.
- [ ] HTTP checker and passive assessment: valid TLS, redirects/errors, cookies, report and PDF.
- [ ] HTTP workbench: supported methods, bounded response display, invalid URL and TLS errors.
- [ ] PCAP/PCAPNG: valid classic and nanosecond PCAP, PCAPNG timestamp resolutions/offsets, malformed/truncated input, and unsupported link types.
- [ ] Local proxy: loopback-only bind, client cap, oversized headers, timeout, CONNECT tunnel, stop/restart.
- [ ] History: persistence across restart, search/filter/sort, delete and clear.
- [ ] App lifecycle: background/foreground, network changes, permission denial, low storage, and interrupted operations.

## Release decision
Do not label the app production-ready or distribute it as a tested APK until all required checks are completed and device/build evidence is recorded. A successful ZIP integrity check is not a substitute for compilation or device testing.
