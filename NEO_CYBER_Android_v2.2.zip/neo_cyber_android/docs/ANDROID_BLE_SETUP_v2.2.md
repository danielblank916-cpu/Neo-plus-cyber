# NEO CYBER v2.2 — Android BLE setup

The Bluetooth panel uses `flutter_blue_plus` for foreground Bluetooth Low Energy (BLE) scanning, connection, GATT service discovery, and reads of characteristics that advertise the `read` property. It deliberately does not write characteristics, subscribe to notifications, run background scans, or control devices without an authenticated device-specific protocol.

## Android manifest permissions

Merge these declarations into `android/app/src/main/AndroidManifest.xml` inside the root `<manifest>` element (not inside `<application>`):

```xml
<uses-feature android:name="android.hardware.bluetooth_le" android:required="false" />
<uses-permission android:name="android.permission.BLUETOOTH_SCAN" />
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30" />
```

For Android 12 (API 31) and later, the app requests `BLUETOOTH_SCAN` and `BLUETOOTH_CONNECT` at runtime. `neverForLocation` is intentionally not asserted in the manifest because some BLE beacon payloads can be location-relevant; the app does not collect or infer the user's location. On Android 11 and earlier, BLE scanning also requires location permission and the legacy location permission flow; this v2.2 UI currently targets Android 12+ for the fully managed permission path.

## Build requirements

- Flutter SDK compatible with Dart `>=3.3.0 <4.0.0`.
- Android `minSdk` at least 21; use a current compile/target SDK supported by the installed Flutter and plugins.
- Run `flutter pub get` after adding the dependencies in `pubspec.yaml`.
- Merge the manifest declarations above into the full Android project scaffold before building an APK.

## User-visible limits

- This is BLE discovery, not universal Bluetooth discovery. Classic Bluetooth-only accessories may not appear.
- A device may advertise anonymously or expose no readable characteristics.
- GATT read access is determined by the peripheral; encrypted or authenticated characteristics may reject reads.
- A successful connection does not imply ownership or authorization. Only connect to devices you own or have explicit permission to inspect.
- No pairing/bonding workflow, writes, firmware updates, or remote-control commands are implemented in this milestone.
