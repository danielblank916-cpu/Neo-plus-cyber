import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'local_proxy.dart';
import 'vulnerability_assessment.dart';

void main() => runApp(const NeoCyberApp());

const _bg = Color(0xFF080D18);
const _panel = Color(0xFF111A2B);
const _blue = Color(0xFF36A7FF);
const _headers = <String, String>{
  'Strict-Transport-Security': 'Enforces HTTPS for supported browsers',
  'Content-Security-Policy': 'Helps reduce cross-site scripting and injection risk',
  'X-Frame-Options': 'Helps prevent clickjacking',
  'X-Content-Type-Options': 'Prevents MIME-type sniffing',
  'Referrer-Policy': 'Controls referrer information sent by the browser',
  'Permissions-Policy': 'Restricts access to browser features',
};

class NeoCyberApp extends StatelessWidget {
  const NeoCyberApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NEO CYBER',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: _bg,
          colorScheme: ColorScheme.fromSeed(
            seedColor: _blue,
            brightness: Brightness.dark,
          ),
          cardTheme: const CardThemeData(color: _panel, elevation: 0),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: _panel,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        home: const HomeShell(),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      DashboardPage(onOpenScanner: () => setState(() => index = 1),
          onOpenWebCheck: () => setState(() => index = 2),
          onOpenPackets: () => setState(() => index = 3),
          onOpenProxy: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const HttpInspectorPage())),
          onOpenLocalProxy: () => setState(() => index = 6),
          onOpenVulnerability: () => setState(() => index = 7)),
      const ScannerPage(),
      const WebCheckPage(),
      const PacketAnalyzerPage(),
      const HistoryPage(),
      const AboutPage(),
      const LocalProxyPage(),
      const VulnerabilityAssessmentPage(),
      const DeviceControlPage(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        backgroundColor: _panel,
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.radar), label: 'Ports'),
          NavigationDestination(icon: Icon(Icons.language), label: 'Web'),
          NavigationDestination(icon: Icon(Icons.graphic_eq), label: 'Packets'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'About'),
          NavigationDestination(icon: Icon(Icons.swap_horiz), label: 'Proxy'),
          NavigationDestination(icon: Icon(Icons.bug_report_outlined), label: 'Assess'),
          NavigationDestination(icon: Icon(Icons.devices_other), label: 'Devices'),
        ],
      ),
    );
  }
}

enum ManagedDeviceType { android, computer, router, camera, iot, bluetooth }

class ManagedDevice {
  final String id;
  final String name;
  final ManagedDeviceType type;
  final String host;
  final int port;
  final DateTime addedAt;
  final DateTime? lastCheckedAt;
  final bool? reachable;

  const ManagedDevice({required this.id, required this.name, required this.type,
    required this.host, required this.port, required this.addedAt,
    this.lastCheckedAt, this.reachable});

  ManagedDevice copyWith({DateTime? lastCheckedAt, bool? reachable}) => ManagedDevice(
    id: id, name: name, type: type, host: host, port: port, addedAt: addedAt,
    lastCheckedAt: lastCheckedAt ?? this.lastCheckedAt,
    reachable: reachable ?? this.reachable);

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'type': type.name,
    'host': host, 'port': port, 'addedAt': addedAt.toIso8601String(),
    'lastCheckedAt': lastCheckedAt?.toIso8601String(), 'reachable': reachable};

  factory ManagedDevice.fromJson(Map<String, dynamic> j) => ManagedDevice(
    id: j['id'] as String, name: j['name'] as String,
    type: ManagedDeviceType.values.firstWhere((e) => e.name == j['type'], orElse: () => ManagedDeviceType.iot),
    host: j['host'] as String, port: j['port'] as int,
    addedAt: DateTime.parse(j['addedAt'] as String),
    lastCheckedAt: j['lastCheckedAt'] == null ? null : DateTime.tryParse(j['lastCheckedAt'] as String),
    reachable: j['reachable'] as bool?);
}

class DeviceControlPage extends StatefulWidget {
  const DeviceControlPage({super.key});
  @override
  State<DeviceControlPage> createState() => _DeviceControlPageState();
}

class _DeviceControlPageState extends State<DeviceControlPage> {
  static const _storageKey = 'neo_device_inventory_v1';
  final List<ManagedDevice> _devices = [];
  final Set<String> _checking = {};
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw != null) {
        final decoded = jsonDecode(raw) as List<dynamic>;
        _devices.addAll(decoded.map((e) => ManagedDevice.fromJson(Map<String, dynamic>.from(e as Map))));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved device inventory could not be read.')));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(_devices.map((d) => d.toJson()).toList()));
  }

  Future<void> _addDevice() async {
    final name = TextEditingController();
    final host = TextEditingController();
    final port = TextEditingController(text: '80');
    ManagedDeviceType type = ManagedDeviceType.android;
    final formKey = GlobalKey<FormState>();
    final accepted = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(
      builder: (context, refresh) => AlertDialog(
        title: const Text('Enroll a device'),
        content: Form(key: formKey, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Add a device you own or are explicitly authorized to manage. This stores an inventory entry only; it does not grant access.', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 14),
          TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Device name'), validator: (v) => v == null || v.trim().isEmpty ? 'Enter a name' : null),
          const SizedBox(height: 10),
          DropdownButtonFormField<ManagedDeviceType>(value: type, decoration: const InputDecoration(labelText: 'Device category'), items: ManagedDeviceType.values.map((t) => DropdownMenuItem(value: t, child: Text(_typeLabel(t)))).toList(), onChanged: (v) { if (v != null) refresh(() { type = v; }); }),
          const SizedBox(height: 10),
          TextFormField(controller: host, decoration: const InputDecoration(labelText: 'IP address or hostname', hintText: '192.168.1.20'), validator: (v) => v == null || v.trim().isEmpty ? 'Enter a host' : (v.contains(RegExp(r'\s')) ? 'Host cannot contain spaces' : null)),
          const SizedBox(height: 10),
          TextFormField(controller: port, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'TCP port'), validator: (v) { final n = int.tryParse(v ?? ''); return n == null || n < 1 || n > 65535 ? 'Enter a port from 1 to 65535' : null; }),
        ]))),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')), FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(dialogContext, true); }, child: const Text('SAVE'))],
      )));
    if (accepted == true && mounted) {
      final device = ManagedDevice(id: '${DateTime.now().microsecondsSinceEpoch}', name: name.text.trim(), type: type, host: host.text.trim(), port: int.parse(port.text), addedAt: DateTime.now());
      setState(() => _devices.add(device));
      await _save();
    }
    name.dispose(); host.dispose(); port.dispose();
  }

  Future<void> _check(ManagedDevice device) async {
    if (_checking.contains(device.id)) return;
    setState(() => _checking.add(device.id));
    bool reachable = false;
    Socket? socket;
    try {
      socket = await Socket.connect(device.host, device.port, timeout: const Duration(seconds: 3));
      reachable = true;
    } on SocketException { reachable = false; }
      on TimeoutException { reachable = false; }
      catch (_) { reachable = false; }
      finally { socket?.destroy(); }
    final i = _devices.indexWhere((d) => d.id == device.id);
    if (i >= 0) _devices[i] = _devices[i].copyWith(lastCheckedAt: DateTime.now(), reachable: reachable);
    if (mounted) setState(() => _checking.remove(device.id));
    await _save();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reachable ? 'TCP connection succeeded. This confirms reachability only.' : 'No TCP connection on ${device.host}:${device.port}. The device may be offline or the port may be closed.')));
  }

  Future<void> _remove(ManagedDevice device) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('Remove device?'), content: Text('Remove ${device.name} from this phone’s inventory? This does not change the device itself.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('REMOVE'))]));
    if (ok == true) { setState(() => _devices.removeWhere((d) => d.id == device.id)); await _save(); }
  }

  static String _typeLabel(ManagedDeviceType t) => switch (t) {
    ManagedDeviceType.android => 'Android phone', ManagedDeviceType.computer => 'Computer / laptop',
    ManagedDeviceType.router => 'Router', ManagedDeviceType.camera => 'Camera',
    ManagedDeviceType.iot => 'Other IoT device', ManagedDeviceType.bluetooth => 'Bluetooth device'};
  IconData _typeIcon(ManagedDeviceType t) => switch (t) {
    ManagedDeviceType.android => Icons.phone_android, ManagedDeviceType.computer => Icons.computer,
    ManagedDeviceType.router => Icons.router, ManagedDeviceType.camera => Icons.videocam,
    ManagedDeviceType.iot => Icons.sensors, ManagedDeviceType.bluetooth => Icons.bluetooth};

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const SizedBox(height: 8),
    const Text('NEO DEVICE CONTROL', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1)),
    const SizedBox(height: 6), const Text('Authorized device inventory', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 18),
    Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: _blue.withOpacity(.35))), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(Icons.verified_user, color: _blue), SizedBox(width: 8), Text('CONTROL FOUNDATION', style: TextStyle(fontWeight: FontWeight.bold))]),
      SizedBox(height: 8), Text('Enroll devices you own or have permission to manage. A connection check only tests one TCP host and port; it does not authenticate or control the device. Remote actions will be added only with secure device-side support.', style: TextStyle(color: Colors.white70, height: 1.4)),
    ])),
    const SizedBox(height: 18),
    Row(children: [Expanded(child: Text('ENROLLED DEVICES (${_devices.length})', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: .8))), FilledButton.icon(onPressed: _addDevice, icon: const Icon(Icons.add), label: const Text('ADD DEVICE'))]),
    const SizedBox(height: 10),
    if (_loading) const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()))
    else if (_devices.isEmpty) Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(16)), child: const Column(children: [Icon(Icons.devices_other, size: 38, color: Colors.white38), SizedBox(height: 10), Text('No devices enrolled', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(height: 5), Text('Add a device to create your private inventory. No sample devices are included.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60))]))
    else ..._devices.map((d) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(_typeIcon(d.type), color: _blue), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(d.name, style: const TextStyle(fontWeight: FontWeight.bold)), Text('${_typeLabel(d.type)} • ${d.host}:${d.port}', style: const TextStyle(color: Colors.white60, fontSize: 12))])), IconButton(tooltip: 'Remove from inventory', onPressed: () => _remove(d), icon: const Icon(Icons.delete_outline))]),
      const SizedBox(height: 6),
      Row(children: [Expanded(child: Text(d.lastCheckedAt == null ? 'Status: Not checked' : 'TCP: ${d.reachable == true ? 'Reachable' : 'Not reachable'} • ${TimeOfDay.fromDateTime(d.lastCheckedAt!).format(context)}', style: TextStyle(color: d.reachable == true ? Colors.lightGreenAccent : Colors.white60, fontSize: 12))), OutlinedButton.icon(onPressed: _checking.contains(d.id) ? null : () => _check(d), icon: _checking.contains(d.id) ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.wifi_tethering, size: 16), label: const Text('CHECK'))]),
    ]))))),
    const SizedBox(height: 14),
    const Text('NOT YET IMPLEMENTED', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white70, letterSpacing: .8)),
    const SizedBox(height: 6),
    const Text('Bluetooth pairing and GATT controls • Android companion enrollment • Windows/Linux agent • router administration • ONVIF camera controls • IoT vendor integrations. These will appear only when their real permissions, protocols and authenticated backends are implemented.', style: TextStyle(color: Colors.white54, height: 1.4)),
  ]);
}

class DashboardPage extends StatelessWidget {
  final VoidCallback onOpenScanner;
  final VoidCallback onOpenWebCheck;
  final VoidCallback onOpenPackets;
  final VoidCallback onOpenProxy;
  final VoidCallback onOpenLocalProxy;
  final VoidCallback onOpenVulnerability;
  const DashboardPage({super.key, required this.onOpenScanner, required this.onOpenWebCheck, required this.onOpenPackets, required this.onOpenProxy, required this.onOpenLocalProxy, required this.onOpenVulnerability});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 12),
          Row(children: [
            Container(width: 46, height: 46,
              decoration: BoxDecoration(color: _blue.withOpacity(.14), borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.shield_moon, color: _blue, size: 28)),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('NEO CYBER', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              Text('Mobile Security Assessment', style: TextStyle(color: Colors.white60)),
            ])),
            const Chip(label: Text('ANDROID')),
          ]),
          const SizedBox(height: 26),
          Container(padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF123B66), Color(0xFF14213A)]), borderRadius: BorderRadius.circular(22)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('YOUR MOBILE SECURITY LAB', style: TextStyle(color: Colors.white70, letterSpacing: 1.1, fontSize: 11)),
              SizedBox(height: 10), Text('Assess. Understand. Secure.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
              SizedBox(height: 8), Text('Run permitted checks directly from your Android phone. No root access or laptop required for supported features.', style: TextStyle(color: Colors.white70, height: 1.4)),
            ])),
          const SizedBox(height: 22),
          const Text('AVAILABLE TOOLS', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
          const SizedBox(height: 12),
          GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.25, children: [
            ToolTile(icon: Icons.radar, title: 'TCP Port Scanner', subtitle: 'Bounded connect scan', status: 'READY', onTap: onOpenScanner),
            ToolTile(icon: Icons.language, title: 'Web Header Check', subtitle: 'Passive HTTP checks', status: 'READY', onTap: onOpenWebCheck),
            ToolTile(icon: Icons.graphic_eq, title: 'Packet Analyzer', subtitle: 'Import and inspect PCAP files', status: 'READY', onTap: onOpenPackets),
            ToolTile(icon: Icons.http, title: 'HTTP Inspector', subtitle: 'Manual request / response', status: 'READY', onTap: onOpenProxy),
            ToolTile(icon: Icons.swap_horiz, title: 'Local HTTP Proxy', subtitle: 'Explicit local forwarding', status: 'READY', onTap: onOpenLocalProxy),
            ToolTile(icon: Icons.bug_report_outlined, title: 'Web Assessment', subtitle: 'Passive config & cookie checks', status: 'READY', onTap: onOpenVulnerability),
          ]),
          const SizedBox(height: 16),
          const Text('Only test devices and websites you own or have explicit permission to assess.', style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      );
}

class ToolTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle, status;
  final VoidCallback? onTap;
  const ToolTile({super.key, required this.icon, required this.title, required this.subtitle, required this.status, this.onTap});

  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14),
          child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(icon, color: _blue, size: 24), const Spacer(), Text(status, style: const TextStyle(fontSize: 9, color: Colors.lightBlueAccent, fontWeight: FontWeight.bold))]),
            const Spacer(), Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
          ])),
        ),
      );
}

class ScanRecord {
  final String type, target, summary, timestamp;
  final List<Map<String, dynamic>> details;
  ScanRecord({required this.type, required this.target, required this.summary, required this.timestamp, this.details = const []});
  Map<String, dynamic> toJson() => {'type': type, 'target': target, 'summary': summary, 'timestamp': timestamp, 'details': details};
  factory ScanRecord.fromJson(Map<String, dynamic> json) => ScanRecord(
    type: json['type'] as String? ?? 'Assessment', target: json['target'] as String? ?? '',
    summary: json['summary'] as String? ?? '', timestamp: json['timestamp'] as String? ?? '',
    details: (json['details'] as List<dynamic>? ?? const []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList());
}

class HistoryStore {
  static const _key = 'neo_cyber_history_v1';
  static Future<void> add(ScanRecord record) async {
    final prefs = await SharedPreferences.getInstance();
    final items = prefs.getStringList(_key) ?? <String>[];
    items.insert(0, jsonEncode(record.toJson()));
    await prefs.setStringList(_key, items.take(100).toList());
  }
  static Future<List<ScanRecord>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final items = prefs.getStringList(_key) ?? <String>[];
    return items.map((s) {
      try { return ScanRecord.fromJson(jsonDecode(s) as Map<String, dynamic>); }
      catch (_) { return null; }
    }).whereType<ScanRecord>().toList();
  }
  static Future<void> remove(ScanRecord record) async {
    final prefs = await SharedPreferences.getInstance();
    final items = prefs.getStringList(_key) ?? <String>[];
    items.removeWhere((raw) {
      try { final value = ScanRecord.fromJson(jsonDecode(raw) as Map<String, dynamic>);
        return value.type == record.type && value.target == record.target && value.timestamp == record.timestamp;
      } catch (_) { return false; }
    });
    await prefs.setStringList(_key, items);
  }
  static Future<void> clear() async => (await SharedPreferences.getInstance()).remove(_key);
}

String _now() => DateTime.now().toLocal().toString().substring(0, 16);

class ServiceFinding {
  final int port;
  final String service;
  final String detail;
  const ServiceFinding(this.port, this.service, this.detail);
}

String _serviceName(int port) => const <int, String>{
  20: 'FTP-DATA', 21: 'FTP', 22: 'SSH', 23: 'TELNET', 25: 'SMTP',
  53: 'DNS', 80: 'HTTP', 110: 'POP3', 111: 'RPCBIND', 123: 'NTP',
  135: 'MS-RPC', 139: 'NETBIOS', 143: 'IMAP', 389: 'LDAP',
  443: 'HTTPS/TLS', 445: 'SMB', 465: 'SMTPS', 587: 'SMTP-SUBMISSION',
  631: 'IPP', 993: 'IMAPS', 995: 'POP3S', 1433: 'MS-SQL',
  1521: 'ORACLE-DB', 2049: 'NFS', 3306: 'MYSQL', 3389: 'RDP',
  5432: 'POSTGRESQL', 5900: 'VNC', 6379: 'REDIS', 8080: 'HTTP-ALT',
  8443: 'HTTPS-ALT', 27017: 'MONGODB',
}[port] ?? 'Unknown / custom';

String _cleanBanner(List<int> bytes) {
  final raw = utf8.decode(bytes, allowMalformed: true);
  return raw.replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ').trim();
}

Future<ServiceFinding> _identifyService(String host, int port, int timeoutMs) async {
  final service = _serviceName(port);
  final httpPorts = <int>{80, 81, 3000, 5000, 8000, 8008, 8080, 8081, 8888, 9000};
  Socket? socket;
  try {
    socket = await Socket.connect(host, port, timeout: Duration(milliseconds: timeoutMs));
    if (httpPorts.contains(port)) {
      socket.write('HEAD / HTTP/1.0\r\nHost: $host\r\nUser-Agent: NEO-CYBER-Service-Check\r\nConnection: close\r\n\r\n');
    }
    final firstChunk = await socket.first.timeout(Duration(milliseconds: timeoutMs));
    final banner = _cleanBanner(firstChunk.take(512).toList());
    if (banner.isNotEmpty) {
      return ServiceFinding(port, service, banner.length > 180 ? '${banner.substring(0, 180)}…' : banner);
    }
    return ServiceFinding(port, service, httpPorts.contains(port) ? 'Connected; no HTTP response banner received.' : 'TCP connection accepted; service not fingerprinted.');
  } on TimeoutException {
    return ServiceFinding(port, service, 'TCP open; service did not send a banner within the time limit.');
  } catch (_) {
    return ServiceFinding(port, service, 'TCP open; service identification unavailable.');
  } finally {
    socket?.destroy();
  }
}

class ScannerPage extends StatefulWidget {
  const ScannerPage({super.key});
  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> {
  final host = TextEditingController();
  final start = TextEditingController(text: '1');
  final end = TextEditingController(text: '128');
  bool authorized = false, running = false, cancelRequested = false;
  int checked = 0;
  List<ServiceFinding> findings = [];
  List<int> openPorts = [];
  String status = 'Ready';
  int total = 128;
  int timeoutMs = 800;

  @override
  void dispose() { host.dispose(); start.dispose(); end.dispose(); super.dispose(); }

  String _csvCell(String value) => '"${value.replaceAll('"', '""')}"';

  Future<void> copyResultsCsv() async {
    if (findings.isEmpty) return;
    final rows = <List<String>>[
      ['Target', 'Port', 'Protocol', 'Service hint', 'Observed banner / result'],
      ...findings.map((f) => [host.text.trim(), f.port.toString(), 'TCP', f.service, f.detail]),
    ];
    final csv = rows.map((row) => row.map(_csvCell).join(',')).join('\r\n');
    await Clipboard.setData(ClipboardData(text: csv));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Scan results copied as CSV.')));
  }

  Future<void> runScan() async {
    final target = host.text.trim();
    final first = int.tryParse(start.text);
    final last = int.tryParse(end.text);
    if (!authorized) { setState(() => status = 'Confirm authorization before scanning.'); return; }
    if (target.isEmpty || first == null || last == null || first < 1 || last > 65535 || first > last || last - first > 127) {
      setState(() => status = 'Enter a host and a valid range of up to 128 ports.'); return;
    }
    setState(() { running = true; cancelRequested = false; checked = 0; findings = []; openPorts = []; total = last - first + 1; status = 'Checking TCP ports on $target (timeout: ${timeoutMs}ms)...'; });
    final open = <int>[];
    for (var port = first; port <= last; port++) {
      if (cancelRequested || !mounted) break;
      try {
        final socket = await Socket.connect(target, port, timeout: Duration(milliseconds: timeoutMs));
        socket.destroy();
        open.add(port);
        if (mounted) setState(() => openPorts = List<int>.from(open));
      } on SocketException catch (_) {} on TimeoutException catch (_) {} catch (_) {}
      if (!mounted) return;
      setState(() { checked++; status = 'Port scan: $checked of $total checked'; });
    }
    final identified = <ServiceFinding>[];
    if (!cancelRequested && open.isNotEmpty) {
      if (mounted) setState(() => status = 'Identifying ${open.length} open service(s)...');
      for (final port in open) {
        if (cancelRequested || !mounted) break;
        identified.add(await _identifyService(target, port, timeoutMs));
        if (mounted) setState(() => findings = List<ServiceFinding>.from(identified));
      }
    }
    final wasCancelled = cancelRequested;
    final summary = '${open.length} open TCP port(s): ${open.isEmpty ? 'none detected' : open.join(', ')}';
    final serviceSummary = identified.isEmpty ? '' : ' Services: ${identified.map((f) => '${f.port}/${f.service}').join(', ')}';
    await HistoryStore.add(ScanRecord(type: 'TCP scan + service identification', target: target,
      summary: '${wasCancelled ? 'Cancelled. ' : ''}$summary. Timeout: ${timeoutMs}ms.$serviceSummary', timestamp: _now(),
      details: identified.map((f) => <String, dynamic>{
        'level': 'info', 'title': '${f.port}/tcp - ${f.service}',
        'evidence': f.detail,
        'recommendation': 'Confirm that this service is expected, keep it updated, and restrict network access to trusted clients.',
      }).toList()));
    if (!mounted) return;
    setState(() { running = false; status = wasCancelled ? 'Scan cancelled. $summary' : 'Finished. $summary'; });
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('TCP PORT SCANNER', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6), const Text('Bounded TCP connect scan with adjustable per-port timeout, conservative service-name mapping and limited banner identification.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 20),
    TextField(controller: host, autocorrect: false, decoration: const InputDecoration(labelText: 'Target hostname or IP', hintText: 'e.g. 192.168.1.10')),
    const SizedBox(height: 12),
    Row(children: [Expanded(child: TextField(controller: start, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Start port'))), const SizedBox(width: 10), Expanded(child: TextField(controller: end, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'End port'))]),
    const SizedBox(height: 12),
    DropdownButtonFormField<int>(value: timeoutMs, decoration: const InputDecoration(labelText: 'Connection timeout', helperText: 'Longer timeouts may help on slower networks.'), items: const [
      DropdownMenuItem(value: 400, child: Text('Fast · 400 ms')),
      DropdownMenuItem(value: 800, child: Text('Balanced · 800 ms')),
      DropdownMenuItem(value: 1500, child: Text('Patient · 1,500 ms')),
      DropdownMenuItem(value: 2500, child: Text('Slow networks · 2,500 ms')),
    ], onChanged: running ? null : (value) { if (value != null) setState(() => timeoutMs = value); }),
    const SizedBox(height: 12),
    Card(child: CheckboxListTile(value: authorized, onChanged: running ? null : (v) => setState(() => authorized = v ?? false), title: const Text('I own this target or have written permission to test it.'), controlAffinity: ListTileControlAffinity.leading)),
    const SizedBox(height: 14),
    Row(children: [Expanded(child: FilledButton.icon(onPressed: running ? null : runScan, icon: const Icon(Icons.play_arrow), label: const Text('Start scan'))), if (running) ...[const SizedBox(width: 10), OutlinedButton.icon(onPressed: () => setState(() { cancelRequested = true; status = 'Stopping after current check...'; }), icon: const Icon(Icons.stop), label: const Text('Stop'))]]),
    const SizedBox(height: 14),
    if (running) LinearProgressIndicator(value: total == 0 ? 0 : (checked / total).clamp(0.0, 1.0)),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('SCAN STATUS', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), Text(status),
      const SizedBox(height: 12), Text('Open ports: ${openPorts.isEmpty ? 'None detected yet' : openPorts.join(', ')}', style: const TextStyle(color: Colors.lightBlueAccent)),
    ]))),
    if (findings.isNotEmpty) ...[
      const SizedBox(height: 12),
      Row(children: [const Expanded(child: Text('SERVICE IDENTIFICATION', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1))), OutlinedButton.icon(onPressed: copyResultsCsv, icon: const Icon(Icons.copy, size: 16), label: const Text('Copy CSV'))]),
      const SizedBox(height: 8),
      ...findings.map((f) => Card(child: ListTile(
        leading: const Icon(Icons.dns, color: _blue),
        title: Text('${f.port}/tcp  •  ${f.service}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        subtitle: Text(f.detail, style: const TextStyle(color: Colors.white60, fontSize: 12)),
      ))),
    ],
    const SizedBox(height: 12),
    const Text('This is not the full Nmap engine. Service names are common-port hints; banners are best-effort and may be absent or misleading. TLS services are not decrypted. Android networking, routing and target firewalls affect results.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4)),
  ]);
}

class WebCheckPage extends StatefulWidget {
  const WebCheckPage({super.key});
  @override
  State<WebCheckPage> createState() => _WebCheckPageState();
}

class _WebCheckPageState extends State<WebCheckPage> {
  final urlController = TextEditingController();
  bool authorized = false, running = false;
  Uri? finalUri;
  Map<String, String> present = {};
  List<String> missing = [];
  String status = 'Ready';
  int? score;

  @override
  void dispose() { urlController.dispose(); super.dispose(); }

  Future<void> checkHeaders() async {
    if (!authorized) { setState(() => status = 'Confirm authorization before testing.'); return; }
    var raw = urlController.text.trim();
    if (raw.isEmpty) { setState(() => status = 'Enter a website hostname or URL.'); return; }
    if (!raw.contains('://')) raw = 'https://$raw';
    final uri = Uri.tryParse(raw);
    if (uri == null || !uri.hasAuthority || (uri.scheme != 'https' && uri.scheme != 'http')) {
      setState(() => status = 'Enter a valid HTTP or HTTPS URL.'); return;
    }
    setState(() { running = true; status = 'Checking security headers...'; present = {}; missing = []; score = null; finalUri = null; });
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10)..userAgent = 'NEO-CYBER-Mobile-Security-Checker/0.2';
    try {
      final request = await client.getUrl(uri).timeout(const Duration(seconds: 12));
      final response = await request.close().timeout(const Duration(seconds: 12));
      final found = <String, String>{};
      final absent = <String>[];
      for (final header in _headers.keys) {
        final value = response.headers.value(header);
        if (value != null) { found[header] = value; } else { absent.add(header); }
      }
      final resolved = response.redirects.isNotEmpty
          ? uri.resolveUri(response.redirects.last.location)
          : uri;
      await response.drain<void>();
      final calculated = (found.length * 100 / _headers.length).round();
      await HistoryStore.add(ScanRecord(type: 'Web header check', target: uri.host, summary: 'Header presence score: $calculated% (${found.length}/${_headers.length})', timestamp: _now()));
      if (!mounted) return;
      setState(() { present = found; missing = absent; score = calculated; finalUri = resolved; running = false; status = 'Completed. Review missing headers and site-specific requirements.'; });
    } on SocketException catch (e) {
      if (mounted) setState(() { running = false; status = 'Connection failed: ${e.message}'; });
    } on TimeoutException {
      if (mounted) setState(() { running = false; status = 'Request timed out.'; });
    } on HandshakeException {
      if (mounted) setState(() { running = false; status = 'TLS certificate or handshake error.'; });
    } catch (e) {
      if (mounted) setState(() { running = false; status = 'Request failed: $e'; });
    } finally { client.close(force: true); }
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('WEB SECURITY CHECK', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6), const Text('Passive inspection of common HTTP security headers. This does not prove a site is secure or vulnerable.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 20),
    TextField(controller: urlController, autocorrect: false, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Website URL', hintText: 'https://example.com')),
    const SizedBox(height: 12),
    Card(child: CheckboxListTile(value: authorized, onChanged: running ? null : (v) => setState(() => authorized = v ?? false), title: const Text('I own this website or have permission to assess it.'), controlAffinity: ListTileControlAffinity.leading)),
    const SizedBox(height: 14),
    FilledButton.icon(onPressed: running ? null : checkHeaders, icon: Icon(running ? Icons.hourglass_top : Icons.security), label: Text(running ? 'Checking...' : 'Check security headers')),
    const SizedBox(height: 14),
    if (running) const LinearProgressIndicator(),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('ASSESSMENT RESULT', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), Text(status),
      if (score != null) ...[
        const SizedBox(height: 12), Text('Header presence score: $score%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.lightBlueAccent)),
        if (finalUri != null) Text('Final URL: $finalUri', style: const TextStyle(color: Colors.white54, fontSize: 11)),
        const SizedBox(height: 12), const Text('PRESENT', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.greenAccent)),
        ...present.entries.map((e) => Padding(padding: const EdgeInsets.only(top: 6), child: Text('✓ ${e.key}: ${e.value}', style: const TextStyle(fontSize: 12)))),
        const SizedBox(height: 12), const Text('MISSING', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orangeAccent)),
        ...missing.map((h) => Padding(padding: const EdgeInsets.only(top: 6), child: Text('• $h — ${_headers[h]}', style: const TextStyle(fontSize: 12)))),
      ],
    ]))),
    const SizedBox(height: 12),
    const Text('A missing header is not automatically a vulnerability. Review the application architecture and deployment requirements before drawing conclusions.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4)),
  ]);
}

// Manual HTTP request/response workbench. This is not a transparent
// interception proxy: the user explicitly submits each request to a target
// they are authorized to assess. HTTPS uses normal platform certificate checks.
class HttpInspectorPage extends StatefulWidget {
  const HttpInspectorPage({super.key});
  @override
  State<HttpInspectorPage> createState() => _HttpInspectorPageState();
}

class _HttpInspectorPageState extends State<HttpInspectorPage> {
  final urlController = TextEditingController();
  final headersController = TextEditingController(text: 'User-Agent: NEO-CYBER-Android/0.4');
  final bodyController = TextEditingController();
  String method = 'GET';
  bool authorized = false, running = false;
  int? responseCode;
  Duration? elapsed;
  Map<String, String> responseHeaders = {};
  String responseBody = '', status = 'Ready — enter an authorized URL and send a request.';

  @override
  void dispose() {
    urlController.dispose(); headersController.dispose(); bodyController.dispose();
    super.dispose();
  }

  Map<String, String>? _parseHeaders(String raw) {
    final result = <String, String>{};
    for (final line in raw.split(RegExp(r'\r?\n'))) {
      if (line.trim().isEmpty) continue;
      final split = line.indexOf(':');
      if (split <= 0) return null;
      final name = line.substring(0, split).trim();
      final value = line.substring(split + 1).trim();
      if (!RegExp(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+").hasMatch(name) ||
          name.toLowerCase() == 'host' || name.toLowerCase() == 'content-length' ||
          name.toLowerCase() == 'connection') return null;
      result[name] = value;
    }
    return result;
  }

  Future<void> sendRequest() async {
    if (!authorized) { setState(() => status = 'Confirm that you own the target or have explicit permission.'); return; }
    var raw = urlController.text.trim();
    if (raw.isEmpty) { setState(() => status = 'Enter a URL.'); return; }
    if (!raw.contains('://')) raw = 'https://$raw';
    final uri = Uri.tryParse(raw);
    if (uri == null || !uri.hasAuthority || uri.host.isEmpty ||
        (uri.scheme != 'http' && uri.scheme != 'https') || uri.userInfo.isNotEmpty) {
      setState(() => status = 'Use a valid http:// or https:// URL without embedded credentials.'); return;
    }
    final customHeaders = _parseHeaders(headersController.text);
    if (customHeaders == null) { setState(() => status = 'Invalid header line. Use Name: value; Host and Content-Length are managed automatically.'); return; }
    if (method == 'POST' && bodyController.text.length > 16000) {
      setState(() => status = 'Request body is limited to 16 KB.'); return;
    }
    setState(() { running = true; status = 'Sending $method request...'; responseCode = null; responseHeaders = {}; responseBody = ''; elapsed = null; });
    final watch = Stopwatch()..start();
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 12)
      ..idleTimeout = const Duration(seconds: 5)
      ..maxConnectionsPerHost = 1
      ..userAgent = 'NEO-CYBER-Android/0.4';
    try {
      late HttpClientRequest request;
      switch (method) {
        case 'HEAD': request = await client.headUrl(uri).timeout(const Duration(seconds: 15)); break;
        case 'OPTIONS': request = await client.openUrl('OPTIONS', uri).timeout(const Duration(seconds: 15)); break;
        case 'POST': request = await client.postUrl(uri).timeout(const Duration(seconds: 15)); break;
        default: request = await client.getUrl(uri).timeout(const Duration(seconds: 15));
      }
      for (final entry in customHeaders.entries) {
        request.headers.set(entry.key, entry.value);
      }
      if (method == 'POST') {
        request.headers.contentType = ContentType('text', 'plain', charset: 'utf-8');
        request.write(bodyController.text);
      }
      final response = await request.close().timeout(const Duration(seconds: 20));
      final headerMap = <String, String>{};
      response.headers.forEach((name, values) => headerMap[name] = values.join(', '));
      final bytes = <int>[];
      var truncated = false;
      await for (final chunk in response.timeout(const Duration(seconds: 20))) {
        final remaining = 48 * 1024 - bytes.length;
        if (remaining <= 0) { truncated = true; break; }
        if (chunk.length > remaining) { bytes.addAll(chunk.take(remaining)); truncated = true; break; }
        bytes.addAll(chunk);
      }
      watch.stop();
      final contentType = response.headers.contentType?.mimeType ?? '';
      String bodyText;
      if (contentType.startsWith('text/') || contentType.contains('json') || contentType.contains('xml') || contentType.contains('javascript')) {
        bodyText = utf8.decode(bytes, allowMalformed: true);
      } else if (bytes.isEmpty) {
        bodyText = '(empty response body)';
      } else {
        bodyText = 'Non-text response: ${bytes.length} bytes. Binary payload is not displayed.';
      }
      if (truncated) bodyText += '\n\n[Display truncated at 48 KB]';
      await HistoryStore.add(ScanRecord(type: 'HTTP request inspector', target: uri.host,
        summary: '$method ${uri.path.isEmpty ? '/' : uri.path} → HTTP ${response.statusCode}', timestamp: _now()));
      if (!mounted) return;
      setState(() { running = false; responseCode = response.statusCode; responseHeaders = headerMap; responseBody = bodyText; elapsed = watch.elapsed; status = 'Completed. Inspect the response below.'; });
    } on SocketException catch (e) {
      if (mounted) setState(() { running = false; status = 'Connection failed: ${e.message}'; });
    } on TimeoutException {
      if (mounted) setState(() { running = false; status = 'Request timed out.'; });
    } on HandshakeException {
      if (mounted) setState(() { running = false; status = 'TLS validation failed. NEO CYBER does not bypass certificate checks.'; });
    } catch (e) {
      if (mounted) setState(() { running = false; status = 'Request failed: $e'; });
    } finally { client.close(force: true); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('HTTP Inspector'), backgroundColor: _bg),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('BURP-STYLE REQUEST WORKBENCH', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 7),
      const Text('Manually send a request to an authorized website and inspect its response. This is not a transparent browser interception proxy.', style: TextStyle(color: Colors.white60, height: 1.4)),
      const SizedBox(height: 16),
      TextField(controller: urlController, autocorrect: false, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Target URL', hintText: 'https://your-test-site.example')),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: method, decoration: const InputDecoration(labelText: 'HTTP method'), items: const ['GET', 'HEAD', 'OPTIONS', 'POST'].map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(), onChanged: running ? null : (v) => setState(() => method = v ?? 'GET')),
      const SizedBox(height: 10),
      TextField(controller: headersController, minLines: 2, maxLines: 5, autocorrect: false, decoration: const InputDecoration(labelText: 'Request headers (one per line)', hintText: 'Accept: application/json')),
      if (method == 'POST') ...[
        const SizedBox(height: 10),
        TextField(controller: bodyController, minLines: 3, maxLines: 7, decoration: const InputDecoration(labelText: 'Plain-text request body (max 16 KB)')),
      ],
      const SizedBox(height: 10),
      Card(child: CheckboxListTile(value: authorized, onChanged: running ? null : (v) => setState(() => authorized = v ?? false), title: const Text('I own this target or have explicit permission to test it.'), controlAffinity: ListTileControlAffinity.leading)),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: running ? null : sendRequest, icon: Icon(running ? Icons.hourglass_top : Icons.send), label: Text(running ? 'Sending...' : 'Send request')),
      if (running) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('RESPONSE', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.bold, fontSize: 11)),
        const SizedBox(height: 8), Text(status),
        if (responseCode != null) ...[
          const SizedBox(height: 8),
          Text('HTTP $responseCode  •  ${elapsed?.inMilliseconds ?? 0} ms', style: const TextStyle(color: Colors.lightBlueAccent, fontWeight: FontWeight.bold, fontSize: 17)),
          const SizedBox(height: 12), const Text('RESPONSE HEADERS', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.bold, fontSize: 11)),
          ...responseHeaders.entries.map((e) => Padding(padding: const EdgeInsets.only(top: 5), child: SelectableText('${e.key}: ${e.value}', style: const TextStyle(fontSize: 11)))),
          const SizedBox(height: 12), const Text('RESPONSE BODY', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.bold, fontSize: 11)),
          const SizedBox(height: 5), SelectableText(responseBody, style: const TextStyle(fontFamily: 'monospace', fontSize: 11, height: 1.35)),
        ],
      ]))),
      const SizedBox(height: 10),
      const Text('Safety and scope: use only systems you own or are authorized to assess. NEO CYBER uses normal Android TLS certificate validation, does not install a CA, does not decrypt other apps’ traffic, and limits displayed response data.', style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.4)),
    ]),
  );
}

// Offline classic-PCAP reader. It deliberately displays packet metadata only;
// it does not capture traffic or expose application payloads.
class CapturedPacket {
  final int number, timestampMicros, capturedLength, originalLength;
  final String protocol, source, destination, details;
  const CapturedPacket({required this.number, required this.timestampMicros,
    required this.capturedLength, required this.originalLength,
    required this.protocol, required this.source, required this.destination,
    required this.details});
}

class PcapSummary {
  final String fileName;
  final int totalPackets;
  final List<CapturedPacket> packets;
  final Map<String, int> protocols;
  const PcapSummary({required this.fileName, required this.totalPackets,
    required this.packets, required this.protocols});
}

class PcapParser {
  static PcapSummary parse(Uint8List bytes, String fileName) {
    if (bytes.length < 12) throw const FormatException('Capture file is too small or incomplete.');
    final data = ByteData.sublistView(bytes);
    final magic = data.getUint32(0, Endian.big);
    if (magic == 0x0a0d0d0a) return _parsePcapNg(bytes, fileName);
    return _parseClassic(bytes, fileName);
  }

  static PcapSummary _parseClassic(Uint8List bytes, String fileName) {
    if (bytes.length < 24) throw const FormatException('File is too small to be a classic PCAP capture.');
    final data = ByteData.sublistView(bytes);
    final magic = data.getUint32(0, Endian.big);
    late final Endian endian;
    if (magic == 0xa1b2c3d4 || magic == 0xa1b23c4d) {
      endian = Endian.big;
    } else if (magic == 0xd4c3b2a1 || magic == 0x4d3cb2a1) {
      endian = Endian.little;
    } else {
      throw const FormatException('Unrecognized capture format. Select a PCAP or PCAPNG file.');
    }
    if (data.getUint16(4, endian) != 2) throw const FormatException('Unsupported PCAP version.');
    final linkType = data.getUint32(20, endian);
    if (linkType != 1) throw FormatException('Unsupported link type $linkType. Ethernet captures are supported.');
    final isNano = magic == 0xa1b23c4d || magic == 0x4d3cb2a1;
    final packets = <CapturedPacket>[];
    var offset = 24;
    while (offset + 16 <= bytes.length && packets.length < 10000) {
      final seconds = data.getUint32(offset, endian);
      final fraction = data.getUint32(offset + 4, endian);
      final fractionMicros = isNano ? fraction ~/ 1000 : fraction;
      if (fraction >= (isNano ? 1000000000 : 1000000)) throw const FormatException('Invalid packet timestamp fraction in classic PCAP.');
      final timestampMicros = seconds * 1000000 + fractionMicros;
      final included = data.getUint32(offset + 8, endian);
      final original = data.getUint32(offset + 12, endian);
      offset += 16;
      if (included > bytes.length - offset) throw const FormatException('Capture contains a truncated packet record.');
      final frame = Uint8List.sublistView(bytes, offset, offset + included);
      offset += included;
      packets.add(_decodePacket(packets.length + 1, timestampMicros, included, original, frame));
    }
    if (packets.isEmpty) throw const FormatException('No packet records were found in this capture.');
    return _summary(fileName, packets);
  }

  static PcapSummary _parsePcapNg(Uint8List bytes, String fileName) {
    var offset = 0;
    Endian? endian;
    final interfaces = <int>[];
    final timestampUnitsPerSecond = <double>[];
    final timestampOffsets = <int>[];
    final packets = <CapturedPacket>[];
    final view = ByteData.sublistView(bytes);
    while (offset + 12 <= bytes.length && packets.length < 10000) {
      final isSection = bytes[offset] == 0x0a && bytes[offset + 1] == 0x0d &&
          bytes[offset + 2] == 0x0d && bytes[offset + 3] == 0x0a;
      if (isSection) {
        if (offset + 12 > bytes.length) throw const FormatException('Truncated PCAPNG section header.');
        final bom = view.getUint32(offset + 8, Endian.big);
        if (bom == 0x1a2b3c4d) { endian = Endian.big; }
        else if (bom == 0x4d3c2b1a) { endian = Endian.little; }
        else { throw const FormatException('Invalid PCAPNG byte-order marker.'); }
        interfaces.clear();
        timestampUnitsPerSecond.clear();
        timestampOffsets.clear();
      }
      if (endian == null) throw const FormatException('PCAPNG section header is missing.');
      final blockType = view.getUint32(offset, endian);
      final blockLength = view.getUint32(offset + 4, endian);
      if (blockLength < 12 || blockLength % 4 != 0 || blockLength > bytes.length - offset) {
        throw const FormatException('Invalid or truncated PCAPNG block.');
      }
      final blockEnd = offset + blockLength;
      if (view.getUint32(blockEnd - 4, endian) != blockLength) {
        throw const FormatException('PCAPNG block length trailer does not match.');
      }
      if (blockType == 0x0a0d0d0a) {
        // Section Header Block: section state was reset above.
      } else if (blockType == 1) {
        if (blockLength < 20) throw const FormatException('Invalid PCAPNG interface block.');
        interfaces.add(view.getUint16(offset + 8, endian));
        var unitsPerSecond = 1000000.0; // PCAPNG default: microsecond resolution.
        var offsetSeconds = 0;
        var optionOffset = offset + 16;
        final optionsEnd = blockEnd - 4;
        while (optionOffset + 4 <= optionsEnd) {
          final code = view.getUint16(optionOffset, endian);
          final length = view.getUint16(optionOffset + 2, endian);
          optionOffset += 4;
          if (code == 0) break;
          if (optionOffset + length > optionsEnd) throw const FormatException('Invalid PCAPNG interface option length.');
          if (code == 9 && length == 1) {
            final resolution = bytes[optionOffset];
            unitsPerSecond = (resolution & 0x80) != 0
                ? _pow(2.0, resolution & 0x7f)
                : _pow10(resolution);
            if (!unitsPerSecond.isFinite || unitsPerSecond <= 0) {
              throw const FormatException('Unsupported PCAPNG timestamp resolution.');
            }
          } else if (code == 14 && length == 8) {
            offsetSeconds = view.getInt64(optionOffset, endian);
          }
          optionOffset += (length + 3) & ~3;
        }
        timestampUnitsPerSecond.add(unitsPerSecond);
        timestampOffsets.add(offsetSeconds);
      } else if (blockType == 6) {
        if (blockLength < 32) throw const FormatException('Invalid PCAPNG packet block.');
        final interfaceId = view.getUint32(offset + 8, endian);
        final high = view.getUint32(offset + 12, endian);
        final low = view.getUint32(offset + 16, endian);
        final captured = view.getUint32(offset + 20, endian);
        final original = view.getUint32(offset + 24, endian);
        final padded = (captured + 3) & ~3;
        if (28 + padded + 4 > blockLength) throw const FormatException('PCAPNG packet data is truncated.');
        if (interfaceId >= interfaces.length) throw const FormatException('PCAPNG packet references an unknown interface.');
        if (interfaces[interfaceId] != 1) throw FormatException('Unsupported PCAPNG link type ${interfaces[interfaceId]}. Ethernet captures are supported.');
        final frame = Uint8List.sublistView(bytes, offset + 28, offset + 28 + captured);
        final ticks = (high * 0x100000000) + low;
        final units = timestampUnitsPerSecond[interfaceId];
        final timestampMicros = (ticks * 1000000.0 / units).round() + timestampOffsets[interfaceId] * 1000000;
        packets.add(_decodePacket(packets.length + 1, timestampMicros, captured, original, frame));
      } else if (blockType == 3) {
        if (blockLength < 16) throw const FormatException('Invalid PCAPNG simple packet block.');
        if (interfaces.isNotEmpty && interfaces.first != 1) throw FormatException('Unsupported PCAPNG link type ${interfaces.first}. Ethernet captures are supported.');
        final original = view.getUint32(offset + 8, endian);
        final captured = (blockLength - 16).clamp(0, original).toInt();
        final frame = Uint8List.sublistView(bytes, offset + 12, offset + 12 + captured);
        packets.add(_decodePacket(packets.length + 1, -1, captured, original, frame));
      }
      offset = blockEnd;
    }
    if (packets.isEmpty) throw const FormatException('No supported Ethernet packet records were found in this PCAPNG capture.');
    return _summary(fileName, packets);
  }

  static double _pow10(int exponent) => exponent <= 308 ? _pow(10.0, exponent) : double.infinity;
  static double _pow(double base, int exponent) {
    var result = 1.0;
    for (var i = 0; i < exponent; i++) result *= base;
    return result;
  }

  static CapturedPacket _decodePacket(int number, int timestampMicros, int included, int original, Uint8List frame) {
    var protocol = 'Other';
    var source = '—';
    var destination = '—';
    var details = 'Ethernet frame';
    if (frame.length >= 14) {
      var etherType = (frame[12] << 8) | frame[13];
      var l3 = 14;
      if ((etherType == 0x8100 || etherType == 0x88a8 || etherType == 0x9100) && frame.length >= 18) {
        etherType = (frame[16] << 8) | frame[17];
        l3 = 18;
      }
      if (etherType == 0x0800 && frame.length >= l3 + 20) {
        final ihl = (frame[l3] & 0x0f) * 4;
        if (ihl >= 20 && frame.length >= l3 + ihl) {
          source = '${frame[l3+12]}.${frame[l3+13]}.${frame[l3+14]}.${frame[l3+15]}';
          destination = '${frame[l3+16]}.${frame[l3+17]}.${frame[l3+18]}.${frame[l3+19]}';
          final ipProto = frame[l3 + 9];
          final transport = l3 + ihl;
          if (ipProto == 6 && frame.length >= transport + 20) {
            protocol = 'TCP'; details = '${_u16(frame, transport)} → ${_u16(frame, transport + 2)}';
          } else if (ipProto == 17 && frame.length >= transport + 8) {
            protocol = 'UDP'; details = '${_u16(frame, transport)} → ${_u16(frame, transport + 2)}';
          } else if (ipProto == 1) { protocol = 'ICMP'; details = 'IPv4 ICMP'; }
          else { protocol = 'IPv4'; details = 'IP protocol $ipProto'; }
        }
      } else if (etherType == 0x86dd && frame.length >= l3 + 40) {
        source = _ipv6(frame, l3 + 8);
        destination = _ipv6(frame, l3 + 24);
        var nextHeader = frame[l3 + 6];
        var transport = l3 + 40;
        var guard = 0;
        while ((nextHeader == 0 || nextHeader == 43 || nextHeader == 60 || nextHeader == 44 || nextHeader == 51) && guard++ < 8) {
          if (transport + 2 > frame.length) break;
          final following = frame[transport];
          final extLength = nextHeader == 44 ? 8 : (nextHeader == 51 ? (frame[transport + 1] + 2) * 4 : (frame[transport + 1] + 1) * 8);
          if (extLength < 8 || transport + extLength > frame.length) break;
          transport += extLength;
          nextHeader = following;
        }
        if (nextHeader == 6 && frame.length >= transport + 20) { protocol = 'TCPv6'; details = '${_u16(frame, transport)} → ${_u16(frame, transport + 2)}'; }
        else if (nextHeader == 17 && frame.length >= transport + 8) { protocol = 'UDPv6'; details = '${_u16(frame, transport)} → ${_u16(frame, transport + 2)}'; }
        else if (nextHeader == 58) { protocol = 'ICMPv6'; details = 'IPv6 ICMP'; }
        else { protocol = 'IPv6'; details = 'Next header $nextHeader'; }
      } else if (etherType == 0x0806) { protocol = 'ARP'; details = 'Address resolution'; }
    }
    return CapturedPacket(number: number, timestampMicros: timestampMicros, capturedLength: included,
      originalLength: original, protocol: protocol, source: source, destination: destination, details: details);
  }

  static int _u16(Uint8List b, int o) => (b[o] << 8) | b[o + 1];
  static String _ipv6(Uint8List b, int o) {
    final groups = <int>[];
    for (var i = 0; i < 16; i += 2) groups.add((b[o + i] << 8) | b[o + i + 1]);
    return groups.map((v) => v.toRadixString(16)).join(':');
  }
  static PcapSummary _summary(String name, List<CapturedPacket> packets) {
    final counts = <String, int>{};
    for (final packet in packets) { counts[packet.protocol] = (counts[packet.protocol] ?? 0) + 1; }
    return PcapSummary(fileName: name, totalPackets: packets.length, packets: packets, protocols: counts);
  }
}
class PacketAnalyzerPage extends StatefulWidget {
  const PacketAnalyzerPage({super.key});
  @override
  State<PacketAnalyzerPage> createState() => _PacketAnalyzerPageState();
}

class _PacketAnalyzerPageState extends State<PacketAnalyzerPage> {
  PcapSummary? summary;
  String status = 'Import an Ethernet .pcap or .pcapng file to inspect packet metadata.';
  bool loading = false;

  Future<void> importCapture() async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.custom,
        allowedExtensions: ['pcap', 'pcapng'], withData: true);
      if (result == null) return;
      final file = result.files.single;
      final bytes = file.bytes;
      if (bytes == null) throw const FormatException('Could not read the selected file. Try choosing it again.');
      setState(() { loading = true; status = 'Analyzing ${file.name}...'; });
      await Future<void>.delayed(Duration.zero);
      final parsed = PcapParser.parse(bytes, file.name);
      await HistoryStore.add(ScanRecord(type: 'PCAP analysis', target: file.name,
        summary: '${parsed.totalPackets} packets; ${parsed.protocols.length} protocols', timestamp: _now()));
      if (!mounted) return;
      setState(() { summary = parsed; loading = false; status = 'Analysis complete. Displaying packet metadata only.'; });
    } on FormatException catch (e) {
      if (mounted) setState(() { loading = false; status = e.message; });
    } catch (e) {
      if (mounted) setState(() { loading = false; status = 'Could not analyze capture: $e'; });
    }
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('PACKET ANALYZER', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6),
    const Text('Offline Ethernet PCAP/PCAPNG inspection with capture-accurate packet timestamps where the file provides them. No root access is required.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 18),
    FilledButton.icon(onPressed: loading ? null : importCapture,
      icon: Icon(loading ? Icons.hourglass_top : Icons.file_open),
      label: Text(loading ? 'Analyzing...' : 'Import PCAP / PCAPNG')),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(status))),
    if (summary != null) ...[
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(summary!.fileName, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6), Text('${summary!.totalPackets} packets analyzed', style: const TextStyle(color: Colors.lightBlueAccent, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12), const Text('PROTOCOL BREAKDOWN', style: TextStyle(fontSize: 11, color: Colors.white54, fontWeight: FontWeight.bold)),
        ...summary!.protocols.entries.map((e) => Padding(padding: const EdgeInsets.only(top: 7), child: Row(children: [Expanded(child: Text(e.key)), Text('${e.value}')]))),
      ]))),
      const SizedBox(height: 12),
      const Text('PACKET LIST', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
      const SizedBox(height: 8),
      ...summary!.packets.take(300).map((p) => Card(child: ListTile(
        dense: true, leading: CircleAvatar(radius: 16, child: Text('${p.number}', style: const TextStyle(fontSize: 10)),),
        title: Text('${p.protocol}  ${p.details}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
        subtitle: Text('${p.source}  →  ${p.destination}\nUTC: ${p.timestampMicros < 0 ? 'Timestamp unavailable' : DateTime.fromMicrosecondsSinceEpoch(p.timestampMicros, isUtc: true).toIso8601String()}\n${p.capturedLength} bytes captured / ${p.originalLength} bytes on wire', style: const TextStyle(fontSize: 11)),
        isThreeLine: true,
      ))),
      if (summary!.totalPackets > 300) const Text('Showing the first 300 packets for mobile performance.', style: TextStyle(color: Colors.white54, fontSize: 12)),
    ],
    const SizedBox(height: 12),
    const Text('Packet metadata is read from the capture file you select. This analyzer does not capture live traffic, decrypt HTTPS, or inspect application payloads. Ethernet captures are supported; unsupported link types are reported.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4)),
  ]);
}

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  late Future<List<ScanRecord>> records;
  String _query = '';
  String _kind = 'All';
  String _order = 'Newest first';
  @override
  void initState() { super.initState(); records = HistoryStore.load(); }
  void refresh() => setState(() => records = HistoryStore.load());

  Future<void> _exportRecord(ScanRecord record) async {
    final doc = pw.Document();
    final levelCounts = <String, int>{};
    for (final detail in record.details) {
      final level = (detail['level'] ?? 'info').toString().toLowerCase();
      levelCounts[level] = (levelCounts[level] ?? 0) + 1;
    }
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(36),
      build: (_) => [
        pw.Text('NEO CYBER', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 4),
        pw.Text('SAVED ASSESSMENT REPORT', style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
        pw.Divider(),
        pw.Text('Assessment: ${record.type}'),
        pw.Text('Target: ${record.target}'),
        pw.Text('Recorded: ${record.timestamp}'),
        pw.SizedBox(height: 8),
        pw.Text('Summary: ${record.summary}'),
        if (record.details.isNotEmpty) ...[
          pw.SizedBox(height: 14),
          pw.Text('OBSERVATIONS', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 6),
          ...record.details.map((detail) => pw.Container(
            margin: const pw.EdgeInsets.only(bottom: 10),
            padding: const pw.EdgeInsets.all(9),
            decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400)),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text('[${(detail['level'] ?? 'info').toString().toUpperCase()}] ${detail['title'] ?? 'Observation'}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              if ((detail['evidence'] ?? '').toString().isNotEmpty) ...[
                pw.SizedBox(height: 4), pw.Text('Evidence: ${detail['evidence']}'),
              ],
              if ((detail['recommendation'] ?? '').toString().isNotEmpty) ...[
                pw.SizedBox(height: 4), pw.Text('Recommendation: ${detail['recommendation']}'),
              ],
            ]),
          )),
        ] else ...[
          pw.SizedBox(height: 12),
          pw.Text('Detailed observations were not stored for this older record.'),
        ],
        if (levelCounts.isNotEmpty) ...[
          pw.SizedBox(height: 8),
          pw.Text('Recorded observation counts: ${levelCounts.entries.map((e) => '${e.key}: ${e.value}').join(' | ')}'),
        ],
        pw.Divider(),
        pw.Text('Report note', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        pw.Text('This document reproduces information saved by NEO CYBER at the time of assessment. It does not perform a new scan or independently validate the recorded observations.'),
      ],
    ));
    final safeStamp = DateTime.now().millisecondsSinceEpoch;
    await Printing.sharePdf(bytes: await doc.save(), filename: 'neo_cyber_history_$safeStamp.pdf');
  }

  Future<void> _showRecord(ScanRecord record) async {
    await showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(
      title: Text(record.type),
      content: SizedBox(width: 420, child: SingleChildScrollView(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          SelectableText('Target: ${record.target}\nDate: ${record.timestamp}\n\n${record.summary}'),
          if (record.details.isNotEmpty) ...[
            const SizedBox(height: 16), const Text('RECORDED DETAILS', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.lightBlueAccent)),
            const SizedBox(height: 8),
            ...record.details.map((detail) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('[${(detail['level'] ?? 'info').toString().toUpperCase()}] ${detail['title'] ?? 'Observation'}', style: const TextStyle(fontWeight: FontWeight.bold)),
              if ((detail['evidence'] ?? '').toString().isNotEmpty) Text('Evidence: ${detail['evidence']}'),
              if ((detail['recommendation'] ?? '').toString().isNotEmpty) Text('Recommendation: ${detail['recommendation']}', style: const TextStyle(color: Colors.white70)),
            ]))),
          ] else const Padding(padding: EdgeInsets.only(top: 12), child: Text('This record contains a summary only; detailed evidence was not stored for this assessment.', style: TextStyle(color: Colors.white54, fontSize: 12))),
        ],
      ))),
      actions: [
        if (record.type.toLowerCase().contains('web') && record.details.isNotEmpty)
          TextButton.icon(onPressed: () { Navigator.pop(dialogContext); _exportRecord(record); }, icon: const Icon(Icons.picture_as_pdf), label: const Text('Export PDF')),
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Close')),
      ],
    ));
  }

  Future<void> _clearAll() async {
    final confirmed = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('Clear all history?'), content: const Text('This permanently deletes locally saved assessment records.'),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Clear history'))],
    ));
    if (confirmed == true) { await HistoryStore.clear(); refresh(); }
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    Row(children: [const Expanded(child: Text('ASSESSMENT HISTORY', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))), IconButton(tooltip: 'Refresh', onPressed: refresh, icon: const Icon(Icons.refresh)), IconButton(tooltip: 'Clear all history', onPressed: _clearAll, icon: const Icon(Icons.delete_outline))]),
    const SizedBox(height: 6), const Text('Stored on this phone. Tap a record to inspect its saved evidence.', style: TextStyle(color: Colors.white60, fontSize: 12)),
    const SizedBox(height: 10),
    FutureBuilder<List<ScanRecord>>(future: records, builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()));
      final allItems = snapshot.data ?? <ScanRecord>[];
      if (allItems.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('No assessments saved yet. Completed scans will appear here.')));
      final query = _query.trim().toLowerCase();
      final items = allItems.where((r) {
        final type = r.type.toLowerCase();
        final isWeb = type.contains('web') || type.contains('http') || type.contains('header');
        final isNetwork = type.contains('tcp') || type.contains('network') || type.contains('port');
        final matchesKind = _kind == 'All' || (_kind == 'Web' && isWeb) || (_kind == 'Network' && isNetwork) || (_kind == 'Other' && !isWeb && !isNetwork);
        final haystack = '${r.type} ${r.target} ${r.summary} ${r.timestamp}'.toLowerCase();
        return matchesKind && (query.isEmpty || haystack.contains(query));
      }).toList();
      items.sort((a, b) => _order == 'Newest first' ? b.timestamp.compareTo(a.timestamp) : a.timestamp.compareTo(b.timestamp));
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search target, tool or finding', border: OutlineInputBorder(), isDense: true), onChanged: (value) => setState(() => _query = value)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: ['All', 'Web', 'Network', 'Other'].map((kind) => ChoiceChip(label: Text(kind), selected: _kind == kind, onSelected: (_) => setState(() => _kind = kind))).toList()),
        const SizedBox(height: 6),
        Align(alignment: Alignment.centerRight, child: DropdownButton<String>(value: _order, underline: const SizedBox.shrink(), items: const [DropdownMenuItem(value: 'Newest first', child: Text('Newest first')), DropdownMenuItem(value: 'Oldest first', child: Text('Oldest first'))], onChanged: (value) { if (value != null) setState(() => _order = value); })),
        if (items.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('No records match these filters. Try another search or category.'))),
        ...items.map((r) => Card(child: ListTile(
        onTap: () => _showRecord(r), leading: const Icon(Icons.fact_check_outlined, color: _blue),
        title: Text(r.type), subtitle: Text('${r.target}\n${r.summary}\n${r.timestamp}'), isThreeLine: true,
        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
          if (r.type.toLowerCase().contains('web') && r.details.isNotEmpty)
            IconButton(tooltip: 'Export saved assessment as PDF', icon: const Icon(Icons.picture_as_pdf_outlined), onPressed: () => _exportRecord(r)),
          IconButton(tooltip: 'Delete record', icon: const Icon(Icons.delete_outline), onPressed: () async { await HistoryStore.remove(r); refresh(); }),
        ]),
      ))),
      ]);
    }),
  ]);
}

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});
  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  bool checking = false;
  DateTime? checkedAt;
  List<_HealthCheck> checks = const [];

  Future<void> _runChecks() async {
    setState(() { checking = true; checks = const []; });
    final results = <_HealthCheck>[];

    results.add(_HealthCheck('Android runtime', Platform.isAndroid,
        Platform.isAndroid ? 'Running on Android.' : 'This build is not running on Android.'));

    try {
      final records = await HistoryStore.load();
      results.add(_HealthCheck('Local history storage', true,
          'History can be read (${records.length} saved records).'));
    } catch (error) {
      results.add(_HealthCheck('Local history storage', false,
          'Could not read local history: $error'));
    }

    ServerSocket? probe;
    try {
      probe = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0,
          shared: false).timeout(const Duration(seconds: 3));
      results.add(_HealthCheck('Loopback TCP sockets', true,
          'Local TCP bind succeeded on 127.0.0.1:${probe.port}.'));
    } catch (error) {
      results.add(_HealthCheck('Loopback TCP sockets', false,
          'Local TCP bind failed: $error'));
    } finally {
      await probe?.close();
    }

    if (!mounted) return;
    setState(() {
      checks = results;
      checkedAt = DateTime.now();
      checking = false;
    });
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('ABOUT NEO CYBER', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 14),
    const Text('NEO CYBER is an Android-first security assessment app designed for non-rooted phones. It does not require a laptop.'),
    const SizedBox(height: 16),
    const Text('Available functions', style: TextStyle(fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('• Bounded TCP connect scanner with stop control.\n• Passive HTTP security-header checker.\n• Manual HTTP request/response inspector.\n• Offline Ethernet PCAP and PCAPNG metadata analyzer with IPv4/IPv6 endpoint decoding.\n• Local assessment history.\n• Loopback-only explicit HTTP forward proxy.\n• Passive web configuration and cookie assessment.'),
    const SizedBox(height: 16),
    const Text('The app only performs supported functions within Android permissions. It does not provide unrestricted Wireshark, Burp Suite, OWASP ZAP or Metasploit desktop functionality.'),
    const SizedBox(height: 20),
    const Text('APP INTEGRATION CHECK', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
    const SizedBox(height: 6),
    const Text('Run real local checks for Android runtime, saved-history readability and loopback TCP socket support. These checks do not contact external systems.', style: TextStyle(color: Colors.white60, fontSize: 12, height: 1.4)),
    const SizedBox(height: 12),
    SizedBox(width: double.infinity, child: FilledButton.icon(
      onPressed: checking ? null : _runChecks,
      icon: checking ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.fact_check),
      label: Text(checking ? 'Checking…' : 'Run app checks'),
    )),
    if (checkedAt != null) ...[
      const SizedBox(height: 8),
      Text('Last checked: ${checkedAt!.toLocal()}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
      const SizedBox(height: 8),
      ...checks.map((item) => Card(child: ListTile(
        leading: Icon(item.passed ? Icons.check_circle : Icons.error_outline,
            color: item.passed ? Colors.greenAccent : Colors.orangeAccent),
        title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(item.detail, style: const TextStyle(color: Colors.white60)),
      ))),
      Text('${checks.where((item) => item.passed).length} of ${checks.length} checks passed. This is a local capability check, not a full app certification.',
          style: const TextStyle(color: Colors.white54, fontSize: 11)),
    ],
    const SizedBox(height: 18),
    const Text('Only assess systems you own or have explicit permission to test.', style: TextStyle(color: Colors.white54)),
  ]);
}

class _HealthCheck {
  final String name;
  final bool passed;
  final String detail;
  const _HealthCheck(this.name, this.passed, this.detail);
}
